=== MACE Smart Product Importer Enterprise ===
Contributors: mace
Requires at least: 6.2
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 5.3.65-rc.1

Import automatique de produits WooCommerce depuis une URL avec mode autonome et MACE Cloud.


== 5.3.30 RC1 — Characteristics Materialization ==
* Conserve la Description source exacte sans y concaténer artificiellement les Caractéristiques.
* Matérialise `specifications_html` dans un onglet WooCommerce distinct « Caractéristiques ».
* Les couples libellé/valeur restent également des attributs WooCommerce visibles.
* Enregistre les lignes de spécifications, le rapport de preuves, les sections produit détectées et le Product Acquisition Path Registry en métadonnées de diagnostic.
* Protection anti-doublon : aucun second onglet n'est ajouté si un ancien chemin a déjà intégré le tableau à la description.


== 5.3.4 RC1 ==
* Génération automatique d’une description courte lorsqu’elle est absente ou réduite au titre.
* Résumé extractif de 1 à 2 phrases à partir du titre et de la description longue, sans invention de données.
* Détection des fausses descriptions courtes qui répètent presque uniquement le titre.
* Traçabilité de l’origine de la description courte dans les métadonnées MACE.

== 5.3.9-rc.1 ==
* Activation automatique MACE Cloud sans copie manuelle de clé.
* Jeton signé, limité au site WordPress et vérifié avant extraction.
* Endpoint Cloud /v1/auth/register et /v1/auth/verify.
* Endpoint /v1/extract connecté au constructeur WooCommerce.
* Protection contre le chargement simultané de plusieurs versions du plugin.
* Validation stricte et refus des produits trop incomplets.

= 5.2.3 RC1 =
* Conservation des paragraphes, listes, titres, tableaux et sauts de ligne dans les descriptions.
* Mise en forme automatique des descriptions aplaties.
* Nettoyage sécurisé du HTML avant enregistrement dans WooCommerce.

= 5.2.3 RC1 =
* Import fidèle des tableaux de caractéristiques.
* Ajout automatique du tableau à la description longue.
* Attributs WooCommerce créés à partir des paires libellé/valeur.
* Tableau responsive sur ordinateur et mobile.

= 5.2.4 RC1 =
* Politique d'images fail-closed : seules les sources produit faisant autorité sont autorisées.
* Le balayage global de toutes les images du DOM est supprimé.
* Remplacement atomique de la galerie et nettoyage des médias intrus hérités des imports précédents.
* Double validation Cloud + WordPress de la liste blanche des URL d'images.


== 5.3.4 RC1 ==
* Conserve les vues, couleurs, finitions et configurations appartenant à la galerie officielle du même produit.
* Enregistre le rôle, la source, les motifs et les indices de variante de chaque image.
* Maintient l'exclusion stricte des médias hors produit.


== 5.3.6 RC1 ==
* Rejet bloquant des descriptions courtes Fnac/marketplace (Achetez sur, infos et prix, livraison, retrait magasin).
* Seuil automatique relevé à 70/100.
* Enregistrement de la raison exacte du rejet dans les métadonnées produit.
* Régénération factuelle à partir de la description longue lors des mises à jour.

== 5.3.7 RC1 ==
* Génération automatique d’une UGS courte lorsqu’aucune UGS source exploitable n’est disponible.
* Format généré fixe de 10 caractères, composé de lettres majuscules et de chiffres.
* Contrôle d’unicité sur les produits et variations WooCommerce.
* Conservation permanente de l’UGS lors des réimportations et traçabilité source/générée.


= 5.3.9 RC1 =
* Formateur professionnel de description courte (introduction + points clés).
* Déduplication exacte et perceptuelle des images, conservation de la meilleure résolution.
* Création et association automatique des marques absentes via la taxonomie disponible ou la taxonomie MACE de secours.


== 5.3.10 RC1 ==
* Endpoint MACE Cloud par défaut migré vers https://mace-cloud-extraction-engine-h5q7.onrender.com.
* Migration automatique de l'ancien endpoint stocké dans WordPress, sans écraser une URL Cloud personnalisée différente.
* Réinitialisation ciblée des anciens identifiants lors de la migration d'endpoint afin d'éviter les jetons signés par l'ancien déploiement.
* Activation automatique du Cloud dès que « Utiliser MACE Cloud » est coché et qu'aucun identifiant n'est disponible.
* Ré-authentification automatique unique sur HTTP 401/site_mismatch puis nouvelle tentative d'extraction.
* Le Cloud reste prioritaire lorsque l'option « Cloud prioritaire » est activée.


== 5.3.11 RC1 ==
* Correctif de non-régression EAN/GTIN après activation réelle du Cloud h5q7.
* Cloud prioritaire n'est plus Cloud exclusif : une réponse Cloud incomplète peut être complétée par la lecture autonome.
* Résolution GTIN/EAN multi-preuves : gtin8/12/13/14, EAN, UPC, barcode, variantes, caractéristiques et tableaux techniques.
* Fusion conservatrice : les valeurs Cloud existantes restent prioritaires ; seules les données absentes sont complétées.
* Le GTIN récupéré continue d'être écrit dans WooCommerce _global_unique_id et _mace5311_spi_gtin.


== 5.3.17 RC1 — Recover Before Fail ==
* Moteur Golden 5.3.11 préservé.
* Recovery marque uniquement si la marque reste absente, depuis les preuves de la même fiche.
* Recovery catégorie métier uniquement si la catégorie est absente ou générique.
* Compatible avec le Cloud 5.3.9 et le Browser Bridge 2.0.5.


== 5.3.18 RC1 — Product Media Ownership ==
* Conserve les acquis 5.3.17.
* Filtre les médias par appartenance à la zone/famille exacte du produit.
* Fusionne les résolutions d’une même vue avant WordPress.
* Les vues validées ne sont plus supprimées par similarité perceptuelle.

== 5.3.19 RC1 — Primary Price Authority ==
* Préserve les acquis 5.3.18.
* Sélection du prix principal à partir de la buy-box/CTA et rejet des autres offres, livraison, mensualités et frais.
* Mapping additif poids/dimensions vers les champs WooCommerce lorsqu'ils sont déjà présents dans la fiche.
* Reporting média clarifié : représentations détectées, vues distinctes validées, bruits rejetés, représentations fusionnées/écartées.

== 5.3.20 RC1 — Commerce Noise Firewall ==
* Conserve Primary Price Authority 513,44 €, Product Media Ownership, marque, catégorie, EAN et mapping poids/dimensions.
* Exclut des caractéristiques les tableaux de financement/paiement (3X/4X, apport, J+28/J+60/J+90, TAEG, mensualités, crédit, etc.).
* Empêche ces données commerciales de contaminer la description courte.
* Défense en profondeur côté plugin pour nettoyer une capture issue d'un Cloud antérieur.


== 5.3.22 RC1 — Shipping Dimensions Authority ==
Récupération additive des dimensions depuis attributs, specifications[], specifications_html et description rendue; mapping automatique vers Longueur/Largeur/Hauteur WooCommerce sans régression du poids, prix, médias, marque, catégorie ou EAN.

== 5.3.23 RC1 — Unicode Dimensions Normalization ==
Normalise les caractères Unicode invisibles (ex. U+200E) présents dans certaines fiches marketplace avant détection des dimensions. Conserve prix principal, média ownership, marque, catégorie, EAN et poids.

== 5.3.24 RC1 — Golden Non-Regression ==
* Livraison cumulative basée sur 5.3.23, sans retrait de mécanisme d'import H5Q7.
* Stack qualifiée : Plugin 5.3.24 RC1 + Browser Bridge 2.0.12 + Cloud 5.3.16 RC1.
* Endpoint Cloud H5Q7 conservé.


== 5.3.25 RC1 — Safe Presentation Restore ==
* Base cumulative 5.3.24, sans retrait des acquis techniques validés.
* Restauration de la structure des descriptions longues aplaties : paragraphes, sections explicites, listes et tableaux source conservés.
* Segmentation compatible avec les textes marketplace en minuscules ; les phrases ne restent plus collées faute de majuscule après le point.
* Description courte renforcée : vrai paragraphe factuel, jusqu'à cinq points clés vérifiés, pas de résumé réduit à un seul attribut.
* Suppression des ellipses finales dans la description courte professionnelle.
* Garde-fous de non-régression dédiés à la structure de description et à la qualité de la description courte.


== 5.3.27 RC1 — Source Layout Fidelity ==
* Préserve les blocs DOM source <div>/<section>/<article> au lieu de les aplatir.
* Reproduction fidèle de l’ordre, des titres, paragraphes, listes et tableaux de la fiche externe.
* Fnac Browser Bridge : la structure HTML rendue reste autoritaire pour la description longue.
* Aucun changement des politiques prix, médias, EAN/GTIN, marque, catégorie, poids ou dimensions.

== 5.3.27 RC1 — Source Layout Fidelity ==
* Préserve la section Description externe selon son ordre et ses blocs source.
* Supporte source-rendered-semantic-html-v2 et source-heading-range-html-v2.
* Empêche l'ajout d'une table de caractéristiques séparée dans une description source fidèle.
* Non-régression : prix, médias, EAN/GTIN, marque, catégorie, poids et dimensions inchangés.


== 5.3.28-rc.1 ==
* Ajoute Merchant Presentation Engine opt-in pour la description longue.
* Source Layout Fidelity reste le comportement par défaut.
* Content Fidelity Guard annule toute transformation présentant une divergence textuelle.
* Conserve la description source originale en méta pour audit et restauration.


5.3.29 RC1 — Description Readability + Marketplace Noise Firewall
- Aération légère des paragraphes longs activée par défaut et désactivable par import.
- Aucune reformulation : segmentation uniquement sur frontières de phrases existantes, protégée par Content Fidelity Guard SHA-256.
- Suppression finale des modules parasites de recommandation/cross-sell (« Les internautes ont aussi acheté », produits similaires, suggestions, etc.).
- Le mode Merchant professionnel reste optionnel et cumulatif.


== 5.3.56 RC1 — Version Identity Gate ==
* Unifie le nom public sur « MACE Smart Product Importer Enterprise 5.3.56 RC1 ».
* Le menu WooCommerce affiche « MACE 5.3.56 RC1 ».
* Aligne header WordPress, constante runtime, User-Agent Cloud, télémétrie et Stable tag sur 5.3.56-rc.1.
* Ajoute un Version Identity Gate bloquant toute future divergence entre ces surfaces.
* Conserve cumulativement Energy Truth Consistency 5.3.54 et Universal Gallery Cohort Completion 5.3.55.

== 5.3.57 RC1 — Mode-Aware Energy Authority ==
* Sépare strictement la classe énergétique SDR/défaut de la classe HDR.
* La classe HDR ne peut plus écraser la classe générique/SDR dans WooCommerce.
* Corrige les attributs corrompus du type « Classe énergétique D » = G en mode fail-closed.
* Préserve « Classe énergétique (mode HDR) » comme donnée technique distincte.

== 5.3.59 RC1 — Energy Truth Certificate Transport ==
* Recherche récursive des preuves énergétiques mode-aware dans toutes les enveloppes Cloud/Bridge.
* Une classe générique explicite de zone produit domine HDR même si SDR n’est pas explicitement nommé.
* Support du contrat energy_truth_certificate (default/SDR/HDR) et séparation inter-mode stricte.

== 5.3.60 RC1 — Product Truth Existence Gates ==
* Atomic Money Existence Gate rejects uncorroborated tiny CTA/rating/fee numbers instead of publishing a false price.
* Energy Existence Gate never synthesizes a product class from scale bounds; ambiguous bound aliases fail closed.
* Source Title Identity Authority prefers the visible product H1/certificate over foreign-locale structured aliases.
* Golden Fnac Samsung route D(default)/G(HDR) preserved.

== 5.3.61 RC1 — Multi-Mode Energy + Strict Tiny Price Gate ==
* Preserves exact operational energy grades such as A++ cooling / A heating.
* Never collapses A++/A to a generic A badge.
* Tiny weak CTA prices require independent structured/exact product-money corroboration.
* Preserves 5.3.60 title, gallery, GTIN, brand and category protections.


== 5.3.65 RC1 — Universal Evidence-to-Woo Materialization Firewall ==
* Cumulative base: 5.3.64 RC1; Price Candidate Ledger and every prior route are preserved.
* Consumes Cloud H5Q7 `materialization_contract` and treats `QUARANTINED` / `REJECTED` as an absolute downstream write prohibition.
* Prevents a generic/composite HVAC class such as `A++ / A` from recreating cooling/heating roles locally when Cloud did not certify them.
* Re-applies the contract after importer-side measurement recovery so local fallbacks cannot bypass Cloud subject/scope decisions.
* Clears stale WooCommerce weight/L/W/H and price fields on resume when the contract explicitly blocks them.
* Filters quarantined mode-specific attributes/specifications while preserving the generic energy display and component evidence.
* Legacy/autonomous imports without a Cloud materialization contract remain unchanged.

== 5.3.64 RC1 — Price Candidate Ledger + Terminal Materialization Gate ==
* Le prix n'est plus fusionné comme un simple scalaire : chaque candidat conserve montant, rôle et provenance.
* Un prix Cloud provenant d'un CTA/financement est exclu avant classement.
* Une preuve Product Offer récupérée localement peut remplacer le candidat Cloud faible sans modifier les autres champs validés.
* Si aucune preuve forte unique n'existe, le prix est bloqué fail-closed.
* Lors d'une reprise, un prix explicitement rejeté est effacé de WooCommerce au lieu de survivre comme ancien _regular_price.
* Golden regression: Samsung AR35 92,11 EUR CTA ne peut plus être matérialisé; un Product Offer fort peut gagner.

== 5.3.63 RC1 — Semantic Product-Price Existence Gate v2 ==
* Weak CTA, financing, instalment, shipping, fee and subscription amounts have zero terminal authority regardless of amount.
* A weak-role amount is accepted only when corroborated by an independent structured/exact PRODUCT_PRICE lane.
* Regression case Samsung AR35 ManoMano: 92.11 CTA is rejected; 499 structured offer remains valid.
