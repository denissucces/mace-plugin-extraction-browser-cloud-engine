<?php
defined('ABSPATH') || exit;
if (!class_exists('MACE5311_SPI_Attribute_Firewall')) require_once __DIR__ . '/class-mace-spi-attribute-firewall.php';

/**
 * H5Q7 Universal Evidence-to-Woo Materialization Firewall v1.
 *
 * This is intentionally a last-mile, fail-closed guard. Extraction may preserve every
 * piece of evidence, but WooCommerce fields are materialized only when the Cloud contract
 * confirms the semantic role/scope/subject for that field. When no Cloud contract exists,
 * legacy/autonomous behaviour is preserved for cumulative non-regression.
 */
final class MACE5311_SPI_Materialization_Firewall {
    private static function state(array $contract, string $field): string {
        $node = $contract['fields'][$field] ?? null;
        if (!is_array($node)) return '';
        return strtoupper(trim((string)($node['state'] ?? '')));
    }

    public static function field_state(array $product, string $field): string {
        $contract = is_array($product['materialization_contract'] ?? null) ? $product['materialization_contract'] : [];
        return self::state($contract, $field);
    }

    public static function has_contract(array $product): bool {
        return !empty($product['materialization_contract']) && is_array($product['materialization_contract']);
    }

    public static function is_blocked_state(string $state): bool {
        return in_array(strtoupper(trim($state)), ['QUARANTINED', 'REJECTED', 'BLOCKED'], true);
    }

    private static function evidence_value(array $contract, string $field): string {
        $node = $contract['fields'][$field] ?? null;
        if (!is_array($node)) return '';
        $evidence = $node['evidence'] ?? null;
        if (is_scalar($evidence)) return trim((string)$evidence);
        if (is_array($evidence)) {
            foreach (['value','selected','winner'] as $key) {
                if (isset($evidence[$key]) && is_scalar($evidence[$key])) return trim((string)$evidence[$key]);
            }
        }
        return '';
    }

    private static function energy_display(string $value): string {
        $value = strtoupper(trim(preg_replace('/\s*\/\s*/', ' / ', $value)));
        return preg_match('/^(?:A\+\+\+|A\+\+|A\+|[A-G])(?: \/ (?:A\+\+\+|A\+\+|A\+|[A-G]))?$/', $value) ? $value : '';
    }

    private static function energy_grade(string $value): string {
        $value = strtoupper(trim($value));
        return preg_match('/^(?:A\+\+\+|A\+\+|A\+|[A-G])$/', $value) ? $value : '';
    }

    private static function energy_role(string $label): string {
        return class_exists('MACE5311_SPI_Attribute_Firewall')
            ? MACE5311_SPI_Attribute_Firewall::energy_semantic_role($label)
            : 'none';
    }

    public static function filter_attributes(array $attributes, array $contract): array {
        $cooling_state = self::state($contract, 'energy_class_cooling');
        $heating_state = self::state($contract, 'energy_class_heating');
        $cooling_blocked = self::is_blocked_state($cooling_state);
        $heating_blocked = self::is_blocked_state($heating_state);
        $cooling_allowed = $cooling_state === 'ALLOW';
        $heating_allowed = $heating_state === 'ALLOW';
        $cooling_value = self::energy_grade(self::evidence_value($contract, 'energy_class_cooling'));
        $heating_value = self::energy_grade(self::evidence_value($contract, 'energy_class_heating'));

        $out = [];
        foreach ($attributes as $label => $value) {
            $role = self::energy_role((string)$label);
            if ($role === 'cooling_class' && $cooling_blocked) continue;
            if ($role === 'heating_class' && $heating_blocked) continue;
            if ($role === 'cooling_class' && $cooling_allowed && $cooling_value !== '') $value = $cooling_value;
            if ($role === 'heating_class' && $heating_allowed && $heating_value !== '') $value = $heating_value;
            $out[$label] = $value;
        }
        return $out;
    }

    public static function filter_specifications(array $rows, array $contract): array {
        $cooling_state = self::state($contract, 'energy_class_cooling');
        $heating_state = self::state($contract, 'energy_class_heating');
        $cooling_blocked = self::is_blocked_state($cooling_state);
        $heating_blocked = self::is_blocked_state($heating_state);
        $cooling_allowed = $cooling_state === 'ALLOW';
        $heating_allowed = $heating_state === 'ALLOW';
        $cooling_value = self::energy_grade(self::evidence_value($contract, 'energy_class_cooling'));
        $heating_value = self::energy_grade(self::evidence_value($contract, 'energy_class_heating'));

        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $label = (string)($row['label'] ?? ($row['name'] ?? ($row['key'] ?? '')));
            $role = self::energy_role($label);
            if ($role === 'cooling_class' && $cooling_blocked) continue;
            if ($role === 'heating_class' && $heating_blocked) continue;
            if ($role === 'cooling_class' && $cooling_allowed && $cooling_value !== '') $row['value'] = $cooling_value;
            if ($role === 'heating_class' && $heating_allowed && $heating_value !== '') $row['value'] = $heating_value;
            $out[] = $row;
        }
        return array_values($out);
    }

    public static function filter_specifications_html(string $html, array $contract): string {
        if ($html === '') return '';
        $cooling_blocked = self::is_blocked_state(self::state($contract, 'energy_class_cooling'));
        $heating_blocked = self::is_blocked_state(self::state($contract, 'energy_class_heating'));
        if (!$cooling_blocked && !$heating_blocked) return $html;

        $patterns = [];
        if ($cooling_blocked) $patterns[] = '(?:refroidissement|frigorifique|cooling|cold|froid)';
        if ($heating_blocked) $patterns[] = '(?:chauffage|heating|heat|chaud)';
        $mode = '(?:' . implode('|', $patterns) . ')';
        $energy = '(?:classe|efficacit[eé]|energy|[eé]nerg[eé]tique)';

        // Remove only row-like blocks that explicitly combine an energy concept with the
        // quarantined operational mode. Component/general facts remain untouched.
        foreach (['tr','li','p','dt','dd'] as $tag) {
            $html = preg_replace_callback(
                '~<' . $tag . '\b[^>]*>[\s\S]*?</' . $tag . '>~iu',
                static function (array $match) use ($energy, $mode): string {
                    $plain = html_entity_decode(strip_tags((string)$match[0]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    return preg_match('~' . $energy . '~iu', $plain) && preg_match('~' . $mode . '~iu', $plain) ? '' : (string)$match[0];
                },
                $html
            );
        }
        return trim($html);
    }

    public static function apply(array $product): array {
        if (!self::has_contract($product)) {
            $product['materialization_firewall_report'] = [
                'version' => 'plugin-universal-materialization-firewall-v1',
                'contract_present' => false,
                'policy' => 'legacy_non_regression_passthrough',
                'mutated' => false,
            ];
            return $product;
        }

        $contract = $product['materialization_contract'];
        $generic_energy_state = self::state($contract, 'energy_class');
        $generic_energy = self::energy_display(self::evidence_value($contract, 'energy_class'));
        if ($generic_energy_state === 'ALLOW' && $generic_energy !== '') {
            $product['energy_class'] = $generic_energy;
            if (!isset($product['attributes']) || !is_array($product['attributes'])) $product['attributes'] = [];
            $product['attributes']['Classe énergétique'] = $generic_energy;
        }
        $before = [
            'attributes' => count((array)($product['attributes'] ?? [])),
            'specifications' => count((array)($product['specifications'] ?? [])),
            'weight' => (string)($product['weight'] ?? ''),
            'length' => (string)($product['length'] ?? ''),
            'width' => (string)($product['width'] ?? ''),
            'height' => (string)($product['height'] ?? ''),
        ];

        $product['attributes'] = self::filter_attributes((array)($product['attributes'] ?? []), $contract);
        $product['specifications'] = self::filter_specifications((array)($product['specifications'] ?? []), $contract);
        $product['specifications_html'] = self::filter_specifications_html((string)($product['specifications_html'] ?? ''), $contract);

        foreach (['energy_class_cooling','energy_class_heating','cooling_energy_class','heating_energy_class','energy_efficiency_class_cooling','energy_efficiency_class_heating'] as $key) {
            $field = (strpos($key, 'cool') !== false) ? 'energy_class_cooling' : 'energy_class_heating';
            if (self::is_blocked_state(self::state($contract, $field))) unset($product[$key]);
        }

        if (self::is_blocked_state(self::state($contract, 'dimensions'))) {
            $product['length'] = '';
            $product['width'] = '';
            $product['height'] = '';
        }
        foreach (['length','width','height'] as $axis) {
            if (self::is_blocked_state(self::state($contract, $axis))) $product[$axis] = '';
        }
        if (self::is_blocked_state(self::state($contract, 'weight'))) $product['weight'] = '';

        if (self::is_blocked_state(self::state($contract, 'price'))) {
            $product['regular_price'] = '';
            $product['sale_price'] = '';
        }

        $after = [
            'attributes' => count((array)$product['attributes']),
            'specifications' => count((array)$product['specifications']),
            'weight' => (string)($product['weight'] ?? ''),
            'length' => (string)($product['length'] ?? ''),
            'width' => (string)($product['width'] ?? ''),
            'height' => (string)($product['height'] ?? ''),
        ];
        $product['materialization_firewall_report'] = [
            'version' => 'plugin-universal-materialization-firewall-v1',
            'contract_present' => true,
            'contract_version' => sanitize_text_field((string)($contract['version'] ?? '')),
            'policy' => 'fail_closed_on_cloud_quarantine',
            'states' => [
                'price' => self::state($contract, 'price'),
                'energy_class_cooling' => self::state($contract, 'energy_class_cooling'),
                'energy_class_heating' => self::state($contract, 'energy_class_heating'),
                'dimensions' => self::state($contract, 'dimensions'),
                'weight' => self::state($contract, 'weight'),
                'media' => self::state($contract, 'media'),
            ],
            'before' => $before,
            'after' => $after,
            'mutated' => $before !== $after,
            'downstream_quarantine_enforced' => true,
            'legacy_without_contract_preserved' => true,
            'non_regression' => true,
        ];
        return $product;
    }
}
