<?php
defined('ABSPATH') || exit;
if (!class_exists('MACE5311_SPI_Content_Firewall')) require_once __DIR__ . '/class-mace-spi-content-firewall.php';

final class MACE5311_SPI_Attribute_Firewall {
    private static function lower(string $value): string { return function_exists('mb_strtolower') ? mb_strtolower($value) : strtolower($value); }
    private static function length(string $value): int { return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value); }

    private static function clean(string $value): string {
        return trim((string)preg_replace('/\s+/u', ' ', html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
    }

    private static function norm(string $value): string {
        $value = self::lower(self::clean($value));
        if (function_exists('remove_accents')) $value = remove_accents($value);
        else $value = strtr($value, ['à'=>'a','á'=>'a','â'=>'a','ä'=>'a','ã'=>'a','å'=>'a','ç'=>'c','è'=>'e','é'=>'e','ê'=>'e','ë'=>'e','ì'=>'i','í'=>'i','î'=>'i','ï'=>'i','ñ'=>'n','ò'=>'o','ó'=>'o','ô'=>'o','ö'=>'o','õ'=>'o','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','ý'=>'y','ÿ'=>'y','œ'=>'oe']);
        return preg_replace('/[^a-z0-9]+/u', '', $value);
    }

    private static function contains_url_or_domain(string $value): bool {
        return (bool)preg_match('~(?:https?://|www\.|\b[a-z0-9-]+\.(?:com|fr|net|org|io|co|de|es|it|be|nl|eu)\b)~iu', $value);
    }

    private static function blocked_transport_key(string $normalized): bool {
        static $blocked = [
            'environment','devicetype','siteid','marketid','statuscode','statustext','entityid','entityname','catalog','nature','salescategory','userrating','labrating','offerid','sellertype','sellername','sellerid','sellerlocation','availability','availabilitytype','availabilityid','offerurl','fulfillment','baseprice','basepricewithtax','currency','taxrate','shippingmethod','shippingmethodid','pricewithtax','authstate',
            'hasenergyefficiencycategory','energyefficiencyscalemin','energyefficiencyscalemax',
            'colorhex','colourhex','colorcode','colourcode','csscolor','hexcolor'
        ];
        return in_array($normalized, $blocked, true);
    }

    private static function is_source_metadata_label(string $label): bool {
        $raw = self::clean($label);
        $normalized = self::norm($raw);
        if ($raw === '') return true;

        // Marketplace/source provenance is not a customer-facing product characteristic.
        // 5.3.49 additive hardening: some marketplaces concatenate the MMID value into
        // the attribute NAME itself (e.g. MMID651840876022), so exact-label filtering is insufficient.
        if (preg_match('/^mmid(?:[\s:_#.-]*[a-z0-9]{3,})?$/iu', $raw)) return true;
        if (str_starts_with($normalized, 'mmid') && strlen($normalized) > 4) return true;
        if (preg_match('/^(?:marketplace\s*id|source\s*id|source|provenance|origin\s*url|url\s*source)$/iu', $raw)) return true;
        if (preg_match('/^(?:r[ée]f(?:[ée]rence)?\.?\s*)?(?:manomano|fnac|rakuten|amazon|cdiscount|boulanger)(?:\s*(?:id|ref|r[ée]f(?:[ée]rence)?))?$/iu', $raw)) return true;
        if (preg_match('/\b(?:manomano|fnac|rakuten|amazon|cdiscount|boulanger)\b/iu', $raw) && preg_match('/\b(?:ref|r[ée]f(?:[ée]rence)?|id|source|marketplace)\b/iu', $raw)) return true;

        // Breadcrumb/navigation artefacts must never become WooCommerce attributes.
        if (preg_match('/^(?:vous\s+[eê]tes\s+ici|accueil)(?:\s*[:>\/]|$)/iu', $raw)) return true;
        if (substr_count($raw, '/') >= 2 && preg_match('/(?:accueil|jardin|entretien|cat[ée]gorie|rayon|produit)/iu', $raw)) return true;
        if (in_array($normalized, ['vousetesici','breadcrumb','breadcrumbs','filtrationnavigation','navigation'], true)) return true;

        // H5Q7 5.3.49 additive terminal product-boundary firewall: storefront chrome/navigation,
        // marketplace footer and account/service labels can never become product attributes.
        if (preg_match('/^(?:manomano\s*infos?|©?\s*\d{4}\s*manomano|top\s+ventes?|seconde\s+vie|peinture\s+et\s+droguerie|color\s*hex|colour\s*hex|catalogue|catalog|plan\s+du\s+site|mentions?\s+l[eé]gales?|protection\s+des\s+donn[eé]es|trust\s+center|accessibilit[eé]|rapports?|nos\s+inspirations|d[eé]couvrir\s+manoexpress|les\s+conseils\s+de\s+nos\s+experts|aide\s+et\s+param[eè]tres|aide\s+et\s+contact|profil|pro\.?\s*cr[eé]ez\s+votre\s+compte|d[eé]couvrir\s+notre\s+app|paiement\s+s[eé]curis[eé]|suivi\s+de\s+commande|retour\s*\/\s*r[eé]tractation|besoin\s+d.?aide|nous\s+contacter|notifier\s+un\s+contenu\s+illicite|devenir\s+marchand|programme\s+d.?affiliation|conditions\s+g[eé]n[eé]rales|nos\s+bons\s+conseils|facebook|instagram|linkedin|tiktok|pinterest|google\s+play|app\s+store|pro|vous\s+[eê]tes\s+un\s+professionnel\s*\?)$/iu', $raw)) return true;
        if (preg_match('/^\s*\/+[^0-9]/u', $raw)) return true;
        if (preg_match('/^©\s*\d{4}\b/u', $raw)) return true;
        return false;
    }

    private static function is_commercial_noise(string $label): bool {
        $value = self::lower(self::clean($label));
        if (function_exists('remove_accents')) $value = remove_accents($value);
        else $value = strtr($value, ['à'=>'a','á'=>'a','â'=>'a','ä'=>'a','ã'=>'a','å'=>'a','ç'=>'c','è'=>'e','é'=>'e','ê'=>'e','ë'=>'e','ì'=>'i','í'=>'i','î'=>'i','ï'=>'i','ñ'=>'n','ò'=>'o','ó'=>'o','ô'=>'o','ö'=>'o','õ'=>'o','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','ý'=>'y','ÿ'=>'y','œ'=>'oe']);
        return (bool)preg_match('/\b(?:duree\s+(?:minimum|maximum)\s+d.?engagement|engagement|montant\s+total.*interets|financement|mensualite|credit|taeg|paiement|(?:3|4)\s*x|j\s*(?:\+\s*)?\d+|assurance|livraison|expedition|vendeur|seller|merchant|offre|offer|availability|fulfillment|shipping|taxe|tva|taxrate|baseprice|pricewithtax)\b/u', $value);
    }

    private static function is_source_name(string $value, string $label): bool {
        if (preg_match('/\b(?:marque|brand|fabricant|manufacturer)\b/iu', $label)) return false;
        return (bool)preg_match('/^(?:fnac(?:\.com)?|manomano(?:\.fr)?|rakuten(?:\.fr)?|boulanger(?:\.com)?|amazon(?:\.fr)?|cdiscount(?:\.com)?)$/iu', self::clean($value));
    }

    private static function energy_grade(string $value): string {
        $value = self::clean($value);
        if (preg_match('/(?:Category|Categorie)([A-G](?:\+{1,3})?)\b/i', $value, $m)) return strtoupper($m[1]);
        if (preg_match('/^([A-G](?:\+{1,3})?)$/i', $value, $m)) return strtoupper($m[1]);
        return '';
    }

    private static function energy_letter(string $value): string {
        $grade = self::energy_grade($value);
        return $grade !== '' ? substr($grade, 0, 1) : '';
    }

    private static function energy_composite(string $value): string {
        $value = self::clean($value);
        if (preg_match('/^([A-G](?:\+{1,3})?)\s*\/\s*([A-G](?:\+{1,3})?)$/i', $value, $m)) {
            return strtoupper($m[1]) . ' / ' . strtoupper($m[2]);
        }
        return '';
    }

    public static function energy_semantic_role(string $label): string {
        $raw = self::clean($label);
        $normalized = self::norm($raw);
        if ($normalized === '') return 'none';
        if (in_array($normalized, ['energyefficiencyscalemin'], true)) return 'scale_min';
        if (in_array($normalized, ['energyefficiencyscalemax'], true)) return 'scale_max';
        if ($normalized === 'hasenergyefficiencycategory') return 'product_class';
        if (preg_match('/(?:classe|energy|energet)/iu', $raw) && preg_match('/(?:min(?:imale?)?|minimum|worst|borne\s+min)/iu', $raw)) return 'scale_min';
        if (preg_match('/(?:classe|energy|energet)/iu', $raw) && preg_match('/(?:max(?:imale?)?|maximum|best|borne\s+max)/iu', $raw)) return 'scale_max';
        // 5.3.57 Mode-Aware Energy Authority: SDR/default and HDR are distinct facts.
        // Never let a valid HDR class overwrite the default/SDR class.
        if (preg_match('/(?:classe|energy|energet)/iu', $raw) && preg_match('/\bHDR\b/iu', $raw)) return 'hdr_class';
        if (preg_match('/(?:classe|energy|energet)/iu', $raw) && preg_match('/\bSDR\b/iu', $raw)) return 'sdr_class';
        if (preg_match('/(?:classe|energy|energet)/iu', $raw) && preg_match('/(?:refroidissement|cooling|froid)/iu', $raw)) return 'cooling_class';
        if (preg_match('/(?:classe|energy|energet)/iu', $raw) && preg_match('/(?:chauffage|heating|heat)/iu', $raw)) return 'heating_class';
        if (preg_match('/^(?:classe\s+(?:(?:d[’\']?)?efficacit[eé]\s+)?[eé]nerg[eé]tique|energy\s+(?:efficiency\s+)?class)(?:\s+[A-G])?$/iu', $raw)) return 'product_class';
        return 'none';
    }

    public static function embedded_energy_letter(string $label): string {
        $raw = self::clean($label);
        if (preg_match('/(?:classe\s+(?:(?:d[’\']?)?efficacit[eé]\s+)?[eé]nerg[eé]tique|energy\s+(?:efficiency\s+)?class)\s+([A-G])$/iu', $raw, $m)) return strtoupper($m[1]);
        return '';
    }

    public static function is_energy_scale_bound_label(string $label): bool {
        $role = self::energy_semantic_role($label);
        return $role === 'scale_min' || $role === 'scale_max';
    }

    private static function canonical_label(string $label): string {
        $key = self::norm($label);
        $map = [
            'capacitedestockage'=>'Capacité de stockage','tailledelecranpouces'=>'Taille de l’écran (pouces)','couleur'=>'Couleur','coloris'=>'Couleur','systemedexploitation'=>'Système d’exploitation','caracteristiquesdelecran'=>'Caractéristiques de l’écran','appareilphoto'=>'Appareil photo','classeenergetique'=>'Classe énergétique','resolutionphoto'=>'Résolution photo','resolutionvideo'=>'Résolution vidéo','processeur'=>'Processeur','typedecartesim'=>'Type de carte SIM','autonomiemaximale'=>'Autonomie maximale','chargerapide'=>'Charge rapide','communicationsansfil'=>'Communications sans fil','accesinternetmobile'=>'Accès internet mobile','typededeverrouillage'=>'Type de déverrouillage','usagetelephoneportable'=>'Usage téléphone portable','gammetelephonie'=>'Gamme téléphonie','modeledetelephone'=>'Modèle de téléphone','indicedasteteenwkg'=>'Indice DAS tête','indicedastroncenwkg'=>'Indice DAS tronc','indicedasmembreenwkg'=>'Indice DAS membre','disponibilitedespiecesdetachees'=>'Disponibilité des pièces détachées','reconditionne'=>'Reconditionné','originedefabrication'=>'Origine de fabrication','fonctionnalitesia'=>'Fonctionnalités IA','captationdidentifiant'=>'Captation d’identifiant','chargeurinclus'=>'Chargeur inclus','puissancedechargeminimale'=>'Puissance de charge minimale','puissancedechargemaximale'=>'Puissance de charge maximale','compatibleusbpd'=>'Compatible USB PD','mentionlegale'=>'Mention légale','ean'=>'EAN','gtin'=>'GTIN','sku'=>'SKU','ugs'=>'UGS','poidsduproduit'=>'Poids du produit','longueurdueproduit'=>'Longueur du produit','largeurduproduit'=>'Largeur du produit','hauteurduproduit'=>'Hauteur du produit'
        ];
        return $map[$key] ?? self::clean($label);
    }

    public static function sanitize_pair(string $label, string $value): array {
        $label = self::clean($label);
        $value = self::clean($value);
        if ($label === '' || $value === '') return ['', '', 'empty'];
        if (MACE5311_SPI_Content_Firewall::is_custom_forbidden($label)) return ['', '', 'custom_admin_filter_label'];
        if (MACE5311_SPI_Content_Firewall::is_custom_forbidden($value)) return ['', '', 'custom_admin_filter_value'];
        $key = self::norm($label);
        if (self::is_source_metadata_label($label)) return ['', '', 'source_metadata'];

        // 5.3.54 Energy Truth Boundary: product class and scale bounds are different
        // semantic facts. A scale min/max value is NEVER allowed to become the product
        // energy class, even when the transport value looks like EUEnergyEfficiencyCategoryD.
        $energy_role = self::energy_semantic_role($label);
        if ($energy_role !== 'none') {
            $grade = self::energy_grade($value);
            $letter = $grade !== '' ? substr($grade, 0, 1) : '';
            $composite = self::energy_composite($value);
            $embedded = self::embedded_energy_letter($label);
            // Corruption guard: labels such as "Classe énergétique D" with value G are
            // internally inconsistent and must never materialize as a WooCommerce attribute.
            if ($embedded !== '' && $letter !== '' && $embedded !== $letter) return ['', '', 'energy_label_value_conflict'];
            if ($energy_role === 'product_class' && $composite !== '') return ['Classe énergétique', $composite, 'canonical_energy_multimode_product_class'];
            if ($energy_role === 'product_class' && $grade !== '') return ['Classe énergétique', $grade, 'canonical_energy_product_class'];
            if ($energy_role === 'sdr_class' && $grade !== '') return ['Classe énergétique', $grade, 'canonical_energy_sdr_class'];
            if ($energy_role === 'hdr_class' && $grade !== '') return ['Classe énergétique (mode HDR)', $grade, 'canonical_energy_hdr_class'];
            if ($energy_role === 'cooling_class' && $grade !== '') return ['Classe énergétique (refroidissement)', $grade, 'canonical_energy_cooling_class'];
            if ($energy_role === 'heating_class' && $grade !== '') return ['Classe énergétique (chauffage)', $grade, 'canonical_energy_heating_class'];
            if ($energy_role === 'scale_min' && $letter !== '') return ['Borne minimale de l’échelle énergétique', $letter, 'energy_scale_bound_min'];
            if ($energy_role === 'scale_max' && $letter !== '') return ['Borne maximale de l’échelle énergétique', $letter, 'energy_scale_bound_max'];
            if (in_array($energy_role, ['scale_min','scale_max','product_class','sdr_class','hdr_class','cooling_class','heating_class'], true)) return ['', '', 'invalid_energy_semantic_value'];
        }
        if (self::blocked_transport_key($key)) return ['', '', 'technical_transport_metadata'];
        if (self::is_commercial_noise($label)) return ['', '', 'commercial_noise'];
        if (MACE5311_SPI_Content_Firewall::contains_contact_or_personal_data($label . ' ' . $value)) return ['', '', 'personal_or_contact_data'];
        $value = MACE5311_SPI_Content_Firewall::sanitize_plain($value);
        if ($value === '') return ['', '', 'empty_after_privacy_firewall'];
        $value = MACE5311_SPI_Content_Firewall::translate_to_store_locale($value, 'attribute_value');
        // Merchant-safe corruption guard: concatenated transport/safety fragments such as
        // "Surface de tonte700EAN694..." are extraction artefacts, never customer-facing facts.
        $joined = self::norm($label . ' ' . $value);
        if (preg_match('/(?:ean|gtin|upc|isbn)\d{8,14}/i', $joined) && !preg_match('/^(?:ean|gtin|upc|isbn|codeean|codegtin)$/i', $key)) {
            return ['', '', 'concatenated_identifier_noise'];
        }
        if (preg_match('/\b(?:voir|consulter|afficher)\s+(?:le\s+)?d[eé]tail\s+(?:de\s+)?s[eé]curit[eé]\s+du\s+produit\b/iu', $value)) {
            return ['', '', 'marketplace_safety_link_label'];
        }
        if (self::contains_url_or_domain($label) || self::contains_url_or_domain($value)) return ['', '', 'url_or_domain'];
        if (self::is_source_name($value, $label)) return ['', '', 'source_or_seller_name'];
        return [self::canonical_label($label), $value, 'accepted'];
    }

    public static function sanitize_map(array $attributes): array {
        $out = [];
        foreach ($attributes as $label => $value) {
            if (is_array($value)) $value = implode(', ', array_map('strval', $value));
            [$clean_label, $clean_value] = self::sanitize_pair((string)$label, (string)$value);
            if ($clean_label === '' || $clean_value === '') continue;
            if (isset($out[$clean_label])) {
                if (self::length($out[$clean_label]) >= self::length($clean_value)) continue;
            }
            $out[$clean_label] = $clean_value;
        }
        foreach ($out as $candidate_label => $candidate_value) {
            $candidate_norm = self::norm($candidate_label);
            foreach ($out as $base_label => $base_value) {
                if ($candidate_label === $base_label) continue;
                $joined = self::norm($base_label . ' ' . $base_value);
                if ($joined !== '' && $candidate_norm === $joined) { unset($out[$candidate_label]); break; }
            }
        }
        return $out;
    }

    public static function sanitize_rows(array $rows): array {
        $out = [];
        $seen = [];
        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $group = sanitize_text_field((string)($row['group'] ?? 'Caractéristiques')) ?: 'Caractéristiques';
            $label = (string)($row['label'] ?? ($row['name'] ?? ($row['key'] ?? '')));
            $value = (string)($row['value'] ?? ($row['values'] ?? ''));
            [$label, $value] = self::sanitize_pair($label, $value);
            if ($label === '' || $value === '') continue;
            $fingerprint = md5(self::lower($label . '|' . $value));
            if (isset($seen[$fingerprint])) continue;
            $seen[$fingerprint] = true;
            $out[] = ['group'=>$group,'label'=>$label,'value'=>$value];
            if (count($out) >= 180) break;
        }
        return $out;
    }

    public static function sanitize_html(string $html): string {
        if (trim($html) === '') return '';
        $seen = [];
        $cleaned = preg_replace_callback('~<tr\b[^>]*>(.*?)</tr>~is', static function ($m) use (&$seen) {
            $cells = [];
            if (preg_match_all('~<(?:th|td)\b[^>]*>(.*?)</(?:th|td)>~is', (string)$m[1], $matches)) {
                foreach ($matches[1] as $cell) $cells[] = trim(wp_strip_all_tags((string)$cell));
            }
            if (count($cells) < 2) return '';
            [$label, $value] = self::sanitize_pair($cells[0], implode(' ', array_slice($cells, 1)));
            if ($label === '' || $value === '') return '';
            $fp = md5(self::lower($label . '|' . $value));
            if (isset($seen[$fp])) return '';
            $seen[$fp] = true;
            $escape = static fn($v) => function_exists('esc_html') ? esc_html($v) : htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            return '<tr><th scope="row">' . $escape($label) . '</th><td>' . $escape($value) . '</td></tr>';
        }, $html);
        $allowed = [
            'section'=>['class'=>true],'div'=>['class'=>true],'h2'=>[],'h3'=>[],'h4'=>[],
            'table'=>['class'=>true],'thead'=>[],'tbody'=>[],'tfoot'=>[],'tr'=>[],
            'th'=>['scope'=>true,'colspan'=>true,'rowspan'=>true], 'td'=>['colspan'=>true,'rowspan'=>true],
            'strong'=>[],'em'=>[],'br'=>[],'span'=>['class'=>true]
        ];
        return trim(function_exists('wp_kses') ? wp_kses((string)$cleaned, $allowed) : (string)$cleaned);
    }

    public static function sanitize_display_rows(array $rows): array {
        $out = [];
        foreach ($rows as $key => $row) {
            if (!is_array($row)) continue;
            $label = (string)($row['label'] ?? $key);
            $value = (string)($row['value'] ?? '');
            [$label, $value] = self::sanitize_pair(wp_strip_all_tags($label), wp_strip_all_tags($value));
            if ($label === '' || $value === '') continue;
            $row['label'] = $label;
            $row['value'] = $value;
            $out[$key] = $row;
        }
        return $out;
    }
}
