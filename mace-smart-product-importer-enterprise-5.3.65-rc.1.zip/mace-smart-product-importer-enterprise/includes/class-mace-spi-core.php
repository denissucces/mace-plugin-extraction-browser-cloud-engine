<?php
defined('ABSPATH') || exit;
if (!class_exists('MACE5311_SPI_Attribute_Firewall')) require_once __DIR__ . '/class-mace-spi-attribute-firewall.php';

final class MACE5311_SPI_Core {
    private static $instance;

    public static function instance(): self {
        return self::$instance ?: self::$instance = new self();
    }

    private function __construct() {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', [$this, 'missing_wc']);
            return;
        }
        foreach (['logger','client','extractor','quality','importer','admin'] as $file) {
            require_once MACE5311_SPI_DIR . 'includes/class-mace-spi-' . $file . '.php';
        }
        $logger = new MACE5311_SPI_Logger();
        $client = new MACE5311_SPI_Client($logger);
        $extractor = new MACE5311_SPI_Extractor();
        $quality = new MACE5311_SPI_Quality();
        $importer = new MACE5311_SPI_Importer($client, $extractor, $quality, $logger);
        new MACE5311_SPI_Admin($importer, $client, $logger);
        add_action('init', [$this, 'register_fallback_brand_taxonomy']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_styles']);
        add_filter('woocommerce_product_tabs', [$this, 'add_specifications_product_tab'], 25);
        add_filter('woocommerce_display_product_attributes', [$this, 'filter_product_attribute_display'], 999, 2);
    }


    /**
     * Materialise les caractéristiques MACE comme un onglet WooCommerce distinct.
     * La description source reste ainsi strictement intacte et les spécifications
     * ne disparaissent plus lorsqu'elles sont volontairement séparées de post_content.
     */
    public function add_specifications_product_tab($tabs): array {
        if (!is_array($tabs)) $tabs = [];
        $product_id = function_exists('get_queried_object_id') ? (int) get_queried_object_id() : 0;
        if (!$product_id) return $tabs;

        $html = MACE5311_SPI_Attribute_Firewall::sanitize_html((string) get_post_meta($product_id, '_mace5311_spi_specifications_html', true));
        if (trim(wp_strip_all_tags($html)) === '') return $tabs;

        // Le chemin legacy pouvait déjà ajouter le tableau dans la description.
        // Ne jamais l'afficher une seconde fois dans ce cas.
        $description = (string) get_post_field('post_content', $product_id);
        if (strpos($description, 'mace-product-specifications') !== false) return $tabs;

        $tabs['mace_specifications'] = [
            'title'    => __('Caractéristiques', 'mace-smart-product-importer-5311-h5q7'),
            'priority' => 25,
            'callback' => [$this, 'render_specifications_product_tab'],
        ];
        return $tabs;
    }

    public function render_specifications_product_tab(): void {
        $product_id = function_exists('get_queried_object_id') ? (int) get_queried_object_id() : 0;
        if (!$product_id) return;
        $html = MACE5311_SPI_Attribute_Firewall::sanitize_html((string) get_post_meta($product_id, '_mace5311_spi_specifications_html', true));
        if (trim(wp_strip_all_tags($html)) === '') return;
        echo '<div class="mace-specifications-tab" data-mace-specifications="attribute-firewall-v1">' . wp_kses_post($html) . '</div>';
    }


    public function filter_product_attribute_display($rows, $product = null): array {
        return MACE5311_SPI_Attribute_Firewall::sanitize_display_rows(is_array($rows) ? $rows : []);
    }

    public function register_fallback_brand_taxonomy(): void {
        if (taxonomy_exists('product_brand') || taxonomy_exists('pwb-brand') || taxonomy_exists('yith_product_brand') || taxonomy_exists('mace_product_brand')) return;
        register_taxonomy('mace_product_brand', ['product'], [
            'labels' => [
                'name' => 'Marques',
                'singular_name' => 'Marque',
                'menu_name' => 'Marques',
                'add_new_item' => 'Ajouter une marque',
                'edit_item' => 'Modifier la marque',
            ],
            'public' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'hierarchical' => false,
            'rewrite' => ['slug' => 'marque'],
        ]);
    }

    public function enqueue_frontend_styles(): void {
        if (!function_exists('is_product') || !is_product()) return;
        wp_register_style('mace5311-spi-product', false, [], MACE5311_SPI_VERSION);
        wp_enqueue_style('mace5311-spi-product');
        wp_add_inline_style('mace5311-spi-product', '.mace-long-description--readable{line-height:1.62}.mace-long-description--readable p{margin:0 0 .95rem}.mace-long-description--readable h2,.mace-long-description--readable h3,.mace-long-description--readable h4{margin:1.65rem 0 .75rem;line-height:1.35}.mace-long-description--merchant{line-height:1.72}.mace-long-description--merchant p{margin:0 0 1.15rem}.mace-long-description--merchant h2,.mace-long-description--merchant h3,.mace-long-description--merchant h4{margin:2rem 0 .9rem;line-height:1.3}.mace-long-description--merchant ul,.mace-long-description--merchant ol{margin:.5rem 0 1.35rem;padding-left:1.45rem}.mace-long-description--merchant li{margin:.42rem 0;line-height:1.58}.mace-long-description--merchant table{width:100%;border-collapse:collapse;margin:1.4rem 0}.mace-long-description--merchant th,.mace-long-description--merchant td{padding:11px 13px;text-align:left;vertical-align:top;border-bottom:1px solid rgba(0,0,0,.1)}.mace-long-description--merchant th{font-weight:650}.mace-short-description{margin:0 0 1.15rem;line-height:1.65}.mace-short-description__intro{margin:0 0 .85rem}.mace-short-description__highlights{margin:.4rem 0 0;padding-left:1.25rem}.mace-short-description__highlights li{margin:.35rem 0;line-height:1.5}.mace-short-description__highlights strong{font-weight:650}.mace-product-specifications{margin:2rem 0}.mace-product-specifications h3{margin:0 0 1rem}.mace-spec-table-wrap{width:100%;overflow-x:auto}.mace-product-specifications table{width:100%;border-collapse:collapse;margin:0}.mace-product-specifications th,.mace-product-specifications td{padding:12px 14px;text-align:left;vertical-align:top;border-bottom:1px solid rgba(0,0,0,.1)}.mace-product-specifications th{width:38%;font-weight:600}.mace-product-specifications tr:nth-child(odd){background:rgba(0,0,0,.035)}@media(max-width:600px){.mace-product-specifications th,.mace-product-specifications td{display:block;width:100%;box-sizing:border-box}.mace-product-specifications th{padding-bottom:5px}.mace-product-specifications td{padding-top:5px}}');
    }

    public function missing_wc(): void {
        echo '<div class="notice notice-error"><p><strong>MACE Smart Product Importer</strong> nécessite WooCommerce.</p></div>';
    }
}
