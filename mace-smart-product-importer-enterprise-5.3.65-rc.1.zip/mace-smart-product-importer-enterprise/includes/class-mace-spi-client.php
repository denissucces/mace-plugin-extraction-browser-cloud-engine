<?php
defined('ABSPATH') || exit;

final class MACE5311_SPI_Client {
    private $logger;
    public function __construct(MACE5311_SPI_Logger $logger) { $this->logger = $logger; }

    public function fetch(string $raw_url) {
        $url = esc_url_raw(trim($raw_url));
        if (!$url || !wp_http_validate_url($url)) return new WP_Error('invalid_url', 'URL invalide ou non sécurisée.');
        if (!$this->host_allowed($url)) return new WP_Error('host_denied', 'Ce domaine n’est pas autorisé par les réglages MACE.');

        $settings = get_option('mace5311_spi_settings', []);
        $attempts = [];
        $cloud_requested = !empty($settings['cloud_enabled']) && !empty($settings['cloud_url']);

        // La case « Utiliser MACE Cloud » doit réellement établir la liaison : si le nouvel
        // endpoint n'a pas encore de jeton, on l'enregistre avant la première extraction.
        if ($cloud_requested && empty($settings['cloud_token']) && empty($settings['cloud_api_key'])) {
            $registration = $this->register();
            if (is_wp_error($registration)) {
                $attempts[] = $this->attempt('mace-cloud-auth', $registration);
            } else {
                $settings = get_option('mace5311_spi_settings', []);
            }
        }
        $cloud_ready = $cloud_requested && (!empty($settings['cloud_token']) || !empty($settings['cloud_api_key']));

        if ($cloud_ready && !empty($settings['cloud_first'])) {
            $result = $this->cloud($url, $settings);
            if (!is_wp_error($result)) return $this->enrich_cloud_result($url, $settings, $result);
            if ($result->get_error_code() === 'source_access_restricted') {
                $bridge = $this->bridge_create($url);
                if (!is_wp_error($bridge)) return new WP_Error('bridge_required', 'Source protégée : utilisez MACE Browser Bridge, puis reprenez l’import.', $bridge);
            }
            $attempts[] = $this->attempt('mace-cloud', $result);
        }

        $result = $this->autonomous($url, $settings);
        if (!is_wp_error($result)) return $result;
        $attempts = array_merge($attempts, (array) $result->get_error_data());

        if ($cloud_ready && empty($settings['cloud_first'])) {
            $result = $this->cloud($url, $settings);
            if (!is_wp_error($result)) return $result;
            if ($result->get_error_code() === 'source_access_restricted') {
                $bridge = $this->bridge_create($url);
                if (!is_wp_error($bridge)) return new WP_Error('bridge_required', 'Source protégée : utilisez MACE Browser Bridge, puis reprenez l’import.', $bridge);
            }
            $attempts[] = $this->attempt('mace-cloud', $result);
        }

        $message = 'Aucune méthode n’a pu lire complètement la fiche produit.';
        if (!$cloud_ready) $message .= ' Le service MACE Cloud n’est pas encore configuré.';
        return new WP_Error('all_failed', $message, ['attempts' => $attempts]);
    }


    public function capabilities() {
        $settings = get_option('mace5311_spi_settings', []);
        $base = rtrim((string)($settings['cloud_url'] ?? ''), '/');
        if (!$base) return new WP_Error('missing_cloud', 'URL MACE Cloud non configurée.');
        $response = wp_safe_remote_get($base . '/v1/capabilities', ['timeout'=>20,'redirection'=>2,'headers'=>['Accept'=>'application/json','User-Agent'=>'MACE-SPI/' . MACE5311_SPI_VERSION]]);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $json = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200 || !is_array($json) || empty($json['ok'])) return new WP_Error('cloud_capabilities', 'Impossible de lire les capacités MACE Cloud (HTTP ' . $code . ').');
        return $json;
    }

    public function health() {
        $settings = get_option('mace5311_spi_settings', []);
        $base = rtrim((string)($settings['cloud_url'] ?? ''), '/');
        if (!$base) return new WP_Error('missing_cloud', 'URL MACE Cloud non configurée.');
        if (empty($settings['cloud_token']) && empty($settings['cloud_api_key'])) return new WP_Error('missing_key', 'MACE Cloud n’est pas encore activé pour ce site.');

        $response = wp_safe_remote_get($base . '/v1/health', [
            'timeout' => 20,
            'headers' => $this->headers($settings),
            'redirection' => 2,
        ]);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $json = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200 || !is_array($json) || empty($json['ok'])) {
            return new WP_Error('cloud_health', 'MACE Cloud indisponible (HTTP ' . $code . ').');
        }
        return $json;
    }

    private function enrich_cloud_result(string $url, array $settings, array $cloud_result): array {
        $product = is_array($cloud_result['product'] ?? null) ? $cloud_result['product'] : [];
        $missing = $this->missing_enrichment_fields($product);
        if (!$missing) return $cloud_result;

        // Non-régression : un succès Cloud n'est pas considéré comme une réponse exclusive.
        // Si des champs structurants manquent, on tente la page source directement et
        // l'extracteur fusionnera uniquement les valeurs complémentaires non vides.
        $autonomous = $this->autonomous($url, $settings);
        if (is_wp_error($autonomous)) {
            $cloud_result['diagnostics']['local_enrichment'] = [
                'attempted' => true,
                'missing_fields' => $missing,
                'status' => 'unavailable',
                'error' => $autonomous->get_error_message(),
            ];
            return $cloud_result;
        }

        $cloud_result['fallback_html'] = (string)($autonomous['html'] ?? '');
        $cloud_result['fallback_method'] = (string)($autonomous['method'] ?? 'autonomous');
        $cloud_result['diagnostics']['local_enrichment'] = [
            'attempted' => true,
            'missing_fields' => $missing,
            'status' => 'available',
            'method' => $cloud_result['fallback_method'],
            'bytes' => strlen($cloud_result['fallback_html']),
            'golden_route' => 'adaptive-complementary-recovery-v1',
        ];
        return $cloud_result;
    }

    private function missing_enrichment_fields(array $product): array {
        $missing = [];
        foreach (['gtin','brand','regular_price','description','short_description','sku','weight','length','width','height'] as $field) {
            if (trim((string)($product[$field] ?? '')) === '') $missing[] = $field;
        }
        foreach (['images','categories','attributes'] as $field) {
            if (empty($product[$field]) || !is_array($product[$field])) $missing[] = $field;
        }
        return array_values(array_unique($missing));
    }

    private function autonomous(string $url, array $settings) {
        $attempts = [];
        foreach ($this->profiles($url) as $name => $headers) {
            $response = wp_safe_remote_get($url, [
                'timeout' => max(10, min(90, (int)($settings['timeout'] ?? 45))),
                'headers' => $headers,
                'redirection' => 5,
                'limit_response_size' => 8 * 1024 * 1024,
            ]);
            if (is_wp_error($response)) {
                $attempts[] = ['method' => 'autonomous-' . $name, 'error' => $response->get_error_message()];
                continue;
            }
            $code = (int) wp_remote_retrieve_response_code($response);
            $body = (string) wp_remote_retrieve_body($response);
            $type = (string) wp_remote_retrieve_header($response, 'content-type');
            if ($code < 200 || $code >= 300) {
                $attempts[] = ['method' => 'autonomous-' . $name, 'http' => $code, 'error' => 'Réponse HTTP ' . $code];
                continue;
            }
            if ($body === '' || stripos($type, 'text/html') === false) {
                $attempts[] = ['method' => 'autonomous-' . $name, 'http' => $code, 'error' => 'Contenu HTML absent.'];
                continue;
            }
            return [
                'method' => 'autonomous-' . $name,
                'html' => $body,
                'diagnostics' => ['http' => $code, 'content_type' => $type, 'bytes' => strlen($body)],
            ];
        }
        return new WP_Error('autonomous_failed', 'Échec du mode autonome.', $attempts);
    }

    private function cloud(string $url, array $settings) {
        $base = rtrim((string)$settings['cloud_url'], '/');
        $request_id = wp_generate_uuid4();
        $payload = wp_json_encode([
            'request_id' => $request_id,
            'url' => $url,
            'locale' => str_replace('_', '-', get_locale()),
            'max_images' => max(1, min(30, (int)($settings['max_images'] ?? 15))),
            'filtering_policy' => MACE5311_SPI_Content_Firewall::export_filtering_policy(),
        ]);

        $send = function (array $active_settings) use ($base, $request_id, $payload) {
            return wp_safe_remote_post($base . '/v1/extract', [
                'timeout' => max(30, min(120, (int)($active_settings['timeout'] ?? 45) + 30)),
                'headers' => $this->headers($active_settings) + ['Content-Type' => 'application/json', 'X-MACE-Request-ID' => $request_id],
                'body' => $payload,
                'redirection' => 0,
            ]);
        };

        $response = $send($settings);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $json = json_decode(wp_remote_retrieve_body($response), true);

        // Un jeton signé par l'ancien déploiement est normalement invalide sur le nouveau.
        // Sur 401/site_mismatch, on ré-enregistre ce site une seule fois puis on rejoue l'extraction.
        $auth_code = is_array($json) ? (string)($json['error']['code'] ?? '') : '';
        if ($code === 401 && in_array($auth_code, ['unauthorized','site_mismatch'], true)) {
            $registration = $this->register();
            if (!is_wp_error($registration)) {
                $settings = get_option('mace5311_spi_settings', []);
                $response = $send($settings);
                if (is_wp_error($response)) return $response;
                $code = (int) wp_remote_retrieve_response_code($response);
                $json = json_decode(wp_remote_retrieve_body($response), true);
            }
        }

        if (!is_array($json)) return new WP_Error('cloud_invalid_json', 'Réponse MACE Cloud invalide (HTTP ' . $code . ').');
        if ($code !== 200 || empty($json['ok']) || empty($json['product'])) {
            $message = $json['error']['message'] ?? ('Erreur MACE Cloud HTTP ' . $code . '.');
            return new WP_Error($json['error']['code'] ?? 'cloud_error', sanitize_text_field($message), $json['diagnostics'] ?? []);
        }
        return [
            'method' => 'mace-cloud',
            'product' => $json['product'],
            'diagnostics' => $json['diagnostics'] ?? [],
            'request_id' => $json['request_id'] ?? $request_id,
        ];
    }


    public function bridge_create(string $url) {
        $settings = get_option('mace5311_spi_settings', []); $base = rtrim((string)($settings['cloud_url'] ?? ''), '/');
        if (!$base) return new WP_Error('missing_cloud','URL MACE Cloud non configurée.');
        $response = wp_safe_remote_post($base . '/v1/bridge/create', [
            'timeout'=>25,'headers'=>$this->headers($settings)+['Content-Type'=>'application/json'],
            'body'=>wp_json_encode([
                'url'=>$url,
                'filtering_policy'=>MACE5311_SPI_Content_Firewall::export_filtering_policy(),
            ]),'redirection'=>0,
        ]);
        if (is_wp_error($response)) return $response; $code=(int)wp_remote_retrieve_response_code($response); $json=json_decode(wp_remote_retrieve_body($response),true);
        if ($code!==201 || !is_array($json) || empty($json['ok'])) return new WP_Error('bridge_create', sanitize_text_field($json['error']['message'] ?? ('Création Browser Bridge impossible (HTTP '.$code.').')));
        return $json;
    }

    public function bridge_result(string $code) {
        $settings=get_option('mace5311_spi_settings',[]); $base=rtrim((string)($settings['cloud_url']??''),'/');
        $response=wp_safe_remote_get($base.'/v1/bridge/result/'.rawurlencode(strtoupper($code)),['timeout'=>30,'headers'=>$this->headers($settings),'redirection'=>0]);
        if(is_wp_error($response))return $response; $http=(int)wp_remote_retrieve_response_code($response); $json=json_decode(wp_remote_retrieve_body($response),true);
        if($http!==200||!is_array($json)||empty($json['ok']))return new WP_Error('bridge_result',sanitize_text_field($json['error']['message']??('Lecture Browser Bridge impossible (HTTP '.$http.').')));
        if(($json['status']??'')!=='ready')return new WP_Error('bridge_pending','La capture Browser Bridge n’est pas encore prête.',['status'=>$json['status']??'pending']);
        return ['method'=>'browser-bridge','product'=>$json['product'],'diagnostics'=>$json['diagnostics']??[],'request_id'=>'bridge-'.strtoupper($code)];
    }

    public function register() {
        $settings = get_option('mace5311_spi_settings', []);
        $base = rtrim((string)($settings['cloud_url'] ?? ''), '/');
        if (!$base) return new WP_Error('missing_cloud', 'URL MACE Cloud non configurée.');
        $installation_id = sanitize_text_field((string)($settings['installation_id'] ?? ''));
        if (!$installation_id) {
            $installation_id = wp_generate_uuid4();
            $settings['installation_id'] = $installation_id;
        }
        $response = wp_safe_remote_post($base . '/v1/auth/register', [
            'timeout' => 30,
            'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json', 'User-Agent' => 'MACE-SPI/' . MACE5311_SPI_VERSION],
            'body' => wp_json_encode(['site_url' => home_url('/'), 'installation_id' => str_replace('-', '', $installation_id)]),
            'redirection' => 0,
        ]);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $json = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 201 || !is_array($json) || empty($json['ok']) || empty($json['token'])) {
            $message = sanitize_text_field($json['error']['message'] ?? ('Activation MACE Cloud impossible (HTTP ' . $code . ').'));
            if (($json['error']['code'] ?? '') === 'registration_unavailable') {
                $message .= ' Synchronisez le Blueprint Render 5.2.0 RC1 puis vérifiez MACE_TOKEN_SECRET et MACE_ALLOW_PUBLIC_REGISTRATION=true.';
            }
            return new WP_Error('cloud_register', $message, ['http'=>$code,'response'=>$json]);
        }
        $settings['cloud_token'] = sanitize_text_field($json['token']);
        $settings['cloud_token_expires'] = sanitize_text_field($json['expires_at'] ?? '');
        $settings['cloud_enabled'] = 1;
        update_option('mace5311_spi_settings', $settings, false);
        return $json;
    }

    public function verify() {
        $settings = get_option('mace5311_spi_settings', []);
        $base = rtrim((string)($settings['cloud_url'] ?? ''), '/');
        if (!$base) return new WP_Error('missing_cloud', 'URL MACE Cloud non configurée.');
        if (empty($settings['cloud_token']) && empty($settings['cloud_api_key'])) return new WP_Error('missing_key', 'MACE Cloud n’est pas encore activé.');
        $response = wp_safe_remote_post($base . '/v1/auth/verify', [
            'timeout' => 20,
            'headers' => $this->headers($settings) + ['Content-Type' => 'application/json'],
            'body' => wp_json_encode(['site_url' => home_url('/')]),
            'redirection' => 0,
        ]);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $json = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200 || !is_array($json) || empty($json['ok'])) return new WP_Error('cloud_verify', sanitize_text_field($json['error']['message'] ?? ('Vérification MACE Cloud impossible (HTTP ' . $code . ').')));
        return $json;
    }

    private function headers(array $settings): array {
        $credential = trim((string)($settings['cloud_token'] ?? ''));
        if ($credential === '') $credential = trim((string)($settings['cloud_api_key'] ?? ''));
        return [
            'Authorization' => 'Bearer ' . $credential,
            'X-MACE-Site' => untrailingslashit(home_url('/')),
            'Accept' => 'application/json',
            'User-Agent' => 'MACE-SPI/' . MACE5311_SPI_VERSION . '; ' . home_url('/'),
            'X-MACE-Filter-Policy-Hash' => (string)(MACE5311_SPI_Content_Firewall::export_filtering_policy()['policy_hash'] ?? ''),
        ];
    }

    private function profiles(string $url): array {
        $host = (string) wp_parse_url($url, PHP_URL_HOST);
        $base = [
            'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language' => 'fr-FR,fr;q=0.9,en;q=0.7',
            'Cache-Control' => 'no-cache',
            'Referer' => 'https://' . $host . '/',
        ];
        return [
            'wordpress' => $base + ['User-Agent' => 'WordPress/' . get_bloginfo('version') . '; ' . home_url('/')],
            'chrome' => $base + ['User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/127 Safari/537.36'],
            'firefox' => $base + ['User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0'],
        ];
    }

    private function host_allowed(string $url): bool {
        $settings = get_option('mace5311_spi_settings', []);
        $raw = trim((string)($settings['allowed_hosts'] ?? ''));
        if ($raw === '') return true;
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        foreach (array_filter(array_map('trim', preg_split('/[\s,]+/', $raw))) as $allowed) {
            $allowed = strtolower($allowed);
            if ($host === $allowed || substr($host, -strlen('.' . $allowed)) === '.' . $allowed) return true;
        }
        return false;
    }

    private function attempt(string $method, WP_Error $error): array {
        return ['method' => $method, 'error' => $error->get_error_message(), 'data' => $error->get_error_data()];
    }
}
