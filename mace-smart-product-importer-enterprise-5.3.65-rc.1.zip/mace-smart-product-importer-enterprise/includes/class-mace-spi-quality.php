<?php
defined('ABSPATH') || exit;
final class MACE5311_SPI_Quality {
    public function score(array $product): array {
        $weights = ['name'=>15,'regular_price'=>15,'description'=>15,'images'=>20,'sku'=>5,'brand'=>5,'categories'=>10,'attributes'=>10,'stock_status'=>5];
        $score = 0; $missing = []; $found = [];
        foreach ($weights as $key => $weight) {
            $ok = !empty($product[$key]) || ($key === 'stock_status' && isset($product[$key]));
            if ($ok) { $score += $weight; $found[] = $key; } else $missing[] = $key;
        }
        return ['score'=>$score,'missing'=>$missing,'found'=>$found];
    }
}
