<?php
defined('ABSPATH') || exit;
if (!class_exists('MACE5311_SPI_Content_Firewall')) require_once __DIR__ . '/class-mace-spi-content-firewall.php';
if (!class_exists('MACE5311_SPI_Attribute_Firewall')) require_once __DIR__ . '/class-mace-spi-attribute-firewall.php';
if (!class_exists('MACE5311_SPI_Materialization_Firewall')) require_once __DIR__ . '/class-mace-spi-materialization-firewall.php';

final class MACE5311_SPI_Extractor {
    private $price_authority_report = [];
    public function extract(array $fetch, string $url) {
        if (!empty($fetch['product']) && is_array($fetch['product'])) {
            $raw = $fetch['product'];
            $fallback_html = (string)($fetch['fallback_html'] ?? '');
            if ($fallback_html !== '') {
                $raw = $this->merge_raw_products($raw, $this->raw_from_html($fallback_html));
            }
            return MACE5311_SPI_Materialization_Firewall::apply($this->normalize($raw, $url));
        }
        $html = (string)($fetch['html'] ?? '');
        if ($html === '') return new WP_Error('empty_html', 'La page récupérée est vide.');

        $product = $this->raw_from_html($html);
        $product = MACE5311_SPI_Materialization_Firewall::apply($this->normalize($product, $url));
        if (empty($product['name'])) return new WP_Error('no_product', 'Aucun produit structuré n’a été détecté dans la page.');
        return $product;
    }

    private function raw_from_html(string $html): array {
        $product = [];
        $json = $this->jsonld($html);
        if ($json) $product = $json;
        foreach ($this->meta($html) as $key => $value) {
            if ((empty($product[$key]) || $product[$key] === []) && $value !== '' && $value !== []) $product[$key] = $value;
        }
        if (empty($product['gtin'])) {
            $html_gtin = $this->gtin_from_html($html);
            if ($html_gtin !== '') $product['gtin'] = $html_gtin;
        }

        // Standalone Product Reconstruction v4: enrichit les pages lisibles sans Cloud
        // (Shopify et pages HTML classiques) avec galerie, variantes, spécifications
        // et signaux structurés présents dans la fiche elle-même.
        $product = $this->merge_raw_products($product, $this->standalone_enrichment_from_html($html, $product));
        return $product;
    }

    private function standalone_enrichment_from_html(string $html, array $seed = []): array {
        $out = [];
        $title = sanitize_text_field((string)($seed['name'] ?? ''));

        // Shopify expose souvent variant/price/barcode dans un JSON embarqué, même
        // lorsque le JSON-LD est incomplet.
        if (preg_match_all('/\{\s*"id"\s*:\s*\d+.*?"price"\s*:\s*(\d+).*?\}/si', $html, $vm)) {
            foreach ($vm[0] as $blob) {
                $variant = json_decode($blob, true);
                if (!is_array($variant)) continue;
                if (empty($out['regular_price']) && isset($variant['price']) && is_numeric($variant['price'])) { $out['regular_price'] = ((float)$variant['price']) / 100; $out['price_source'] = 'embedded-product-variant-price'; }
                if (empty($out['sku']) && !empty($variant['sku'])) $out['sku'] = sanitize_text_field((string)$variant['sku']);
                if (empty($out['gtin']) && !empty($variant['barcode'])) {
                    $candidate = $this->normalize_gtin_candidate((string)$variant['barcode']);
                    if ($candidate !== '') $out['gtin'] = $candidate;
                }
                if (empty($out['weight']) && isset($variant['weight']) && is_numeric($variant['weight'])) $out['weight'] = ((float)$variant['weight']) / 1000;
                break;
            }
        }

        // Galerie produit : privilégier les médias dont URL/alt recoupe l'identité du
        // produit, et les médias Shopify de la fiche. Les widgets/recommandations sont
        // exclus par contexte lexical.
        $images = [];
        if (class_exists('DOMDocument')) {
            $dom = new DOMDocument();
            libxml_use_internal_errors(true);
            @$dom->loadHTML('<?xml encoding="utf-8" ?>'.$html);
            libxml_clear_errors();
            $xpath = new DOMXPath($dom);
            $title_tokens = array_values(array_filter(preg_split('/[^\p{L}0-9]+/u', mb_strtolower($title)), fn($x)=>mb_strlen($x)>=3));
            foreach ($xpath->query('//img[@src or @data-src or @srcset]') as $img) {
                $src = trim((string)($img->getAttribute('src') ?: $img->getAttribute('data-src')));
                if ($src === '' && $img->getAttribute('srcset')) $src = trim(explode(' ', explode(',', $img->getAttribute('srcset'))[0])[0]);
                if ($src === '') continue;
                $alt = mb_strtolower(trim((string)$img->getAttribute('alt')));
                $probe = mb_strtolower($src.' '.$alt);
                $ctx = ''; $node = $img->parentNode;
                for ($i=0; $node && $i<4; $i++, $node=$node->parentNode) $ctx .= ' '.mb_strtolower(trim((string)$node->textContent));
                if (preg_match('/related|recommend|similar|you may also like|recent|review|footer|header|logo|avatar|payment|banner/u', $ctx)) continue;
                $match = false;
                foreach ($title_tokens as $tok) if (mb_strpos($probe, $tok) !== false) { $match = true; break; }
                if (strpos($probe, 'cdn.shopify.com') !== false && preg_match('/product|kukirin|g2|master|files\//u', $probe)) $match = true;
                if ($match) $images[] = esc_url_raw(html_entity_decode($src, ENT_QUOTES|ENT_HTML5, 'UTF-8'));
            }
        }
        if ($images) $out['images'] = array_values(array_unique(array_filter($images)));

        // Spécifications simples « libellé : valeur » visibles dans la fiche.
        $attrs = [];
        $plain = html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES|ENT_HTML5, 'UTF-8');
        foreach (preg_split('/[\r\n]+/u', $plain) as $line) {
            $line = trim(preg_replace('/\s{2,}/u',' ', $line));
            if (!preg_match('/^([^:：]{2,80})[:：]\s*(.{1,240})$/u', $line, $m)) continue;
            $label = sanitize_text_field(trim($m[1])); $value = sanitize_text_field(trim($m[2]));
            if ($label === '' || $value === '' || $this->is_commerce_noise_attribute($label, $value)) continue;
            if (preg_match('/^(battery|max speed|dual motor|speed level|max range|max load|charging time|waterproof level|brake system|net weight|expend size|fold size|packing size)$/i', $label)) {
                $map = [
                    'battery'=>'Batterie','max speed'=>'Vitesse maximale','dual motor'=>'Motorisation','speed level'=>'Niveaux de vitesse',
                    'max range'=>'Autonomie maximale','max load'=>'Charge maximale','charging time'=>'Temps de charge',
                    'waterproof level'=>'Indice de protection','brake system'=>'Système de freinage','net weight'=>'Poids du produit',
                    'expend size'=>'Dimensions dépliées','fold size'=>'Dimensions pliées','packing size'=>'Dimensions emballage'
                ];
                $label = $map[strtolower($label)] ?? $label;
            }
            $attrs[$label] = $value;
        }
        if ($attrs) $out['attributes'] = $attrs;
        return $out;
    }

    private function gtin_from_html(string $html): string {
        // Microdata/itemprop explicite.
        if (preg_match('/<[^>]+itemprop=["\'](?:gtin14|gtin13|gtin12|gtin8|gtin|ean|upc)["\'][^>]+(?:content|value)=["\']([^"\']+)["\']/iu', $html, $m)
            || preg_match('/<[^>]+(?:content|value)=["\']([^"\']+)["\'][^>]+itemprop=["\'](?:gtin14|gtin13|gtin12|gtin8|gtin|ean|upc)["\']/iu', $html, $m)) {
            $candidate = $this->normalize_gtin_candidate($m[1]);
            if ($candidate !== '') return $candidate;
        }

        // Caractéristique visible : EAN : 1234567890123, Code EAN, GTIN, UPC, etc.
        $text = html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/(?:EAN(?:[-\s]?13)?|GTIN(?:[-\s]?(?:8|12|13|14))?|UPC(?:[-\s]?A)?|code\s*(?:EAN|barres?)|barcode)\s*[:#-]?\s*((?:\d[\s.\-]?){7,13}\d)/iu', $text, $m)) {
            return $this->normalize_gtin_candidate($m[1]);
        }
        return '';
    }

    private function merge_raw_products(array $primary, array $fallback): array {
        // Price Candidate Ledger v1: unlike ordinary fields, price is never merged as
        // a simple non-empty scalar. Preserve both Cloud and autonomous candidates with
        // their provenance so a weak CTA/financing value cannot hide a stronger same-page
        // Product Offer recovered during additive enrichment.
        $price_candidates = [];
        $append_price_candidate = static function (&$list, array $node, string $origin): void {
            $amount = $node['regular_price'] ?? '';
            if ($amount === '' || $amount === null) return;
            $source = (string)($node['price_source'] ?? ($node['primary_price_source'] ?? ($node['regular_price_source'] ?? '')));
            $list[] = ['amount'=>(string)$amount, 'source'=>$source, 'origin'=>$origin];
        };
        $append_price_candidate($price_candidates, $primary, 'primary');
        $append_price_candidate($price_candidates, $fallback, 'autonomous_fallback');
        foreach ((array)($primary['price_candidates'] ?? []) as $candidate) if (is_array($candidate)) $price_candidates[] = $candidate;
        foreach ((array)($fallback['price_candidates'] ?? []) as $candidate) if (is_array($candidate)) $price_candidates[] = $candidate;
        if ($price_candidates) $primary['price_candidates'] = $price_candidates;

        // Le Cloud reste l'autorité principale for ordinary fields. Le mode autonome ne remplit que les
        // champs absents afin d'éviter toute régression lorsqu'une méthode possède
        // une preuve que l'autre n'a pas (notamment EAN/GTIN).
        foreach ($fallback as $key => $value) {
            if ($value === '' || $value === [] || $value === null) continue;
            if (!array_key_exists($key, $primary) || $primary[$key] === '' || $primary[$key] === [] || $primary[$key] === null) {
                $primary[$key] = $value;
            }
        }
        return $primary;
    }

    private function jsonld(string $html): array {
        if (!preg_match_all('~<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>~is', $html, $matches)) return [];
        foreach ($matches[1] as $raw) {
            $decoded = json_decode(html_entity_decode(trim($raw), ENT_QUOTES | ENT_HTML5, 'UTF-8'), true);
            $product = $this->find_product($decoded);
            if (!$product) continue;
            $offer = $product['offers'] ?? [];
            if (isset($offer[0])) $offer = $offer[0];
            $brand = is_array($product['brand'] ?? null) ? ($product['brand']['name'] ?? '') : ($product['brand'] ?? '');
            return [
                'name' => $product['name'] ?? '',
                'description' => $product['description'] ?? '',
                'sku' => $product['sku'] ?? ($product['mpn'] ?? ''),
                'gtin' => $product['gtin14'] ?? ($product['gtin13'] ?? ($product['gtin12'] ?? ($product['gtin8'] ?? ($product['gtin'] ?? ($product['ean'] ?? ($product['upc'] ?? '')))))),
                'brand' => $brand,
                'regular_price' => $offer['price'] ?? ($offer['lowPrice'] ?? ''),
                'price_source' => !empty($offer['price']) || !empty($offer['lowPrice']) ? 'json-ld-product-offer' : '',
                'currency' => $offer['priceCurrency'] ?? '',
                'stock_status' => stripos((string)($offer['availability'] ?? ''), 'outofstock') !== false ? 'outofstock' : 'instock',
                'images' => $product['image'] ?? [],
                'attributes' => $product['additionalProperty'] ?? [],
                'weight' => is_array($product['weight'] ?? null) ? ($product['weight']['value'] ?? '') : ($product['weight'] ?? ''),
            ];
        }
        return [];
    }

    private function find_product($node) {
        if (!is_array($node)) return null;
        $type = $node['@type'] ?? null;
        if ($type === 'Product' || (is_array($type) && in_array('Product', $type, true))) return $node;
        foreach ($node as $value) if (is_array($value) && ($product = $this->find_product($value))) return $product;
        return null;
    }

    private function meta(string $html): array {
        $get = static function (string $key) use ($html): string {
            $q = preg_quote($key, '~');
            if (preg_match('~<meta[^>]+(?:property|name)=["\']' . $q . '["\'][^>]+content=["\']([^"\']*)~i', $html, $m) ||
                preg_match('~<meta[^>]+content=["\']([^"\']*)["\'][^>]+(?:property|name)=["\']' . $q . '["\']~i', $html, $m)) {
                return html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }
            return '';
        };
        return [
            'name' => $get('og:title'),
            'description' => $get('og:description'),
            'short_description' => $get('description'),
            'regular_price' => $get('product:price:amount'),
            'price_source' => $get('product:price:amount') !== '' ? 'open-graph-product-price' : '',
            'currency' => $get('product:price:currency'),
            'images' => array_filter([$get('og:image')]),
        ];
    }

    private function energy_grade_value($value): string {
        $value = trim(wp_strip_all_tags((string)$value));
        if (preg_match('/(?:Category|Categorie)([A-G](?:\+{1,3})?)\b/i', $value, $m)) return strtoupper($m[1]);
        if (preg_match('/^([A-G](?:\+{1,3})?)$/i', $value, $m)) return strtoupper($m[1]);
        return '';
    }

    private function energy_letter_value($value): string {
        $grade = $this->energy_grade_value($value);
        return $grade !== '' ? substr($grade, 0, 1) : '';
    }

    private function collect_multimode_energy_evidence(array $raw, string $name = ''): array {
        $out = ['cooling'=>'', 'heating'=>'', 'source'=>'', 'confidence'=>0, 'locked'=>false];
        // 5.3.65 Evidence-to-Woo contract: a local title/presentation pair must never
        // recreate operational modes that Cloud explicitly quarantined. This is the
        // precise last-mile failure observed on the Samsung AR35 A++/A case.
        if (MACE5311_SPI_Materialization_Firewall::has_contract($raw)) {
            $cool_state = MACE5311_SPI_Materialization_Firewall::field_state($raw, 'energy_class_cooling');
            $heat_state = MACE5311_SPI_Materialization_Firewall::field_state($raw, 'energy_class_heating');
            if (MACE5311_SPI_Materialization_Firewall::is_blocked_state($cool_state) || MACE5311_SPI_Materialization_Firewall::is_blocked_state($heat_state)) {
                return ['cooling'=>'', 'heating'=>'', 'source'=>'cloud_materialization_quarantine', 'confidence'=>1, 'locked'=>false];
            }
        }
        $strings = [$name];
        $walk = function($node, int $depth = 0) use (&$walk, &$strings) {
            if ($depth > 7) return;
            if (is_array($node)) { foreach ($node as $v) $walk($v, $depth + 1); return; }
            if (!is_string($node) || strlen($node) > 1500000) return;
            if (stripos($node, 'classe') !== false || stripos($node, 'energy') !== false || stripos($node, 'refroid') !== false || stripos($node, 'chauff') !== false) $strings[] = $node;
        };
        $walk($raw);
        foreach ($strings as $source) {
            $plain = trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags((string)$source), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
            if ($plain === '') continue;
            $patterns = [
                '/classe\s+(?:d[’\']?efficacit[eé]\s+)?[eé]nerg[eé]tique\s*[:\-]?\s*([A-G](?:\+{1,3})?)\s+(?:en\s+)?refroidissement\s*[,;\/]?\s*(?:et\s*)?([A-G](?:\+{1,3})?)\s+(?:en\s+)?chauffage/iu',
                '/energy\s+(?:efficiency\s+)?class\s*[:\-]?\s*([A-G](?:\+{1,3})?)\s+(?:in\s+)?cooling\s*[,;\/]?\s*(?:and\s*)?([A-G](?:\+{1,3})?)\s+(?:in\s+)?heating/iu',
            ];
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $plain, $m)) {
                    $out = ['cooling'=>strtoupper($m[1]), 'heating'=>strtoupper($m[2]), 'source'=>'exact_labeled_multimode_pair', 'confidence'=>1, 'locked'=>true];
                    return $out;
                }
            }
            // Explicit label/value pairs can be separate in tables or specification arrays.
            $cool=''; $heat='';
            if (preg_match('/classe\s+(?:d[’\']?efficacit[eé]\s+)?[eé]nerg[eé]tique\s*\(?\s*(?:mode\s+)?refroidissement\s*\)?\s*[:=\-]?\s*([A-G](?:\+{1,3})?)/iu', $plain, $m)) $cool=strtoupper($m[1]);
            if (preg_match('/classe\s+(?:d[’\']?efficacit[eé]\s+)?[eé]nerg[eé]tique\s*\(?\s*(?:mode\s+)?chauffage\s*\)?\s*[:=\-]?\s*([A-G](?:\+{1,3})?)/iu', $plain, $m)) $heat=strtoupper($m[1]);
            if ($cool !== '') $out['cooling']=$cool;
            if ($heat !== '') $out['heating']=$heat;
            if ($out['cooling'] !== '' && $out['heating'] !== '') {
                $out['source']='separate_labeled_multimode_pairs'; $out['confidence']=1; $out['locked']=true; return $out;
            }
        }
        // A title such as A++/A is only interpreted as cooling/heating when the product identity itself is HVAC-related.
        $titlePlain = trim(wp_strip_all_tags($name));
        if (preg_match('/(?:climatiseur|climatisation|air\s*conditioner|heat\s*pump)/iu', $titlePlain) && preg_match('/\b([A-G](?:\+{1,3})?)\s*\/\s*([A-G](?:\+{1,3})?)\b/i', $titlePlain, $m)) {
            return ['cooling'=>strtoupper($m[1]), 'heating'=>strtoupper($m[2]), 'source'=>'hvac_title_pair', 'confidence'=>0.9, 'locked'=>true];
        }
        return $out;
    }

    private function energy_class_from_title(string $name): string {
        $plain = trim(wp_strip_all_tags($name));
        if (preg_match('/\bclasse(?:\s+(?:d[’\']?efficacit[eé]|[eé]nerg[eé]tique))?\s*[:\-]?\s*([A-G])\b/iu', $plain, $m)) return strtoupper($m[1]);
        if (preg_match('/\benergy\s+(?:efficiency\s+)?class\s*[:\-]?\s*([A-G])\b/iu', $plain, $m)) return strtoupper($m[1]);
        return '';
    }

    private function collect_nested_energy_mode_evidence(array $raw): array {
        $out = ['default'=>[], 'sdr'=>[], 'hdr'=>[], 'certificates'=>[]];
        $seen = [];
        $walk = function($node, string $path = 'root', int $depth = 0) use (&$walk, &$out, &$seen) {
            if ($depth > 8 || !is_array($node)) return;
            // Decision/telemetry objects are not raw source evidence and must never vote
            // in the energy authority resolver. They can contain keys named energy_class
            // whose values are structured decision nodes rather than scalar grades.
            if (preg_match('/(?:^|\.)(?:materialization_contract|universal_materialization_firewall_report|materialization_firewall_report)(?:\.|$)/', $path)) return;
            $oid = md5($path . '|' . serialize(array_keys($node)));
            if (isset($seen[$oid])) return; $seen[$oid] = true;
            $push = static function(array &$bucket, string $value, string $source, int $score) {
                $v = strtoupper(trim($value));
                if (!preg_match('/^[A-G]$/', $v)) return;
                $bucket[] = ['value'=>$v,'source'=>$source,'score'=>$score];
            };
            $isCert = isset($node['default_class']) || isset($node['generic_class']) || isset($node['energy_class_default']);
            if ($isCert) {
                $default = (string)($node['default_class'] ?? $node['generic_class'] ?? $node['energy_class_default'] ?? '');
                $sdr = (string)($node['sdr_class'] ?? $node['energy_class_sdr'] ?? '');
                $hdr = (string)($node['hdr_class'] ?? $node['energy_class_hdr'] ?? '');
                $push($out['default'], $default !== '' ? $default : $sdr, $path.':energy_truth_certificate_default', 390);
                $push($out['sdr'], $sdr, $path.':energy_truth_certificate_sdr', 400);
                $push($out['hdr'], $hdr, $path.':energy_truth_certificate_hdr', 400);
                $out['certificates'][] = ['path'=>$path,'default'=>$default,'sdr'=>$sdr,'hdr'=>$hdr,'version'=>(string)($node['version'] ?? '')];
            }
            $generic = (string)($node['energy_class'] ?? $node['energy_efficiency_class'] ?? $node['energy_rating'] ?? '');
            $sdr = (string)($node['energy_class_sdr'] ?? $node['sdr_energy_class'] ?? '');
            $hdr = (string)($node['energy_class_hdr'] ?? $node['hdr_energy_class'] ?? '');
            // Only treat a generic value as authoritative when the same object also carries
            // mode-aware evidence or explicitly says it is Browser/rendered/product-zone evidence.
            $pathNorm = strtolower($path.' '.(string)($node['source'] ?? '').' '.(string)($node['version'] ?? ''));
            $modeAware = $sdr !== '' || $hdr !== '' || preg_match('/browser|bridge|rendered|product.zone|sustainability|energy.truth|certificate/', $pathNorm);
            if ($modeAware) {
                $push($out['default'], $generic, $path.':nested_generic', 360);
                $push($out['sdr'], $sdr, $path.':nested_sdr', 370);
                $push($out['hdr'], $hdr, $path.':nested_hdr', 370);
            }
            foreach ($node as $k=>$v) if (is_array($v)) $walk($v, $path.'.'.$k, $depth+1);
        };
        $walk($raw);
        foreach (['default','sdr','hdr'] as $k) {
            usort($out[$k], static fn($a,$b)=>($b['score']<=>$a['score']));
            $uniq=[]; $filtered=[];
            foreach ($out[$k] as $row) { $key=$row['value'].'|'.$row['source']; if(isset($uniq[$key]))continue; $uniq[$key]=1; $filtered[]=$row; }
            $out[$k]=$filtered;
        }
        return $out;
    }

    private function collect_exact_energy_pairs_from_payload(array $raw): array {
        $out = ['default'=>[], 'sdr'=>[], 'hdr'=>[]];
        $seen = [];
        $push = function(string $label, string $value, string $source, int $score) use (&$out, &$seen) {
            $role = MACE5311_SPI_Attribute_Firewall::energy_semantic_role($label);
            $letter = $this->energy_letter_value($value);
            if ($letter === '' || in_array($role, ['scale_min','scale_max','none'], true)) return;
            $bucket = $role === 'hdr_class' ? 'hdr' : ($role === 'sdr_class' ? 'sdr' : 'default');
            $embedded = MACE5311_SPI_Attribute_Firewall::embedded_energy_letter($label);
            if ($embedded !== '' && $embedded !== $letter) return;
            $key = $bucket.'|'.$letter.'|'.strtolower(trim(wp_strip_all_tags($label)));
            if (isset($seen[$key])) return; $seen[$key] = true;
            $out[$bucket][] = ['value'=>$letter,'source'=>$source,'score'=>$score,'label'=>trim(wp_strip_all_tags($label))];
        };
        $walk = function($node, string $path='root', int $depth=0) use (&$walk, $push) {
            if ($depth > 7) return;
            if (preg_match('/(?:^|\.)(?:materialization_contract|universal_materialization_firewall_report|materialization_firewall_report)(?:\.|$)/', $path)) return;
            if (is_array($node)) {
                foreach ($node as $k=>$v) $walk($v, $path.'.'.$k, $depth+1);
                return;
            }
            if (!is_string($node) || strlen($node) < 8 || strlen($node) > 2500000) return;
            $src = $node;
            // Exact HTML table/dl rows are the strongest raw source proof.
            if (stripos($src, '<') !== false) {
                if (preg_match_all('~<(?:tr)[^>]*>\\s*<(?:th|td)[^>]*>(.*?)</(?:th|td)>\\s*<(?:th|td)[^>]*>(.*?)</(?:th|td)>[\\s\\S]*?</tr>~iu', $src, $rows, PREG_SET_ORDER)) {
                    foreach ($rows as $r) $push(wp_strip_all_tags($r[1]), wp_strip_all_tags($r[2]), $path.':raw_table_pair', 430);
                }
                if (preg_match_all('~<dt[^>]*>(.*?)</dt>\\s*<dd[^>]*>(.*?)</dd>~iu', $src, $rows, PREG_SET_ORDER)) {
                    foreach ($rows as $r) $push(wp_strip_all_tags($r[1]), wp_strip_all_tags($r[2]), $path.':raw_dl_pair', 425);
                }
            }
            // Conservative plain-text adjacency fallback for exact energy labels only.
            $plain = trim(preg_replace('/\\s+/u', ' ', wp_strip_all_tags($src)));
            if ($plain !== '' && preg_match_all('/(Classe\\s+(?:d[’\']?efficacit[eé]\\s+)?[eé]nerg[eé]tique(?:\\s*\\(\\s*mode\\s+(?:HDR|SDR)\\s*\\))?)\\s*[:=\\-]?\\s*([A-G])\\b/iu', $plain, $rows, PREG_SET_ORDER)) {
                foreach ($rows as $r) $push($r[1], $r[2], $path.':raw_text_pair', 410);
            }
        };
        $walk($raw);
        foreach ($out as &$bucket) usort($bucket, static fn($a,$b)=>($b['score']<=>$a['score']));
        unset($bucket);
        return $out;
    }

    private function energy_mode_candidates(array $raw, array $attributes): array {
        $out = ['default'=>[], 'sdr'=>[], 'hdr'=>[]];
        $push = static function (&$bucket, string $value, string $source, int $score) {
            $v = strtoupper(trim($value));
            if (!preg_match('/^[A-G]$/', $v)) return;
            $bucket[] = ['value'=>$v,'source'=>$source,'score'=>$score];
        };
        $pairs = [];
        foreach ((array)($raw['specifications'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $pairs[] = [(string)($row['label'] ?? ($row['name'] ?? '')), (string)($row['value'] ?? '')];
        }
        foreach ((array)($raw['attributes'] ?? []) as $k => $v) {
            if (is_array($v) && isset($v['name'])) $pairs[] = [(string)$v['name'], (string)($v['value'] ?? '')];
            elseif (!is_array($v)) $pairs[] = [(string)$k, (string)$v];
        }
        foreach ($pairs as [$label,$value]) {
            $role = MACE5311_SPI_Attribute_Firewall::energy_semantic_role($label);
            $letter = $this->energy_letter_value($value);
            if ($letter === '') continue;
            $embedded = MACE5311_SPI_Attribute_Firewall::embedded_energy_letter($label);
            if ($embedded !== '' && $embedded !== $letter) continue;
            if ($role === 'product_class') $push($out['default'], $letter, 'exact_source_product_class', 330);
            elseif ($role === 'sdr_class') $push($out['sdr'], $letter, 'exact_source_sdr_class', 350);
            elseif ($role === 'hdr_class') $push($out['hdr'], $letter, 'exact_source_hdr_class', 350);
        }
        $rendered = is_array($raw['rendered_sustainability_evidence'] ?? null) ? $raw['rendered_sustainability_evidence'] : [];
        $nestedModes = $this->collect_nested_energy_mode_evidence($raw);
        $exactPairs = $this->collect_exact_energy_pairs_from_payload($raw);
        foreach ($exactPairs['default'] as $row) $push($out['default'], $row['value'], $row['source'], $row['score']);
        foreach ($exactPairs['sdr'] as $row) $push($out['sdr'], $row['value'], $row['source'], $row['score']);
        foreach ($exactPairs['hdr'] as $row) $push($out['hdr'], $row['value'], $row['source'], $row['score']);
        foreach ($nestedModes['default'] as $row) $push($out['default'], $row['value'], $row['source'], $row['score']);
        foreach ($nestedModes['sdr'] as $row) $push($out['sdr'], $row['value'], $row['source'], $row['score']);
        foreach ($nestedModes['hdr'] as $row) $push($out['hdr'], $row['value'], $row['source'], $row['score']);
        $letter = $this->energy_letter_value($rendered['energy_class_sdr'] ?? '');
        if ($letter !== '') $push($out['sdr'], $letter, 'browser_rendered_sdr', 340);
        $letter = $this->energy_letter_value($rendered['energy_class'] ?? '');
        if ($letter !== '') $push($out['default'], $letter, 'browser_rendered_default', 320);
        $letter = $this->energy_letter_value($rendered['energy_class_hdr'] ?? '');
        if ($letter !== '') $push($out['hdr'], $letter, 'browser_rendered_hdr', 340);
        foreach (['energy_class_sdr','sdr_energy_class'] as $field) {
            $letter = $this->energy_letter_value($raw[$field] ?? ''); if ($letter !== '') $push($out['sdr'], $letter, $field, 310);
        }
        foreach (['energy_class_hdr','hdr_energy_class'] as $field) {
            $letter = $this->energy_letter_value($raw[$field] ?? ''); if ($letter !== '') $push($out['hdr'], $letter, $field, 310);
        }
        $letter = $this->energy_letter_value($attributes['Classe énergétique'] ?? '');
        if ($letter !== '') $push($out['default'], $letter, 'sanitized_default_attribute', 260);
        $letter = $this->energy_letter_value($attributes['Classe énergétique (mode HDR)'] ?? '');
        if ($letter !== '') $push($out['hdr'], $letter, 'sanitized_hdr_attribute', 260);
        foreach ($out as &$bucket) usort($bucket, static fn($a,$b)=>($b['score']<=>$a['score']));
        unset($bucket);
        return $out;
    }

    private function resolve_energy_truth_authority(array $raw, array $attributes, string $name): array {
        $title = $this->energy_class_from_title($name);
        $modes = $this->energy_mode_candidates($raw, $attributes);
        $mode_default = $modes['sdr'][0] ?? ($modes['default'][0] ?? null);
        $mode_hdr = $modes['hdr'][0] ?? null;
        $cloud = is_array($raw['energy_truth_authority_v2'] ?? null) ? $raw['energy_truth_authority_v2'] : [];
        $cloud_winner = $this->energy_letter_value($cloud['winner'] ?? '');
        $cloud_locked = !empty($cloud['locked']) && $cloud_winner !== '';
        $reg = is_array($raw['regulatory_product_authority_report']['energy_class'] ?? null) ? $raw['regulatory_product_authority_report']['energy_class'] : [];
        $reg_winner = $this->energy_letter_value($reg['winner'] ?? '');
        $reg_locked = !empty($reg['locked']) && $reg_winner !== '';
        $locked_winner = $cloud_locked ? $cloud_winner : ($reg_locked ? $reg_winner : '');

        // Two independent locked direct truths may never be silently reconciled.
        if ($locked_winner !== '' && $title !== '' && $locked_winner !== $title) {
            return ['', ['version'=>'plugin-energy-truth-authority-v1','locked'=>false,'reason'=>'direct_locked_cloud_title_conflict','cloud'=>$locked_winner,'title'=>$title,'fail_closed'=>true]];
        }
        if ($locked_winner !== '') {
            // A legacy Cloud winner that conflicts with stronger explicit SDR/default source evidence
            // is not allowed to override another mode (e.g. HDR G over SDR D).
            if ($mode_default && $mode_default['value'] !== $locked_winner && ($mode_default['score'] ?? 0) >= 320) {
                return [$mode_default['value'], ['version'=>'plugin-energy-mode-authority-v3-certificate','locked'=>true,'winner'=>$mode_default['value'],'source'=>$mode_default['source'],'rejected_legacy_cloud_winner'=>$locked_winner,'hdr'=>$mode_hdr['value'] ?? '','mode_separation'=>true]];
            }
            return [$locked_winner, ['version'=>'plugin-energy-mode-authority-v3-certificate','locked'=>true,'winner'=>$locked_winner,'source'=>'cloud_locked_energy_truth','title'=>$title,'hdr'=>$mode_hdr['value'] ?? '','mode_separation'=>true]];
        }
        if ($title !== '' && (!$mode_default || ($mode_default['score'] ?? 0) < 320)) {
            return [$title, ['version'=>'plugin-energy-mode-authority-v3-certificate','locked'=>true,'winner'=>$title,'source'=>'exact_product_title','score'=>260,'hdr'=>$mode_hdr['value'] ?? '','mode_separation'=>true]];
        }
        if ($title !== '' && $mode_default && $mode_default['value'] !== $title && ($mode_default['score'] ?? 0) >= 320) {
            return ['', ['version'=>'plugin-energy-mode-authority-v3-certificate','locked'=>false,'reason'=>'direct_title_source_conflict','title'=>$title,'source_winner'=>$mode_default['value'],'source'=>$mode_default['source'],'fail_closed'=>true,'hdr'=>$mode_hdr['value'] ?? '','mode_separation'=>true]];
        }
        if ($mode_default) {
            $bounds = $this->energy_scale_bound_values($raw, $attributes);
            $source = (string)($mode_default['source'] ?? '');
            $score = (int)($mode_default['score'] ?? 0);
            $direct = $score >= 380 || preg_match('/browser_rendered|energy_truth_certificate|raw_(?:table|dl|text)_pair|product_zone/i', $source);
            if (in_array($mode_default['value'], $bounds, true) && !$direct) {
                return ['', ['version'=>'plugin-energy-existence-gate-v1','locked'=>false,'reason'=>'ambiguous_scale_bound_alias','candidate'=>$mode_default['value'],'bounds'=>$bounds,'source'=>$source,'fail_closed'=>true]];
            }
            if ($score >= 320 || $direct) {
                return [$mode_default['value'], ['version'=>'plugin-energy-mode-authority-v4-existence-gate','locked'=>true,'winner'=>$mode_default['value'],'source'=>$source,'score'=>$score,'hdr'=>$mode_hdr['value'] ?? '','mode_separation'=>true]];
            }
        }
        if ($title !== '') {
            return [$title, ['version'=>'plugin-energy-mode-authority-v4-existence-gate','locked'=>true,'winner'=>$title,'source'=>'exact_product_title','score'=>260,'hdr'=>$mode_hdr['value'] ?? '','mode_separation'=>true]];
        }
        return ['', ['version'=>'plugin-energy-existence-gate-v1','locked'=>false,'reason'=>'no_direct_product_class_proof','scale_bounds_vote'=>false,'fail_closed'=>true]];
    }

    private function energy_scale_bound_values(array $raw, array $attributes): array {
        $out = [];
        foreach ($attributes as $label => $value) {
            $role = MACE5311_SPI_Attribute_Firewall::energy_semantic_role((string)$label);
            if (!in_array($role, ['scale_min','scale_max'], true)) continue;
            $letter = $this->energy_letter_value($value);
            if ($letter !== '') $out[] = $letter;
        }
        foreach ((array)($raw['specifications'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $label = (string)($row['label'] ?? ($row['name'] ?? ''));
            $role = MACE5311_SPI_Attribute_Firewall::energy_semantic_role($label);
            if (!in_array($role, ['scale_min','scale_max'], true)) continue;
            $letter = $this->energy_letter_value($row['value'] ?? '');
            if ($letter !== '') $out[] = $letter;
        }
        return array_values(array_unique($out));
    }

    private function resolve_source_title_authority(array $raw, string $url, string $fallback): string {
        $candidates = [];
        $push = function($value, int $score, string $source) use (&$candidates) {
            $value = sanitize_text_field((string)$value);
            if ($value === '' || strlen($value) < 6 || strlen($value) > 520) return;
            $candidates[] = ['value'=>$value,'score'=>$score,'source'=>$source];
        };
        $walk = function($node, string $path='root', int $depth=0) use (&$walk, $push) {
            if ($depth > 7 || !is_array($node)) return;
            if (isset($node['source_title_certificate']) && is_array($node['source_title_certificate'])) {
                $c = $node['source_title_certificate'];
                $push($c['visible_h1'] ?? ($c['title'] ?? ''), !empty($c['locked']) ? 500 : 450, $path.'.source_title_certificate');
            }
            if (isset($node['rendered_identity_evidence']) && is_array($node['rendered_identity_evidence'])) {
                $push($node['rendered_identity_evidence']['title_text'] ?? '', 430, $path.'.rendered_identity_evidence');
            }
            if (isset($node['bridge_identity_evidence']) && is_array($node['bridge_identity_evidence'])) {
                $push($node['bridge_identity_evidence']['title'] ?? '', 420, $path.'.bridge_identity_evidence');
            }
            foreach ($node as $k=>$v) if (is_array($v)) $walk($v, $path.'.'.$k, $depth+1);
        };
        $walk($raw);
        $push($fallback, 250, 'raw_name');
        if (!$candidates) return $fallback;
        $identityTokens = [];
        $probe = strtolower($url.' '.$fallback);
        if (preg_match_all('/[a-z0-9]{5,}/i', $probe, $m)) {
            foreach ($m[0] as $t) if (preg_match('/[a-z]/i',$t) && preg_match('/\d/',$t)) $identityTokens[] = strtolower($t);
        }
        foreach ($candidates as &$c) {
            $n = strtolower($c['value']);
            foreach (array_unique($identityTokens) as $t) if (strpos($n,$t)!==false) $c['score'] += 80;
        }
        unset($c);
        usort($candidates, static fn($a,$b)=>$b['score']<=>$a['score']);
        return $candidates[0]['value'];
    }

    private function synchronize_energy_html(string $html, string $winner): string {
        if ($winner === '' || trim($html) === '') return $html;
        // Explicit product-class claims only. Max/min/scale/range rows are deliberately untouched.
        $html = preg_replace_callback(
            '~((?:classe\s+(?:(?:d[’\']?)?efficacit[eé]\s+)?[eé]nerg[eé]tique|energy\s+(?:efficiency\s+)?class))(?!\s*(?:max|min|maximum|minimum|echelle|échelle|scale|plage|range))\s*(?:est|is|de|of|:|-|=)?\s*([A-G])\b~iu',
            static function ($m) use ($winner) { return $m[1] . ' : ' . $winner; },
            $html
        );
        $html = preg_replace(
            '~(<(?:dt|th)[^>]*>\s*Classe\s+[eé]nerg[eé]tique\s*</(?:dt|th)>\s*<(?:dd|td)[^>]*>\s*)[A-G](\s*</(?:dd|td)>)~iu',
            '$1' . $winner . '$2',
            $html
        );
        return (string)$html;
    }

    private function synchronize_energy_rows(array $rows, string $winner): array {
        if ($winner === '') return $rows;
        foreach ($rows as &$row) {
            if (!is_array($row)) continue;
            $label = (string)($row['label'] ?? ($row['name'] ?? ''));
            if (MACE5311_SPI_Attribute_Firewall::energy_semantic_role($label) === 'product_class') $row['value'] = $winner;
        }
        unset($row);
        return $rows;
    }

    private function normalize(array $raw, string $url): array {
        $attributes = [];
        foreach ((array)($raw['attributes'] ?? []) as $key => $value) {
            if (is_array($value) && isset($value['name'])) {
                $name = sanitize_text_field((string)$value['name']);
                $val = sanitize_text_field((string)($value['value'] ?? ''));
            } elseif (!is_array($value)) {
                $name = sanitize_text_field((string)$key);
                $val = sanitize_text_field((string)$value);
            } else continue;
            if ($name !== '' && $val !== '' && !$this->is_commerce_noise_attribute($name, $val)) {
                $attributes[$name] = $val;
            }
        }
        $attributes = MACE5311_SPI_Attribute_Firewall::sanitize_map($attributes);
        $name = $this->resolve_source_title_authority($raw, $url, sanitize_text_field((string)($raw['name'] ?? '')));
        [$canonical_energy_class, $energy_truth_report] = $this->resolve_energy_truth_authority($raw, $attributes, $name);
        if ($canonical_energy_class !== '') $attributes['Classe énergétique'] = $canonical_energy_class;
        $energy_modes = $this->energy_mode_candidates($raw, $attributes);
        $hdr_candidate = $energy_modes['hdr'][0]['value'] ?? '';
        if ($hdr_candidate !== '') $attributes['Classe énergétique (mode HDR)'] = $hdr_candidate;
        // 5.3.61 Multi-Mode Energy Authority: preserve regulatory grades with their exact
        // operational role. HVAC A++/A means cooling/heating, not a generic class A.
        $multimode_energy = $this->collect_multimode_energy_evidence($raw, $name);
        $multimode_locked = !empty($multimode_energy['locked']) && ($multimode_energy['cooling'] ?? '') !== '' && ($multimode_energy['heating'] ?? '') !== '';
        if ($multimode_locked) {
            $attributes['Classe énergétique (refroidissement)'] = $multimode_energy['cooling'];
            $attributes['Classe énergétique (chauffage)'] = $multimode_energy['heating'];
            $attributes['Classe énergétique'] = $multimode_energy['cooling'] . ' / ' . $multimode_energy['heating'];
            $canonical_energy_class = $attributes['Classe énergétique'];
            $energy_truth_report['multimode'] = $multimode_energy;
            $energy_truth_report['winner'] = $canonical_energy_class;
            $energy_truth_report['version'] = 'plugin-multimode-energy-authority-v1';
            $energy_truth_report['locked'] = true;
        }

        // 5.3.44 Environmental Product Authority: preserve direct environmental facts
        // captured from product text, icons or product-image evidence.
        $environmental = [
            'Classe énergétique' => (string)$canonical_energy_class,
            'Indice de durabilité' => (string)($raw['durability_index'] ?? ($attributes['Indice de durabilité'] ?? '')),
            'Indice de réparabilité' => (string)($raw['repairability_index'] ?? ($attributes['Indice de réparabilité'] ?? '')),
        ];
        $environmental_text = wp_strip_all_tags(
            (string)($raw['short_description'] ?? '') . ' ' .
            (string)($raw['description'] ?? '') . ' ' .
            (string)($raw['specifications_html'] ?? '') . ' ' .
            wp_json_encode((array)($raw['specifications'] ?? []), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
        // Energy is fail-closed: never reconstruct a product class from presentation text.
        // Only resolve_energy_truth_authority() may authorize a class.
        if ($environmental['Indice de durabilité'] === '' &&
            preg_match('~(?:indice\s+de\s+durabilit[eé]|durability\s+index)\s*[:\-]?\s*([0-9](?:[.,][0-9])?|10(?:[.,]0)?)\s*(?:/\s*10)?~iu', $environmental_text, $m)) {
            $environmental['Indice de durabilité'] = str_replace('.', ',', $m[1]) . ' / 10';
        }
        if ($environmental['Indice de réparabilité'] === '' &&
            preg_match('~(?:indice\s+de\s+r[eé]parabilit[eé]|repairability\s+index)\s*[:\-]?\s*([0-9](?:[.,][0-9])?|10(?:[.,]0)?)\s*(?:/\s*10)?~iu', $environmental_text, $m)) {
            $environmental['Indice de réparabilité'] = str_replace('.', ',', $m[1]) . ' / 10';
        }
        foreach ($environmental as $label => $value) {
            $value = sanitize_text_field($value);
            if ($value !== '' && !isset($attributes[$label])) $attributes[$label] = $value;
        }
        $attributes = MACE5311_SPI_Attribute_Firewall::sanitize_map($attributes);
        // 5.3.37 Global Privacy & Source Firewall: no customer-facing text may
        // retain e-mail, phone/WhatsApp, opening hours, postal/contact blocks or URLs.
        $raw['short_description'] = MACE5311_SPI_Content_Firewall::sanitize_plain((string)($raw['short_description'] ?? ''));
        $raw['description'] = MACE5311_SPI_Content_Firewall::sanitize_html((string)($raw['description'] ?? ''));

        // 5.3.36 Direct Product Fact Recovery: Cloud/standalone payloads can arrive with
        // concatenated marketplace text (e.g. Battery 52V...Max speed...Net weight...).
        // Recover only product facts into normalized French labels before generating the
        // short description or shipping fields; contact/source blocks are deliberately ignored.
        $recovered_text_facts = $this->recover_direct_product_facts_from_text((string)($raw['short_description'] ?? ''), (string)($raw['description'] ?? ''));
        foreach ($recovered_text_facts as $fact_name => $fact_value) {
            $fact_value = MACE5311_SPI_Content_Firewall::translate_to_store_locale((string)$fact_value, 'attribute_value');
            if (!isset($attributes[$fact_name]) || trim((string)$attributes[$fact_name]) === '') $attributes[$fact_name] = $fact_value;
        }
        foreach ($attributes as $fact_name => $fact_value) {
            $attributes[$fact_name] = MACE5311_SPI_Content_Firewall::translate_to_store_locale((string)$fact_value, 'attribute_value');
        }
        $attributes = MACE5311_SPI_Attribute_Firewall::sanitize_map($attributes);
        if ($canonical_energy_class !== '') $attributes['Classe énergétique'] = $canonical_energy_class;
        if ($multimode_locked) {
            $attributes['Classe énergétique (refroidissement)'] = $multimode_energy['cooling'];
            $attributes['Classe énergétique (chauffage)'] = $multimode_energy['heating'];
            $attributes['Classe énergétique'] = $multimode_energy['cooling'] . ' / ' . $multimode_energy['heating'];
        }
        $description_format = sanitize_key((string)($raw['description_format'] ?? ''));
        $description = $this->format_description((string)($raw['description'] ?? ''), false, $description_format);
        if (!$multimode_locked) $description = $this->synchronize_energy_html($description, $canonical_energy_class);

        // 5.3.36 Inline Media Recovery Authority: when Cloud/standalone returns zero media
        // but the authoritative product description contains identity-matched product images,
        // reconstruct the main/gallery list from those images instead of materializing a
        // product with an empty WooCommerce gallery.
        $media_recovery = $this->recover_inline_product_media($description, $name, (array)($raw['images'] ?? []), (array)($raw['image_report'] ?? []));
        $raw['images'] = $media_recovery['images'];
        $raw['image_report'] = $media_recovery['report'];

        $raw_short_energy_synced = $multimode_locked ? (string)($raw['short_description'] ?? '') : $this->synchronize_energy_html((string)($raw['short_description'] ?? ''), $canonical_energy_class);
        $short_description = $this->format_description($raw_short_energy_synced, true, '');
        $short_generated = false;
        $settings = get_option('mace5311_spi_settings', []);
        $short_mode = in_array(($settings['short_description_mode'] ?? 'automatic'), ['automatic', 'always_generate', 'preserve_source'], true)
            ? (string)$settings['short_description_mode']
            : 'automatic';
        $short_format = in_array(($settings['short_description_format'] ?? 'professional'), ['professional', 'standard', 'plain'], true)
            ? (string)$settings['short_description_format']
            : 'professional';
        $source_short_description = $short_description;
        $source_rejection_reason = $this->short_description_hard_rejection_reason($source_short_description, $name);
        $short_rejection_reason = $source_rejection_reason;
        $short_quality = $this->short_description_quality($source_short_description, $name);
        if ($source_rejection_reason !== '') $short_quality = 0;

        // Pipeline final : le texte source est d'abord qualifié, puis retiré de la
        // mémoire de travail s'il est promotionnel. Il ne peut donc plus écraser le
        // résumé produit généré lors de l'enregistrement WooCommerce.
        $must_generate = $short_mode === 'always_generate'
            || ($short_mode === 'automatic' && ($source_rejection_reason !== '' || $short_quality < 70));
        if ($must_generate) {
            if ($source_rejection_reason !== '') $short_description = '';
            $facts = [];
            foreach ($attributes as $fact_name => $fact_value) {
                if (MACE5311_SPI_Attribute_Firewall::is_energy_scale_bound_label((string)$fact_name)) continue;
                $facts[] = $fact_name . ' : ' . $fact_value . '.';
            }
            $generation_corpus = trim($description . "\n" . wp_strip_all_tags((string)($raw['specifications_html'] ?? '')) . "\n" . implode(' ', $facts));
            $generated = $this->generate_short_description($name, $generation_corpus);
            if ($generated === '' || $this->short_description_hard_rejection_reason($generated, $name) !== '') {
                $generated = $this->generate_fact_based_short_description($name, $attributes, $description);
            }
            if ($generated !== '') {
                $short_description = $generated;
                $short_generated = true;
                $short_quality = $this->short_description_quality($short_description, $name);
            }
        }

        // Garde-fou absolu : sauf mode « conserver la source », aucun fragment de
        // marketplace rejeté ne peut atteindre post_excerpt.
        $final_rejection = $this->short_description_hard_rejection_reason($short_description, $name);
        if ($short_mode !== 'preserve_source' && $final_rejection !== '') {
            $short_description = $this->generate_fact_based_short_description($name, $attributes, $description);
            $short_generated = $short_description !== '';
            $short_quality = $this->short_description_quality($short_description, $name);
        }
        $short_rejection_reason = $short_generated ? $source_rejection_reason : $final_rejection;

        // Le formatage est une étape obligatoire du pipeline final. Dans les versions
        // précédentes, le réglage était enregistré mais le formateur n'était jamais appelé.
        $short_description = MACE5311_SPI_Content_Firewall::sanitize_plain((string)$short_description);
        $short_description = MACE5311_SPI_Content_Firewall::translate_to_store_locale($short_description, 'short_description');
        $short_description = $this->format_short_description_for_woocommerce(
            $short_description,
            $name,
            $attributes,
            $short_format
        );

        // Golden recovery lanes: preserve the 5.3.11 extraction result first, then
        // fill only fields that are still missing/generic from evidence already present
        // in the same product fiche. Existing valid values are never replaced.
        $brand = $this->resolve_brand_authority((string)($raw['brand'] ?? ''), $name, $description, $attributes, $raw);

        $categories = array_values(array_filter(array_map('sanitize_text_field', (array)($raw['categories'] ?? []))));
        if (!$categories) $categories = $this->infer_categories($name, $attributes);
        if ($this->categories_need_recovery($categories)) {
            $identity = is_array($raw['bridge_identity_evidence'] ?? null) ? $raw['bridge_identity_evidence'] : [];
            $breadcrumb_evidence = implode(' ', array_map('sanitize_text_field', (array)($identity['breadcrumbs'] ?? [])));
            // Additive taxonomy recovery: source breadcrumb evidence is consulted only when
            // categories are missing/generic; a previously validated meaningful category is never replaced.
            $recovered_categories = $this->recover_categories_from_product_content($name, trim($description . ' ' . $breadcrumb_evidence), $attributes);
            if ($recovered_categories) $categories = $recovered_categories;

            // 5.3.53 Visual Product Evidence Authority v1: OCR taxonomy hints may fill a
            // still-missing/generic taxonomy only when they come from the Browser's
            // corroboration-only authority. OCR never replaces an already meaningful category.
            if ($this->categories_need_recovery($categories)) {
                $visual_authority = is_array($identity['visual_product_evidence_authority'] ?? null) ? $identity['visual_product_evidence_authority'] : [];
                $visual_hints = array_values(array_filter(array_map('sanitize_text_field', (array)($visual_authority['taxonomy_hints'] ?? ($identity['visual_ocr_taxonomy_hints'] ?? [])))));
                $policy_ok = ($visual_authority['policy'] ?? '') === 'ocr-corroboration-only' || !empty($identity['visual_ocr_taxonomy_hints']);
                if ($policy_ok && $visual_hints) $categories = $visual_hints;
            }
        }
        $gtin = $this->resolve_gtin($raw, $attributes);
        $regular_price = $this->resolve_regular_price_authority($raw);
        $measurements = $this->recover_structured_measurements($raw, $attributes, $description);

        // 5.3.39 Golden Route Memory: every successful field is associated with the
        // additive authority lanes that were allowed to contribute. This is deliberately
        // strategy-centric (not marketplace-centric) so the same blueprint can guide
        // future difficult pages from any shop without leaking source identity.
        $local_path_registry = $this->build_golden_route_registry([
            'name' => $name,
            'description' => $description,
            'short_description' => $short_description,
            'brand' => $brand,
            'categories' => $categories,
            'gtin' => $gtin,
            'regular_price' => $regular_price,
            'images' => (array)($raw['images'] ?? []),
            'attributes' => $attributes,
            'weight' => $measurements['weight'],
            'length' => $measurements['length'],
            'width' => $measurements['width'],
            'height' => $measurements['height'],
        ], $raw);
        $source_path_registry = is_array($raw['acquisition_path_registry'] ?? null) ? $raw['acquisition_path_registry'] : [];
        $acquisition_path_registry = array_replace_recursive($source_path_registry, $local_path_registry);

        $final_specifications = $this->sanitize_specification_rows((array)($raw['specifications'] ?? []));
        $final_specifications_html = $this->sanitize_specifications_html((string)($raw['specifications_html'] ?? ''));
        if (!$multimode_locked) {
            $final_specifications = $this->synchronize_energy_rows($final_specifications, $canonical_energy_class);
            $final_specifications_html = $this->synchronize_energy_html($final_specifications_html, $canonical_energy_class);
        }

        return [
            'source_url' => $url,
            'name' => $name,
            'description' => $description,
            'description_format' => $description_format,
            'description_report' => is_array($raw['description_report'] ?? null) ? $raw['description_report'] : [],
            'short_description' => $short_description,
            'short_description_generated' => $short_generated,
            'short_description_source' => $short_generated ? 'generated_from_title_and_long_description' : 'source',
            'short_description_quality' => $short_quality,
            'short_description_mode' => $short_mode,
            'short_description_format' => $short_format,
            'short_description_rejection_reason' => $short_rejection_reason,
            'sku' => sanitize_text_field((string)($raw['sku'] ?? '')),
            'gtin' => $gtin,
            'brand' => $brand,
            'regular_price' => $regular_price,
            'sale_price' => $this->decimal($raw['sale_price'] ?? ''),
            'currency' => sanitize_text_field((string)($raw['currency'] ?? '')),
            'price_report' => is_array($raw['price_report'] ?? null) ? $raw['price_report'] : [],
            'price_authority_report' => $this->price_authority_report,
            'stock_status' => ($raw['stock_status'] ?? 'instock') === 'outofstock' ? 'outofstock' : 'instock',
            'images' => array_values(array_unique(array_filter(array_map('esc_url_raw', (array)($raw['images'] ?? []))))),
            'brand_logo' => esc_url_raw((string)($raw['brand_logo'] ?? '')),
            'image_report' => is_array($raw['image_report'] ?? null) ? $raw['image_report'] : [],
            'categories' => $categories,
            'attributes' => $attributes,
            'specifications' => $final_specifications,
            'specifications_html' => $final_specifications_html,
            'energy_class' => $canonical_energy_class,
            'energy_truth_report' => $energy_truth_report,
            'specifications_report' => is_array($raw['specifications_report'] ?? null) ? $raw['specifications_report'] : [],
            'direct_product_sections' => is_array($raw['direct_product_sections'] ?? null) ? $raw['direct_product_sections'] : [],
            'acquisition_path_registry' => $acquisition_path_registry,
            'materialization_contract' => is_array($raw['materialization_contract'] ?? null) ? $raw['materialization_contract'] : [],
            'cloud_materialization_firewall_report' => is_array($raw['universal_materialization_firewall_report'] ?? null) ? $raw['universal_materialization_firewall_report'] : [],
            'weight' => $measurements['weight'],
            'length' => $measurements['length'],
            'width' => $measurements['width'],
            'height' => $measurements['height'],
        ];
    }



    private function build_golden_route_registry(array $final, array $raw): array {
        $validated = [];
        foreach (['name','description','short_description','brand','gtin','regular_price','weight','length','width','height'] as $field) {
            if (trim((string)($final[$field] ?? '')) !== '') $validated[] = $field;
        }
        foreach (['images','categories','attributes'] as $field) {
            if (!empty($final[$field]) && is_array($final[$field])) $validated[] = $field;
        }
        $lanes = [
            'structured_data' => true,
            'meta_open_graph' => true,
            'rendered_or_source_html' => true,
            'direct_product_fact_recovery' => true,
            'privacy_source_firewall' => true,
            'locale_normalization' => true,
            'brand_authority' => trim((string)($final['brand'] ?? '')) !== '',
            'taxonomy_recovery' => !empty($final['categories']),
            'gtin_authority' => trim((string)($final['gtin'] ?? '')) !== '',
            'price_authority' => trim((string)($final['regular_price'] ?? '')) !== '',
            'inline_media_recovery' => !empty($final['images']),
            'structured_measurements' => trim((string)($final['weight'] ?? '')) !== '' || trim((string)($final['length'] ?? '')) !== '',
            'attribute_firewall' => !empty($final['attributes']),
            'description_fidelity' => trim((string)($final['description'] ?? '')) !== '',
        ];
        $active = [];
        foreach ($lanes as $lane => $enabled) if ($enabled) $active[] = $lane;
        return [
            'schema' => 'mace-golden-route-v1',
            'policy' => 'additive_only_non_regression',
            'active_lanes' => $active,
            'validated_fields' => array_values(array_unique($validated)),
            'completion_score' => count(array_unique($validated)),
            'source_registry_present' => !empty($raw['acquisition_path_registry']),
        ];
    }

    private function resolve_gtin(array $raw, array $attributes): string {
        $aliases = ['gtin14','gtin13','gtin12','gtin8','gtin','ean13','ean','upc','barcode','isbn13'];
        foreach ($aliases as $key) {
            if (!empty($raw[$key])) {
                $candidate = $this->normalize_gtin_candidate((string)$raw[$key]);
                if ($candidate !== '') return $candidate;
            }
        }

        foreach ($attributes as $label => $value) {
            if (!$this->is_gtin_label((string)$label)) continue;
            $candidate = $this->normalize_gtin_candidate((string)$value);
            if ($candidate !== '') return $candidate;
        }

        foreach ((array)($raw['specifications'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $label = (string)($row['label'] ?? ($row['name'] ?? ($row['key'] ?? '')));
            $value = (string)($row['value'] ?? ($row['values'] ?? ''));
            if (!$this->is_gtin_label($label)) continue;
            $candidate = $this->normalize_gtin_candidate($value);
            if ($candidate !== '') return $candidate;
        }

        foreach ((array)($raw['variants'] ?? []) as $variant) {
            if (!is_array($variant)) continue;
            foreach (['gtin','barcode','ean','upc'] as $key) {
                if (empty($variant[$key])) continue;
                $candidate = $this->normalize_gtin_candidate((string)$variant[$key]);
                if ($candidate !== '') return $candidate;
            }
        }

        $spec_html = wp_strip_all_tags((string)($raw['specifications_html'] ?? ''));
        if ($spec_html !== '' && preg_match('/(?:EAN(?:[-\s]?13)?|GTIN(?:[-\s]?(?:8|12|13|14))?|UPC(?:[-\s]?A)?|code\s*(?:EAN|barres?)|barcode)\s*[:#-]?\s*((?:\d[\s.\-]?){7,13}\d)/iu', $spec_html, $m)) {
            $candidate = $this->normalize_gtin_candidate($m[1]);
            if ($candidate !== '') return $candidate;
        }
        return '';
    }

    private function is_gtin_label(string $label): bool {
        $label = mb_strtolower(remove_accents(trim($label)));
        $label = preg_replace('/[^a-z0-9]+/u', ' ', $label);
        return (bool) preg_match('/\b(?:ean(?:\s*13)?|gtin(?:\s*(?:8|12|13|14))?|upc(?:\s*a)?|barcode|code\s*ean|code\s*barres?)\b/u', $label);
    }

    private function normalize_gtin_candidate(string $value): string {
        $value = html_entity_decode(wp_strip_all_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (!preg_match_all('/(?<!\d)(?:\d[\s.\-]?){7,13}\d(?!\d)/u', $value, $matches)) return '';
        foreach ($matches[0] as $match) {
            $digits = preg_replace('/\D+/', '', $match);
            if (in_array(strlen($digits), [8, 12, 13, 14], true)) return $digits;
        }
        return '';
    }

    private function short_description_hard_rejection_reason(string $short, string $name): string {
        $plain_original = trim(wp_strip_all_tags($short));
        $plain = $this->normalize_comparison_text($plain_original);
        $title = $this->normalize_comparison_text($name);
        if ($plain === '') return 'empty';

        // Règles bloquantes : une seule occurrence suffit. Ces formulations sont des
        // fragments de marketplace, et non une description produit exploitable.
        $hard_patterns = [
            'achetez sur', 'acheter sur', 'faites vous livrer', 'beneficiez du retrait',
            'retrait en magasin', 'retrait magasin', 'infos et prix', 'voir le prix',
            'commandez sur', 'disponible sur', 'vendu et expedie', 'expedie par',
            'ajouter au panier', 'livraison gratuite', 'livraison rapide', 'chez vous ou',
            'office hours', 'business hours', 'whatsapp', 'contact us', 'customer service',
            'email:', 'e-mail:', 'address:', 'adresse:', 'telephone:', 'phone:',
        ];
        foreach ($hard_patterns as $pattern) {
            if (strpos($plain, $pattern) !== false) return 'marketplace_promotional_text:' . $pattern;
        }
        // Locale fidelity: on a French storefront, a clearly English marketplace snippet
        // is not published verbatim. It is regenerated from verified product facts.
        $locale = function_exists('get_locale') ? strtolower((string)get_locale()) : 'fr_fr';
        if (strpos($locale, 'fr') === 0) {
            $english_hits = preg_match_all('/\b(?:the|with|and|battery|motor|speed|range|powerful|off\s*road|electric\s+scooter|make\s+it|more\s+stable|shock\s+absorber)\b/u', $plain, $dummy);
            $french_hits = preg_match_all('/\b(?:avec|batterie|moteur|vitesse|autonomie|puissance|electrique|électrique|trottinette|stable|amortisseur)\b/u', $plain, $dummy2);
            if ($english_hits >= 4 && $english_hits > ($french_hits * 2 + 1)) return 'foreign_language_source:en';
        }
        if (preg_match('/\b(?:fnac|amazon|cdiscount|manomano|rakuten|darty|boulanger|ebay|aliexpress|temu)\b/u', $plain)) {
            return 'marketplace_name';
        }
        if (preg_match('/\b(?:financement|paiement|mensualite|credit|taeg|taux|apport|acompte|echeance|j\s*(?:\+\s*)?\d+|3\s*x|4\s*x|klarna|alma|oney|cofidis|sofinco|cashback)\b/u', $plain)) {
            return 'commerce_or_financing_noise';
        }
        if (preg_match('~https?://|www\.|\.(?:com|fr|net|org)\b~ui', $plain_original)) return 'external_url';
        if (preg_match('/(?:[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}|(?:whatsapp|office\s+hours|business\s+hours|address|adresse|phone|telephone|téléphone)\s*[:：])/iu', $plain_original)) return 'contact_or_source_identity';
        if (stripos((string)get_locale(), 'fr') === 0) {
            $english_hits = preg_match_all('/\b(?:the|and|with|battery|motor|speed|range|scooter|more|stable|powerful|off-road)\b/i', $plain_original, $tmp);
            $french_hits = preg_match_all('/\b(?:le|la|les|et|avec|batterie|moteur|vitesse|autonomie|trottinette|puissant)\b/iu', $plain_original, $tmp2);
            if ($english_hits >= 4 && $english_hits > ($french_hits * 2)) return 'language_mismatch_en_fr';
        }

        $words = preg_split('/\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY);
        if (count($words) < 12) return 'too_short';
        if ($title !== '' && ($plain === $title || strpos($plain, $title) === 0)) {
            $extra = trim(substr($plain, strlen($title)));
            $extra_words = preg_split('/\s+/u', $extra, -1, PREG_SPLIT_NO_EMPTY);
            if (count($extra_words) < 14) return 'title_repetition';
        }
        return '';
    }

    private function short_description_needs_fallback(string $short, string $name): bool {
        return $this->short_description_quality($short, $name) < 60;
    }

    private function short_description_quality(string $short, string $name): int {
        $plain_original = trim(wp_strip_all_tags($short));
        $plain = $this->normalize_comparison_text($plain_original);
        $title = $this->normalize_comparison_text($name);
        if ($plain === '') return 0;

        $word_count = count(preg_split('/\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY));
        $score = 100;
        if ($word_count < 8) $score -= 55;
        elseif ($word_count < 15) $score -= 30;
        elseif ($word_count > 90) $score -= 15;

        if ($title !== '' && ($plain === $title || strpos($plain, $title) === 0)) {
            $extra = trim(substr($plain, strlen($title)));
            if ($extra === '') $score -= 70;
            elseif (count(preg_split('/\s+/u', $extra, -1, PREG_SPLIT_NO_EMPTY)) < 8) $score -= 40;
        }

        $promo_patterns = [
            'achetez sur', 'acheter sur', 'commandez', 'commander', 'profitez de', 'livraison gratuite',
            'faites vous livrer', 'retrait en magasin', 'retrait magasin', 'vendu et expedie', 'expedie par',
            'disponible chez', 'prix bas', 'meilleur prix', 'offre speciale', 'promotion', 'infos et prix',
            'decouvrez sur', 'cliquez ici', 'voir plus', 'ajouter au panier', 'en stock chez', 'marketplace'
        ];
        foreach ($promo_patterns as $pattern) {
            if (strpos($plain, $pattern) !== false) $score -= 28;
        }
        if (preg_match('~https?://|www\.|\.com\b|\.fr\b~u', $plain_original)) $score -= 30;
        if (preg_match('/\b(?:fnac|amazon|cdiscount|manomano|rakuten|darty|boulanger|ebay|aliexpress|temu)\b/u', $plain)) $score -= 18;

        $short_words = $this->meaningful_words($plain);
        $title_words = $this->meaningful_words($title);
        if ($short_words && $title_words) {
            $overlap = count(array_intersect($short_words, $title_words));
            $ratio = $overlap / max(1, count(array_unique($short_words)));
            if ($word_count <= 24 && $ratio >= 0.72) $score -= 40;
        }

        $sentences = preg_split('/(?<=[.!?])\s+/u', $plain_original, -1, PREG_SPLIT_NO_EMPTY);
        if (count($sentences) >= 1 && count($sentences) <= 3) $score += 8;
        if (preg_match('/\b(?:concu|permet|offre|dispose|equipe|adapte|ideal|capacite|puissance|performance|utilisation|technologie)\b/u', $plain)) $score += 8;

        return max(0, min(100, $score));
    }

    private function generate_fact_based_short_description(string $name, array $attributes, string $long_description): string {
        $facts = [];
        foreach ($attributes as $label => $value) {
            $label = trim(wp_strip_all_tags((string)$label));
            $value = trim(wp_strip_all_tags((string)$value));
            if ($label === '' || $value === '') continue;
            $comparison = $this->normalize_comparison_text($label . ' ' . $value);
            if (preg_match('/\b(?:prix|livraison|vendeur|ean|sku|reference interne|disponibilite)\b/u', $comparison)) continue;
            $facts[] = $label . ' ' . $value;
            if (count($facts) >= 4) break;
        }
        if (!$facts) {
            $plain = trim(preg_replace('/\s{2,}/u', ' ', wp_strip_all_tags($long_description)));
            $plain = preg_replace('/\b(?:achetez|commandez|livraison|retrait magasin).*$/ui', '', (string)$plain);
            if ($plain !== '') {
                $fallback = trim(wp_trim_words($plain, 48, ''));
                if ($fallback !== '' && !preg_match('/[.!?]$/u', $fallback)) $fallback .= '.';
                return wpautop(esc_html($fallback), false);
            }
            return $name !== '' ? wpautop(esc_html(rtrim($name, '.:; ') . ' est présenté avec ses principales caractéristiques techniques et fonctionnelles.'), false) : '';
        }
        $first = rtrim($name, '.:; ');
        $sentence = ($first !== '' ? $first . ' se distingue par ' : 'Ce produit se distingue par ') . implode(', ', array_slice($facts, 0, 3)) . '.';
        if (isset($facts[3])) $sentence .= ' Il comprend également ' . $facts[3] . '.';
        return wpautop(esc_html($sentence), false);
    }

    private function generate_short_description(string $name, string $long_description): string {
        $html = preg_replace('~<(table|thead|tbody|tfoot|tr|th|td)[^>]*>.*?</\1>~is', ' ', $long_description);
        $html = preg_replace('~<h[1-6][^>]*>.*?</h[1-6]>~is', ' ', (string)$html);
        $plain = html_entity_decode(wp_strip_all_tags((string)$html, true), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = preg_replace('/[\r\n\t]+/u', ' ', $plain);
        $plain = preg_replace('/\s{2,}/u', ' ', trim((string)$plain));
        if ($plain === '') return '';

        $sentences = preg_split('/(?<=[.!?])\s+(?=[\p{L}0-9])/u', $plain, -1, PREG_SPLIT_NO_EMPTY);
        if (!$sentences) $sentences = [$plain];

        $title_words = $this->meaningful_words($this->normalize_comparison_text($name));
        $blocked_starts = ['caracteristiques', 'specifications', 'reference', 'ref ', 'ean ', 'sku ', 'livraison', 'vendeur', 'avis clients', 'achetez', 'commandez', 'profitez', 'retrait', 'expedie', 'vendu par', 'disponible chez'];
        $candidates = [];
        foreach ($sentences as $index => $sentence) {
            $sentence = trim(preg_replace('/\s{2,}/u', ' ', (string)$sentence));
            $length = mb_strlen($sentence);
            if ($length < 35 || $length > 360) continue;
            $comparison = $this->normalize_comparison_text($sentence);
            $blocked = false;
            foreach ($blocked_starts as $start) {
                if (strpos($comparison, $start) === 0) { $blocked = true; break; }
            }
            if ($blocked || preg_match('/\b(?:fnac|amazon|cdiscount|manomano|rakuten|darty|boulanger|ebay|aliexpress|temu|livraison|retrait magasin|ajouter au panier|infos et prix)\b/u', $comparison)) continue;
            $words = $this->meaningful_words($comparison);
            $overlap = count(array_intersect($words, $title_words));
            $score = max(0, 20 - $index) + ($overlap * 8);
            if (preg_match('/\b(?:ideal|concu|permet|offre|dispose|equipe|adapt|pratique|performant|capacite|compatible|utilisation)\b/u', $comparison)) $score += 8;
            $candidates[] = ['text'=>$sentence, 'score'=>$score, 'index'=>$index, 'words'=>$words];
        }

        if (!$candidates) {
            $fallback = trim(wp_trim_words($plain, 48, ''));
            if ($fallback !== '' && !preg_match('/[.!?]$/u', $fallback)) $fallback .= '.';
            return wpautop(esc_html($fallback), false);
        }

        usort($candidates, static function ($a, $b) {
            return $a['score'] === $b['score'] ? $a['index'] <=> $b['index'] : $b['score'] <=> $a['score'];
        });
        $selected = [$candidates[0]];
        foreach (array_slice($candidates, 1) as $candidate) {
            $common = count(array_intersect($selected[0]['words'], $candidate['words']));
            $similarity = $common / max(1, min(count($selected[0]['words']), count($candidate['words'])));
            if ($similarity < 0.55) { $selected[] = $candidate; break; }
        }
        usort($selected, static function ($a, $b) { return $a['index'] <=> $b['index']; });
        $summary = implode(' ', array_column($selected, 'text'));
        $summary = trim(wp_trim_words($summary, 58, ''));
        if ($summary !== '' && !preg_match('/[.!?]$/u', $summary)) $summary .= '.';

        $summary_words = $this->meaningful_words($this->normalize_comparison_text($summary));
        $title_overlap = count(array_intersect($summary_words, $title_words));
        if ($name !== '' && $title_words && $title_overlap === 0) {
            $summary = rtrim($name, '.:; ') . ' — ' . lcfirst($summary);
        }
        return wpautop(esc_html($summary), false);
    }

    private function format_short_description_for_woocommerce(string $html, string $name, array $attributes, string $mode): string {
        $plain = html_entity_decode(trim(wp_strip_all_tags($html)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = preg_replace('/[\p{Cf}\x{00AD}]+/u', ' ', (string)$plain);
        $plain = trim(preg_replace('/\s{2,}/u', ' ', (string)$plain));
        if ($plain === '') return '';
        if ($mode === 'plain') return esc_html($plain);

        $facts = [];
        foreach ($attributes as $label => $value) {
            $label = trim(wp_strip_all_tags((string)$label));
            $value = trim(wp_strip_all_tags((string)$value));
            if ($label === '' || $value === '') continue;
            [$label, $value] = MACE5311_SPI_Attribute_Firewall::sanitize_pair($label, $value);
            if ($label === '' || $value === '') continue;
            if (MACE5311_SPI_Attribute_Firewall::is_energy_scale_bound_label($label)) continue;
            $check = $this->normalize_comparison_text($label . ' ' . $value);
            if (preg_match('/\b(?:prix|livraison|vendeur|ean|gtin|sku|ugs|reference interne|disponibilite|securite du produit|classe energetique|indice de durabilite|indice de reparabilite)\b/u', $check)) continue;
            if (mb_strlen($value) > 90) continue;
            $facts[] = ['label'=>$label, 'value'=>$value];
            if (count($facts) >= 5) break;
        }

        // 5.3.25: a short description must remain a real product summary, not a title
        // followed by a single recovered attribute. Build a minimum useful paragraph
        // from the verified title/facts when the captured summary is too thin.
        $sentences = preg_split('/(?<=[.!?])\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY);
        $intro = trim(implode(' ', array_slice($sentences ?: [$plain], 0, 2)));
        $intro_words = preg_split('/\s+/u', $this->normalize_comparison_text($intro), -1, PREG_SPLIT_NO_EMPTY);
        $intro_word_count = count($intro_words ?: []);
        if ($intro_word_count < 28 && $facts) {
            $fact_phrases = [];
            foreach (array_slice($facts, 0, 3) as $fact) {
                $fact_phrases[] = mb_strtolower($fact['label']) . ' ' . $fact['value'];
            }
            $subject = rtrim(trim($name), '.:; ');
            if ($subject === '') $subject = 'Ce produit';
            $intro = $subject . ' réunit ' . implode(', ', $fact_phrases) . '.';
            if (isset($facts[3])) {
                $intro .= ' Il intègre également ' . mb_strtolower($facts[3]['label']) . ' ' . $facts[3]['value'] . ' pour compléter ses caractéristiques principales.';
            } else {
                $intro .= ' Cette configuration rassemble les caractéristiques essentielles pour une présentation produit claire et exploitable.';
            }
        }

        // Never end a professional short description with an ellipsis. Keep complete
        // sentences and cap only after sentence selection.
        $intro = preg_replace('/(?:…|\.\.\.)\s*$/u', '.', trim((string)$intro));
        $intro_sentences = preg_split('/(?<=[.!?])\s+/u', $intro, -1, PREG_SPLIT_NO_EMPTY);
        if (count($intro_sentences ?: []) > 2) $intro = implode(' ', array_slice($intro_sentences, 0, 2));
        if (!preg_match('/[.!?]$/u', $intro)) $intro .= '.';

        if ($mode === 'standard') {
            $parts = preg_split('/(?<=[.!?])\s+/u', $intro, -1, PREG_SPLIT_NO_EMPTY);
            return implode("\n", array_map(static function ($part) { return '<p>' . esc_html(trim($part)) . '</p>'; }, $parts ?: [$intro]));
        }

        $out = '<div class="mace-short-description mace-short-description--professional">';
        $out .= '<p class="mace-short-description__intro">' . esc_html($intro) . '</p>';
        $out .= $this->render_environmental_badges($attributes);
        if ($facts) {
            $out .= '<ul class="mace-short-description__highlights">';
            foreach ($facts as $fact) {
                $out .= '<li><strong>' . esc_html($fact['label']) . ' :</strong> ' . esc_html($fact['value']) . '</li>';
            }
            $out .= '</ul>';
        }
        $out .= '</div>';
        return wp_kses_post($out);
    }

    private function render_environmental_badges(array $attributes): string {
        $settings = get_option('mace5311_spi_settings', []);
        if (array_key_exists('short_environmental_badges', $settings) && empty($settings['short_environmental_badges'])) return '';

        $energy = trim((string)($attributes['Classe énergétique'] ?? ''));
        $durability = trim((string)($attributes['Indice de durabilité'] ?? ''));
        $repairability = trim((string)($attributes['Indice de réparabilité'] ?? ''));

        if ($energy === '' && $durability === '' && $repairability === '') return '';

        $cards = [];
        if ($durability !== '') {
            $cards[] =
                '<div class="mace-env-card mace-env-card--durability" style="display:flex;align-items:center;gap:10px;min-width:180px;padding:10px 12px;border:1px solid #e4e4e4;border-radius:10px;background:#fff;">' .
                    '<span aria-hidden="true" style="font-size:28px;line-height:1;">⌛</span>' .
                    '<span><strong style="display:block;font-size:13px;">Indice de durabilité</strong>' .
                    '<span style="font-size:24px;font-weight:700;line-height:1.1;">' . esc_html($durability) . '</span>' .
                    '<small style="display:block;margin-top:3px;">Fiabilité · Réparabilité</small></span>' .
                '</div>';
        }
        if ($repairability !== '') {
            $cards[] =
                '<div class="mace-env-card mace-env-card--repairability" style="display:flex;align-items:center;gap:10px;min-width:180px;padding:10px 12px;border:1px solid #e4e4e4;border-radius:10px;background:#fff;">' .
                    '<span aria-hidden="true" style="font-size:26px;line-height:1;">🛠</span>' .
                    '<span><strong style="display:block;font-size:13px;">Indice de réparabilité</strong>' .
                    '<span style="font-size:24px;font-weight:700;line-height:1.1;">' . esc_html($repairability) . '</span></span>' .
                '</div>';
        }
        if ($energy !== '') {
            $energy_letter = strtoupper(preg_replace('/[^A-G+]/i', '', $energy));
            if ($energy_letter === '') $energy_letter = $energy;
            $cards[] =
                '<div class="mace-env-card mace-env-card--energy" style="display:flex;align-items:center;gap:10px;min-width:180px;padding:10px 12px;border:1px solid #e4e4e4;border-radius:10px;background:#fff;">' .
                    '<span style="display:inline-flex;align-items:center;justify-content:center;min-width:50px;height:42px;padding:0 12px;border-radius:5px;background:#b86624;color:#fff;font-size:25px;font-weight:800;">' . esc_html($energy_letter) . '</span>' .
                    '<span><strong style="display:block;font-size:13px;">Classe énergétique</strong>' .
                    '<small style="display:block;margin-top:3px;">Échelle A à G</small></span>' .
                '</div>';
        }

        return '<div class="mace-environmental-badges" style="display:flex;flex-wrap:wrap;gap:10px;margin:14px 0 12px;">' .
            implode('', $cards) .
        '</div>';
    }

    /**
     * Terminal price authority. A Cloud terminal lock or exact Browser Bridge
     * primary-product-zone proof outranks any weaker DOM/JSON-LD price. This is the
     * final plugin-side non-regression barrier before WooCommerce materialization.
     */
    private function resolve_regular_price_authority(array $raw): string {
        $source = strtolower((string)($raw['source_url'] ?? ($raw['url'] ?? '')));
        $is_fnac = strpos($source, 'fnac.') !== false;
        $is_manomano = strpos($source, 'manomano.') !== false;
        $raw_regular = $this->decimal($raw['regular_price'] ?? '');
        $this->price_authority_report = ['version'=>'price-candidate-ledger-v1','materialization'=>'undecided','selected'=>'','reason'=>''];

        // Candidate-bound authority: select evidence for the amount it actually proves.
        // A strong source elsewhere in the payload can no longer launder a weak Cloud amount.
        $weak_role_pattern = '/primary-buybox-cta-text|buybox-cta|eco[- ]?participation|livraison|shipping|mensualit|par mois|\/mois|alma|financement|abonnement|subscription|service partenaire|offre partenaire|deposit|acompte|rating|note|avis/i';
        $strong_money_pattern = '/pricecurrency|json-ld-product-offer|structured-product-offer|exact-product-zone|bridge-primary-product-zone|commerce-price-evidence|product-offer|certified-product-price|open-graph-product-price|embedded-product-variant-price/i';
        $ledger = [];
        foreach ((array)($raw['price_candidates'] ?? []) as $candidate) {
            if (!is_array($candidate)) continue;
            $amount = $this->decimal($candidate['amount'] ?? ($candidate['price'] ?? ($candidate['value'] ?? '')));
            if ($amount === '') continue;
            $role = strtolower((string)($candidate['source'] ?? ($candidate['role'] ?? '')));
            $ledger[] = ['amount'=>$amount,'role'=>$role,'origin'=>(string)($candidate['origin'] ?? 'candidate')];
        }
        $top_source = strtolower(trim((string)($raw['price_source'] ?? ($raw['primary_price_source'] ?? ($raw['regular_price_source'] ?? '')))));
        if ($raw_regular !== '' && !array_filter($ledger, static fn($c)=>$c['amount']===$raw_regular && $c['origin']==='primary')) {
            $ledger[] = ['amount'=>$raw_regular,'role'=>$top_source,'origin'=>'primary'];
        }
        $strong_ledger = [];
        foreach ($ledger as $candidate) {
            $weak = $candidate['role'] !== '' && preg_match($weak_role_pattern, $candidate['role']) === 1;
            $strong = $candidate['role'] !== '' && preg_match($strong_money_pattern, $candidate['role']) === 1;
            if ($strong && !$weak) $strong_ledger[] = $candidate;
        }
        // If the Cloud winner is explicitly weak, it has zero authority. Prefer exactly one
        // strong independently recovered candidate; conflicting strong candidates fail closed.
        // A certified PRODUCT_PRICE contract is evaluated first because it binds an amount
        // to its semantic role explicitly and is therefore stronger than the weak scalar.
        $early_contract = is_array($raw['product_price_contract'] ?? null) ? $raw['product_price_contract'] : [];
        $early_contract_status = strtolower((string)($early_contract['status'] ?? ($early_contract['decision'] ?? '')));
        $early_contract_role = strtolower((string)($early_contract['semantic_role'] ?? ($early_contract['role'] ?? '')));
        $early_contract_price = $this->decimal($early_contract['authoritative_price'] ?? ($early_contract['amount'] ?? ($early_contract['value'] ?? '')));
        if ($early_contract_price !== '' && $early_contract_role === 'product_price' && in_array($early_contract_status, ['certified','accepted','locked','authoritative'], true)) {
            $this->price_authority_report = ['version'=>'price-candidate-ledger-v1','materialization'=>'allowed','selected'=>$early_contract_price,'reason'=>'certified_product_price_contract'];
            return $early_contract_price;
        }
        if ($raw_regular !== '' && $top_source !== '' && preg_match($weak_role_pattern, $top_source) === 1) {
            $by_amount = [];
            foreach ($strong_ledger as $c) $by_amount[$c['amount']] = $c;
            if (count($by_amount) === 1) {
                $winner = array_values($by_amount)[0];
                $this->price_authority_report = ['version'=>'price-candidate-ledger-v1','materialization'=>'allowed','selected'=>$winner['amount'],'reason'=>'weak_cloud_replaced_by_single_strong_candidate','source'=>$winner['role']];
                return $winner['amount'];
            }
            $this->price_authority_report = ['version'=>'price-candidate-ledger-v1','materialization'=>'blocked_untrusted','selected'=>'','reason'=>count($by_amount)>1?'conflicting_strong_candidates_after_weak_cloud':'weak_cloud_without_strong_candidate','rejected'=>$raw_regular,'source'=>$top_source];
            return '';
        }

        $bridge = '';
        $bridge_node = [];
        foreach (['bridge-primary-product-zone-v1','bridge_primary_product_zone_v1','bridge_primary_product_zone'] as $key) {
            if (!isset($raw[$key])) continue;
            $bridge_node = is_array($raw[$key]) ? $raw[$key] : ['amount'=>$raw[$key]];
            $value = $bridge_node['price'] ?? ($bridge_node['value'] ?? ($bridge_node['amount'] ?? ''));
            $bridge = $this->decimal($value);
            if ($bridge !== '') break;
        }

        $lock = is_array($raw['price_terminal_lock'] ?? null) ? $raw['price_terminal_lock'] : [];
        $locked_candidate = (!empty($lock['locked']) && isset($lock['authoritative_price'])) ? $this->decimal($lock['authoritative_price']) : '';

        // Product Price Evidence Contract v3. Never infer provenance only from the
        // numeric amount. Production Cloud responses may expose the winning role as
        // top-level price_source/primary_price_source while older plugin gates looked
        // only inside nested price_evidence. That blind spot allowed a financing/CTA
        // amount such as 92.11 EUR to survive even though its role was explicitly weak.
        $price_contract = is_array($raw['product_price_contract'] ?? null) ? $raw['product_price_contract'] : [];
        $contract_price = '';
        $contract_status = strtolower((string)($price_contract['status'] ?? ($price_contract['decision'] ?? '')));
        $contract_role = strtolower((string)($price_contract['semantic_role'] ?? ($price_contract['role'] ?? '')));
        $contract_candidate = $price_contract['authoritative_price'] ?? ($price_contract['amount'] ?? ($price_contract['value'] ?? ''));
        if (in_array($contract_status, ['certified','accepted','locked','authoritative'], true) && $contract_role === 'product_price') {
            $contract_price = $this->decimal($contract_candidate);
        }

        $evidence = strtolower(wp_json_encode([
            $raw['price_source'] ?? '',
            $raw['primary_price_source'] ?? '',
            $raw['regular_price_source'] ?? '',
            $raw['price_report'] ?? [],
            $raw['price_evidence'] ?? [],
            $raw['commerce_price_evidence'] ?? [],
            $raw['primary_price_meta'] ?? [],
            $raw['rendered_primary_price_meta'] ?? [],
            $raw['price_truth_certificate'] ?? [],
            $price_contract,
            $raw['diagnostics']['price'] ?? [],
        ]));
        $bridge_meta = strtolower(wp_json_encode($bridge_node));

        // A certified PRODUCT_PRICE contract is terminal and independent of any
        // incidental number still present in the Cloud payload.
        if ($contract_price !== '') { $this->price_authority_report=['version'=>'price-candidate-ledger-v1','materialization'=>'allowed','selected'=>$contract_price,'reason'=>'certified_product_price_contract']; return $contract_price; }

        if ($locked_candidate !== '') {
            $lv = (float)$locked_candidate;
            $lock_meta = strtolower(wp_json_encode($lock));
            $lock_strong = preg_match($strong_money_pattern, $lock_meta.' '.$evidence) === 1;
            $lock_weak = preg_match($weak_role_pattern, $lock_meta.' '.$evidence) === 1;
            if (!($lv < 20.0 && (!$lock_strong || $lock_weak))) return $locked_candidate;
            // A tiny locked value without atomic money proof is intentionally demoted.
        }
        $raw_value = $raw_regular !== '' ? (float)$raw_regular : 0.0;
        $bridge_value = $bridge !== '' ? (float)$bridge : 0.0;
        $raw_weak = preg_match($weak_role_pattern, $evidence) === 1;
        $raw_strong_money = preg_match($strong_money_pattern, $evidence) === 1;
        $top_level_price_role = strtolower(trim((string)($raw['price_source'] ?? ($raw['primary_price_source'] ?? ($raw['regular_price_source'] ?? '')))));
        $top_level_weak = $top_level_price_role !== '' && preg_match($weak_role_pattern, $top_level_price_role) === 1;
        $bridge_weak = preg_match($weak_role_pattern, $bridge_meta) === 1;
        $bridge_strong_money = preg_match($strong_money_pattern, $bridge_meta) === 1;
        // Semantic Product-Price Existence Gate v2.
        // A CTA/financing/shipping/fee amount is NEVER a terminal product price by itself,
        // regardless of magnitude. Previous versions only rejected tiny values (<20), which
        // allowed realistic-looking instalments such as 92.11 to leak into WooCommerce.
        // Weak-role money therefore has zero terminal authority until corroborated by an
        // independent PRODUCT_PRICE lane (structured offer / exact product zone / commerce proof).
        if ($raw_regular !== '' && ($top_level_weak || ($raw_weak && !$raw_strong_money))) {
            if ($bridge !== '' && $bridge_strong_money && !$bridge_weak) return $bridge;
            $this->price_authority_report=['version'=>'price-candidate-ledger-v1','materialization'=>'blocked_untrusted','selected'=>'','reason'=>'weak_role_without_independent_product_price'];
            return '';
        }
        if ($bridge !== '' && $bridge_weak && !$bridge_strong_money) {
            if ($raw_regular !== '' && $raw_strong_money && !$raw_weak) return $raw_regular;
            return '';
        }
        if ($raw_regular === '') return $bridge;
        if ($bridge === '') return $raw_regular;

        $a = $raw_value;
        $b = $bridge_value;
        $ratio = min($a,$b) > 0 ? max($a,$b) / min($a,$b) : 999.0;

        // 5.3.53 Visual Product Evidence Authority v1. OCR is corroboration-only:
        // it may decide which *existing* price lane is visually confirmed, but can never
        // create a new WooCommerce amount. This protects against ancillary CTA amounts.
        $identity = is_array($raw['bridge_identity_evidence'] ?? null) ? $raw['bridge_identity_evidence'] : [];
        $visual_authority = is_array($identity['visual_product_evidence_authority'] ?? null) ? $identity['visual_product_evidence_authority'] : [];
        $visual_prices = (array)($visual_authority['price_candidates'] ?? ($identity['visual_ocr_price_candidates'] ?? []));
        $visual_match_a = false; $visual_match_b = false;
        foreach ($visual_prices as $vp) {
            $v = (float)$this->decimal($vp);
            if ($v <= 0) continue;
            if ($a > 0 && abs($v-$a)/$a <= 0.02) $visual_match_a = true;
            if ($b > 0 && abs($v-$b)/$b <= 0.02) $visual_match_b = true;
        }
        if ($visual_match_b && !$visual_match_a && $ratio >= 1.20) return $bridge;
        if ($visual_match_a && !$visual_match_b && $ratio >= 1.20) return $raw_regular;

        // Exact Main Price Consensus v2.
        // The key distinction is "price role", not merely the DOM/JSON-LD technology used.
        // A buy-box CTA can contain eco-participation, instalments, shipping or service prices.
        // Those are never allowed to defeat an exact product-zone price.
        $weak_primary = preg_match('/primary-buybox-cta-text|buybox-cta|eco[- ]?participation|livraison|shipping|mensualit|par mois|\/mois|alma|financement|abonnement|subscription|service partenaire|offre partenaire|deposit|acompte/i', $evidence) === 1;
        $exact_bridge = strpos($bridge_meta, 'exact-product-zone') !== false
            || strpos($bridge_meta, 'bridge-primary-product-zone-v1') !== false
            || strpos($bridge_meta, 'product-zone') !== false;

        // Strong anti-regression case observed on marketplace pages:
        // a tiny ancillary amount (for example 4.39) must not replace a hundreds-euro product price.
        if ($ratio >= 1.8 && $exact_bridge && ($weak_primary || ($a < 20.0 && $b >= 50.0))) {
            return $bridge;
        }

        // If the regular price is strongly supported by a Product Offer and the Bridge candidate
        // is explicitly a weak split/installment candidate, preserve the structured offer.
        $structured_offer = strpos($evidence, 'json-ld-product-offer') !== false
            || strpos($evidence, 'product-offer') !== false
            || strpos($evidence, 'json_ld') !== false;
        $split_bridge = strpos($bridge_meta, 'split-child') !== false || strpos($bridge_meta, 'split-text') !== false;
        if ($ratio >= 1.8 && $structured_offer && $split_bridge && !$weak_primary && !($a < 20.0 && $b >= 50.0)) {
            return $raw_regular;
        }

        // Fnac's previously validated exact product-zone path stays authoritative.
        if ($is_fnac && $exact_bridge) return $bridge;

        // ManoMano: exact product-zone evidence wins normal disagreements unless the stronger
        // structured-offer exception above is present.
        if ($is_manomano && $exact_bridge && $ratio >= 1.35) return $bridge;

        // Close values normally represent the same price formatted by two lanes.
        if ($ratio < 1.35) return $bridge;

        return $raw_regular;
    }

    /**
     * Brand authority resolver. Marketplace fields can sometimes expose the seller,
     * distributor or a generic product family as the brand. Explicit product facts
     * ("Marque: COLORWAY", Brand, Fabricant...) always outrank those weaker hints.
     */
    private function resolve_brand_authority(string $raw_brand, string $name, string $description, array $attributes, array $raw = []): string {
        $blocked = [
            'vae','vtt','ebike','e bike','velo','vélo','velo electrique','vélo électrique',
            'electric bike','bike','produit','product','fnac','manomano','marketplace','seller',
            'noir','black','blanc','white','orange','rouge','red','bleu','blue',
            'tv','television','télévision','televiseur','téléviseur','oled','qled','neo qled','led','lcd',
            'uhd','4k','8k','hdr','smart tv','smarttv','wifi','bluetooth','android tv','google tv',
            'robot','tondeuse','tondeuse robot','electrique','électrique','sans fil','jardin','outillage',
            'mini led','micro led','neo qled mini led','quantum mini led','quantum dot','neo qled','fhd','full hd','hd','hdr10','hdr10+','dolby vision','dolby atmos','nfc','usb','hdmi',
            'tizen','webos','ai','ia','batterie','lithium','lithium ion','autonomie','moteur','gaming','premium','pro','plus','max','ultra',
            'smartphone','telephone','téléphone','tablette','ordinateur','pc','laptop','notebook','ssd','ram','gpu','cpu','camera','appareil photo',
            'aspirateur','refrigerateur','réfrigérateur','congelateur','lave linge','lave vaisselle','lave','vaisselle','dishwasher','encastrable','pose libre','four','micro ondes','climatiseur','ventilateur','seche linge','sèche linge','machine a laver','machine à laver','plaque cuisson','hotte','cuisiniere','cuisinière'
        ];
        $normalize_candidate = function ($candidate) use ($blocked): string {
            $candidate = trim(wp_strip_all_tags((string)$candidate));
            $candidate = preg_replace('/\s{2,}/u', ' ', $candidate);
            $candidate = preg_replace('/\s+(?:modele|modèle|couleur|type|taille|poids|reference|référence)\s*[:\-].*$/iu', '', $candidate);
            $candidate = trim($candidate, " \t\n\r\0\x0B:;-|");
            if ($candidate === '' || mb_strlen($candidate) > 40) return '';
            $normalized = $this->normalize_comparison_text($candidate);
            if (in_array($normalized, $blocked, true)) return '';

            $generic_tokens = [
                'tv','television','televiseur','oled','qled','neo','mini','micro','led','lcd','uhd','fhd','hd','4k','8k','hdr','hdr10',
                'smart','wifi','bluetooth','quantum','dot','ai','ia','display','screen','ecran','robot','tondeuse','vae','vtt','ebike',
                'bike','batterie','gaming','premium','pro','plus','max','ultra',
                'lave','vaisselle','dishwasher','encastrable','refrigerateur','congelateur','four','aspirateur','seche','linge','machine','cuisson','hotte'
            ];
            $parts = preg_split('/[^\p{L}0-9]+/u', $normalized, -1, PREG_SPLIT_NO_EMPTY);
            if ($parts) {
                $generic_count = 0;
                foreach ($parts as $part) if (in_array($part, $generic_tokens, true)) $generic_count++;
                if ($generic_count === count($parts)) return '';
                if (count($parts) >= 2 && $generic_count >= count($parts) - 1 &&
                    preg_match('/\b(?:oled|qled|led|lcd|uhd|hdr|smart|quantum|mini|neo)\b/u', $normalized)) return '';
            }

            if (preg_match('/^(?:\d+[a-z]{0,3}|[a-z]?\d+[a-z0-9-]*)$/iu', $candidate)) return '';
            return sanitize_text_field($candidate);
        };

        // 0. Highest terminal authority: the Cloud multi-evidence brand report.
        // The parallel H5Q7 plugin remains isolated and does not touch/deactivate the legacy importer.
        // A Cloud brand is accepted only when it survived technology/generic rejection and has
        // medium/high/very_high confidence from multiple independent product evidence lanes.
        $bridge_report = is_array($raw['bridge_authority_report'] ?? null) ? $raw['bridge_authority_report'] : [];
        $bridge_brand = $normalize_candidate((string)($bridge_report['brand_after'] ?? ''));
        $bridge_confidence = strtolower(trim((string)($bridge_report['brand_confidence'] ?? '')));

        // Never trust a Cloud verdict blindly if the terminal plugin can prove it is a
        // technology-only composite. This is the final non-regression firewall.
        if ($bridge_brand !== '' && in_array($bridge_confidence, ['medium','high','very_high'], true)) {
            $identity = is_array($raw['bridge_identity_evidence'] ?? null) ? $raw['bridge_identity_evidence'] : [];
            $visual_authority = is_array($identity['visual_product_evidence_authority'] ?? null) ? $identity['visual_product_evidence_authority'] : [];
            $consensus = array_merge(
                (array)($visual_authority['brand_consensus'] ?? []),
                (array)($identity['visual_ocr_brand_consensus'] ?? []),
                (array)($identity['visual_text_brand_consensus'] ?? [])
            );
            foreach ($consensus as $consensus_raw) {
                $consensus_brand = $normalize_candidate($consensus_raw);
                if ($consensus_brand !== '') return $consensus_brand;
            }
            $bridge_haystack = $this->normalize_comparison_text(
                $name . ' ' . wp_strip_all_tags($description) . ' ' .
                wp_strip_all_tags((string)($raw['short_description'] ?? '')) . ' ' .
                implode(' ', (array)($identity['image_text_hints'] ?? [])) . ' ' .
                implode(' ', (array)($identity['image_ocr_text'] ?? []))
            );
            $bridge_norm = $this->normalize_comparison_text($bridge_brand);
            if ($bridge_norm !== '' && mb_strpos(' ' . $bridge_haystack . ' ', ' ' . $bridge_norm . ' ') !== false) return $bridge_brand;
            // An uncorroborated Cloud brand is advisory only; continue to local consensus.
        }

        // 0b. Product-image identity evidence supplied by Browser Bridge 2.0.20+.
        // A visual candidate is never trusted alone: it must also occur in the title or descriptions,
        // unless the Browser/Cloud has already marked it as an explicit brand candidate.
        $identity = is_array($raw['bridge_identity_evidence'] ?? null) ? $raw['bridge_identity_evidence'] : [];
        $identity_haystack = $this->normalize_comparison_text($name . ' ' . wp_strip_all_tags($description) . ' ' . wp_strip_all_tags((string)($raw['short_description'] ?? '')));
        $visual_candidates = array_merge(
            (array)($identity['visual_ocr_brand_consensus'] ?? []),
            (array)($identity['ocr_brand_candidates'] ?? []),
            (array)($identity['visual_text_brand_consensus'] ?? []),
            (array)($identity['image_brand_candidates'] ?? []),
            (array)($identity['explicit_brand_candidates'] ?? [])
        );
        foreach ($visual_candidates as $visual_raw) {
            $visual = $normalize_candidate($visual_raw);
            if ($visual === '') continue;
            $vn = $this->normalize_comparison_text($visual);
            if ($vn !== '' && mb_strpos(' ' . $identity_haystack . ' ', ' ' . $vn . ' ') !== false) return $visual;
        }

        // 1. Highest authority: explicit structured/product attribute labels.
        foreach ($attributes as $label => $value) {
            $normalized = $this->normalize_comparison_text((string)$label);
            if (!preg_match('/\b(?:marque|brand|fabricant|manufacturer|constructeur)\b/u', $normalized)) continue;
            $candidate = $normalize_candidate($value);
            if ($candidate === '') continue;
            $cn = $this->normalize_comparison_text($candidate);
            $corroboration = $this->normalize_comparison_text(
                $name . ' ' . wp_strip_all_tags($description) . ' ' .
                wp_strip_all_tags((string)($raw['short_description'] ?? '')) . ' ' .
                implode(' ', (array)($identity['image_text_hints'] ?? [])) . ' ' .
                implode(' ', (array)($identity['image_ocr_text'] ?? []))
            );
            if ($cn !== '' && mb_strpos(' ' . $corroboration . ' ', ' ' . $cn . ' ') !== false) return $candidate;
        }

        // 2. Explicit fact in product description. HTML boundaries are intentionally
        // used so the next marketplace field cannot be glued to the brand value.
        $patterns = [
            '/(?:marque|brand|fabricant|manufacturer|constructeur)\s*[:\-]\s*([^<\r\n;|]{1,60})/iu',
            '/(?:marque|brand|fabricant|manufacturer|constructeur)\s*[:\-]\s*([\p{L}0-9][\p{L}0-9 .&+\'’_-]{1,40}?)(?=\s+(?:modele|modèle|couleur|type|taille|poids|reference|référence)\s*[:\-]|$)/iu',
        ];
        foreach ($patterns as $pattern) {
            if (!preg_match($pattern, $description, $m)) continue;
            $candidate = $normalize_candidate($m[1]);
            if ($candidate === '') continue;
            $candidate_norm = $this->normalize_comparison_text($candidate);
            $corroboration = $this->normalize_comparison_text(
                $name . ' ' . wp_strip_all_tags((string)($raw['short_description'] ?? '')) . ' ' .
                implode(' ', (array)($identity['image_text_hints'] ?? [])) . ' ' .
                implode(' ', (array)($identity['image_ocr_text'] ?? []))
            );
            if ($candidate_norm !== '' && mb_strpos(' ' . $corroboration . ' ', ' ' . $candidate_norm . ' ') !== false) return $candidate;
        }

        // 3. Structured/schema brand becomes authoritative when it is a plausible
        // product brand and the product identity itself corroborates it. This avoids
        // choosing a technology token such as OLED/QLED as the brand when the title
        // already contains "Samsung", "LG", etc.
        $candidate = $normalize_candidate($raw_brand);
        if ($candidate !== '') {
            $identity_haystack = $this->normalize_comparison_text($name . ' ' . wp_strip_all_tags($description));
            $candidate_norm = $this->normalize_comparison_text($candidate);
            if ($candidate_norm !== '' && mb_strpos(' ' . $identity_haystack . ' ', ' ' . $candidate_norm . ' ') !== false) return $candidate;
            // Never promote an isolated schema/marketplace brand without independent corroboration.
        }

        // 4. Title evidence is never accepted alone. A trademark-like title token must
        // also be corroborated by description/short-description or visual evidence.
        $tokens = preg_split('/[\s\-–—|:;,\/]+/u', trim($name), -1, PREG_SPLIT_NO_EMPTY);
        $corroboration_haystack = $this->normalize_comparison_text(
            wp_strip_all_tags($description) . ' ' .
            wp_strip_all_tags((string)($raw['short_description'] ?? '')) . ' ' .
            implode(' ', (array)($identity['image_text_hints'] ?? [])) . ' ' .
            implode(' ', (array)($identity['image_alt_hints'] ?? [])) . ' ' .
            implode(' ', (array)($identity['image_ocr_text'] ?? []))
        );
        foreach ($tokens as $token) {
            $clean = preg_replace('/[^\p{L}0-9&+\'’_-]/u', '', $token);
            if ($clean === '' || mb_strlen($clean) < 2) continue;
            if (mb_strlen($clean) === 2 && $clean !== mb_strtoupper($clean)) continue;
            $candidate = $normalize_candidate($clean);
            if ($candidate === '') continue;
            $cn = $this->normalize_comparison_text($candidate);
            if ($cn !== '' && mb_strpos(' ' . $corroboration_haystack . ' ', ' ' . $cn . ' ') !== false) return $candidate;
        }

        return $this->recover_brand_from_product_content($name, $description, $attributes);
    }

    private function detect_brand(string $raw_brand, string $name, array $attributes): string {
        $brand = trim(wp_strip_all_tags($raw_brand));
        if ($brand !== '') return sanitize_text_field($brand);

        foreach ($attributes as $label => $value) {
            $normalized = $this->normalize_comparison_text((string)$label);
            if (preg_match('/\b(?:marque|brand|fabricant|manufacturer|constructeur)\b/u', $normalized)) {
                $candidate = trim(wp_strip_all_tags((string)$value));
                if ($candidate !== '') return sanitize_text_field($candidate);
            }
        }

        // Les titres de marketplaces placent généralement la marque avant le modèle.
        // On privilégie un mot en majuscules ou en casse de marque, tout en excluant
        // les mots génériques du produit et les unités techniques.
        $tokens = preg_split('/[\s\-–—|:;,\/]+/u', trim($name), -1, PREG_SPLIT_NO_EMPTY);
        $blocked = ['TRONCONNEUSE','THERMIQUE','ELECTRIQUE','SANS','FIL','GUIDE','CHAINE','PRODUIT','MOTEUR','OUTIL','OUTILLAGE','REMORQUE','TONDEUSE','PERCEUSE','SCIE','POMPE','CLIMATISEUR','VENTILATEUR','ENCEINTE','CASQUE','SMARTPHONE','TELEVISEUR'];
        foreach ($tokens as $token) {
            $clean = preg_replace('/[^\p{L}0-9]/u', '', $token);
            if ($clean === '' || mb_strlen($clean) < 3 || preg_match('/^\d+(?:CC|CM|MM|KG|W|V|L)?$/iu', $clean)) continue;
            $upper = mb_strtoupper(remove_accents($clean));
            if (in_array($upper, $blocked, true)) continue;
            if ($clean === mb_strtoupper($clean) && preg_match('/\p{L}/u', $clean)) return sanitize_text_field($clean);
        }
        return '';
    }

    private function recover_brand_from_product_content(string $name, string $description, array $attributes): string {
        $plain = trim(wp_strip_all_tags($description));
        if ($plain === '') return '';

        $patterns = [
            '/^\s*([\p{L}0-9][\p{L}0-9 .&+\'’_-]{1,30})\s*[\-–—:]\s+/u',
            '/\b(?:marque|brand|fabricant|manufacturer|constructeur)\s*[:\-]\s*([\p{L}0-9][\p{L}0-9 .&+\'’_-]{1,40})/iu',
            '/\b([\p{L}0-9][\p{L}0-9 .&+\'’_-]{1,30})\s+est\s+une\s+marque\b/iu',
        ];
        $blocked = ['produit','tondeuse','robot','nouveau','neuf','description','caracteristiques','caractéristiques','jardin','outillage'];
        foreach ($patterns as $pattern) {
            if (!preg_match($pattern, $plain, $m)) continue;
            $candidate = trim(preg_replace('/\s{2,}/u', ' ', (string)$m[1]));
            $normalized = $this->normalize_comparison_text($candidate);
            if ($candidate === '' || mb_strlen($candidate) > 40 || in_array($normalized, $blocked, true)) continue;
            if (count(preg_split('/\s+/u', $candidate, -1, PREG_SPLIT_NO_EMPTY)) > 4) continue;
            return sanitize_text_field($candidate);
        }
        return '';
    }

    private function categories_need_recovery(array $categories): bool {
        if (!$categories) return true;
        $generic_or_technology = [
            'produits importes','produit importe','imported products','products',
            'oled','qled','neo qled','led','lcd','uhd','4k','8k','hdr','smart tv','wifi','bluetooth',
            'samsung','lg','sony','philips','panasonic','tcl','hisense','colorway','gardena'
        ];
        $meaningful = array_values(array_filter($categories, function ($category) use ($generic_or_technology) {
            $normalized = $this->normalize_comparison_text((string)$category);
            return $normalized !== '' && !in_array($normalized, $generic_or_technology, true);
        }));
        foreach ($meaningful as $category) {
            if (preg_match('/[^\p{Latin}0-9 &+\-\'’]/u', $category)) return true;
            $normalized = $this->normalize_comparison_text((string)$category);
            if (preg_match('/^(?:oled|qled|neo qled|led|lcd|uhd|4k|8k|hdr)$/u', $normalized)) return true;
        }
        return count($meaningful) === 0;
    }

    private function recover_categories_from_product_content(string $name, string $description, array $attributes): array {
        $haystack = $this->normalize_comparison_text($name . ' ' . wp_strip_all_tags($description) . ' ' . implode(' ', array_keys($attributes)) . ' ' . implode(' ', array_values($attributes)));
        $rules = [
            '/\b(?:robot\s+tondeuse|tondeuse\s+robot|tondeuse|landroid)\b/u' => ['Tondeuses'],
            '/\btronconneuse\b/u' => ['Tronçonneuses'],
            '/\bdebroussailleuse\b/u' => ['Débroussailleuses'],
            '/\bremorque\b/u' => ['Remorques'],
            '/\bclimatiseur\b/u' => ['Climatiseurs'],
            '/\bventilateur\b/u' => ['Ventilateurs'],
            '/\benceinte\b/u' => ['Enceintes'],
            '/\bcasque\b/u' => ['Casques'],
            '/\bsmartphone|telephone\b/u' => ['Smartphones'],
            '/\b(?:lave[ -]?vaisselle|dishwasher)\b/u' => ['Électroménager', 'Gros électroménager', 'Lave-vaisselle'],
            '/\b(?:lave[ -]?linge|machine\s+[aà]\s+laver|washing machine)\b/u' => ['Électroménager', 'Gros électroménager', 'Lave-linge'],
            '/\b(?:s[eè]che[ -]?linge|tumble dryer)\b/u' => ['Électroménager', 'Gros électroménager', 'Sèche-linge'],
            '/\b(?:r[eé]frig[eé]rateur|frigo|refrigerator)\b/u' => ['Électroménager', 'Gros électroménager', 'Réfrigérateurs'],
            '/\b(?:cong[eé]lateur|freezer)\b/u' => ['Électroménager', 'Gros électroménager', 'Congélateurs'],
            '/\b(?:micro[ -]?ondes|microwave)\b/u' => ['Électroménager', 'Cuisson', 'Micro-ondes'],
            '/\b(?:four\s+encastrable|four\s+[eé]lectrique|oven)\b/u' => ['Électroménager', 'Cuisson', 'Fours'],
            '/\b(?:plaque\s+de\s+cuisson|table\s+de\s+cuisson|induction\s+hob|cooktop)\b/u' => ['Électroménager', 'Cuisson', 'Plaques de cuisson'],
            '/\b(?:hotte\s+aspirante|cooker hood|range hood)\b/u' => ['Électroménager', 'Cuisson', 'Hottes'],
            '/\b(?:aspirateur|vacuum cleaner)\b/u' => ['Électroménager', 'Entretien de la maison', 'Aspirateurs'],
            '/\b(?:tv|televiseur|téléviseur|television|télévision)\b.*\b(?:oled|qled|led|lcd|uhd|4k|8k|smart)\b|\b(?:oled|qled)\s+(?:tv|televiseur|téléviseur)\b/u' => ['High-tech', 'TV et vidéo', 'Téléviseurs'],
            '/\b(?:trottinette|e[- ]?scooter|electric scooter|scooter electrique|off[- ]?road e[- ]?scooter)\b/u' => ['Sports et loisirs', 'Mobilité urbaine', 'Trottinettes électriques'],
            '/\b(?:velo|vélo|vae|vtt|e[- ]?bike|bicyclette|fat\s*bike)\b/u' => ['Sports et loisirs', 'Cyclisme', 'Vélos électriques'],
            '/\bperceuse\b/u' => ['Perceuses'],
        ];
        foreach ($rules as $pattern => $categories) {
            if (preg_match($pattern, $haystack)) return $categories;
        }
        return [];
    }

    private function infer_categories(string $name, array $attributes): array {
        $haystack = $this->normalize_comparison_text($name . ' ' . implode(' ', array_keys($attributes)) . ' ' . implode(' ', array_values($attributes)));
        $rules = [
            '/\btronconneuse\b/u' => ['Jardin', 'Outillage de jardin', 'Tronçonneuses'],
            '/\btondeuse\b/u' => ['Jardin', 'Outillage de jardin', 'Tondeuses'],
            '/\bdebroussailleuse\b/u' => ['Jardin', 'Outillage de jardin', 'Débroussailleuses'],
            '/\bremorque\b/u' => ['Automobile et transport', 'Remorques'],
            '/\bclimatiseur\b/u' => ['Climatisation et ventilation', 'Climatiseurs'],
            '/\bventilateur\b/u' => ['Climatisation et ventilation', 'Ventilateurs'],
            '/\benceinte\b/u' => ['High-tech', 'Audio', 'Enceintes'],
            '/\bcasque\b/u' => ['High-tech', 'Audio', 'Casques'],
            '/\bsmartphone|telephone\b/u' => ['High-tech', 'Téléphonie', 'Smartphones'],
            '/\b(?:lave[ -]?vaisselle|dishwasher)\b/u' => ['Électroménager', 'Gros électroménager', 'Lave-vaisselle'],
            '/\b(?:lave[ -]?linge|machine\s+[aà]\s+laver|washing machine)\b/u' => ['Électroménager', 'Gros électroménager', 'Lave-linge'],
            '/\b(?:s[eè]che[ -]?linge|tumble dryer)\b/u' => ['Électroménager', 'Gros électroménager', 'Sèche-linge'],
            '/\b(?:r[eé]frig[eé]rateur|frigo|refrigerator)\b/u' => ['Électroménager', 'Gros électroménager', 'Réfrigérateurs'],
            '/\b(?:cong[eé]lateur|freezer)\b/u' => ['Électroménager', 'Gros électroménager', 'Congélateurs'],
            '/\b(?:micro[ -]?ondes|microwave)\b/u' => ['Électroménager', 'Cuisson', 'Micro-ondes'],
            '/\b(?:four\s+encastrable|four\s+[eé]lectrique|oven)\b/u' => ['Électroménager', 'Cuisson', 'Fours'],
            '/\b(?:plaque\s+de\s+cuisson|table\s+de\s+cuisson|induction\s+hob|cooktop)\b/u' => ['Électroménager', 'Cuisson', 'Plaques de cuisson'],
            '/\b(?:hotte\s+aspirante|cooker hood|range hood)\b/u' => ['Électroménager', 'Cuisson', 'Hottes'],
            '/\b(?:aspirateur|vacuum cleaner)\b/u' => ['Électroménager', 'Entretien de la maison', 'Aspirateurs'],
            '/\b(?:tv|televiseur|téléviseur|television|télévision)\b.*\b(?:oled|qled|led|lcd|uhd|4k|8k|smart)\b|\b(?:oled|qled)\s+(?:tv|televiseur|téléviseur)\b/u' => ['High-tech', 'TV et vidéo', 'Téléviseurs'],
            '/\b(?:trottinette|e[- ]?scooter|electric scooter|scooter electrique|off[- ]?road e[- ]?scooter)\b/u' => ['Sports et loisirs', 'Mobilité urbaine', 'Trottinettes électriques'],
            '/\b(?:velo|vélo|vae|vtt|e[- ]?bike|bicyclette|fat\s*bike)\b/u' => ['Sports et loisirs', 'Cyclisme', 'Vélos électriques'],
            '/\bperceuse\b/u' => ['Outillage', 'Outillage électroportatif', 'Perceuses'],
        ];
        foreach ($rules as $pattern => $path) if (preg_match($pattern, $haystack)) return $path;
        return ['Produits importés'];
    }

    private function recover_direct_product_facts_from_text(string $short, string $description): array {
        $plain = html_entity_decode(wp_strip_all_tags($short . ' ' . $description), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = preg_replace('/[\p{Cf}\x{00AD}]+/u', ' ', (string)$plain);
        $plain = trim(preg_replace('/\s{2,}/u', ' ', (string)$plain));
        if ($plain === '') return [];

        // Stop before seller/contact/service identity: these are never product facts.
        $plain = preg_split('/(?:Office\s+hours|Business\s+hours|Email|E-mail|WhatsApp|Address|Adresse|Customer\s+service|Contact\s+us)\s*[:：]?/iu', $plain, 2)[0] ?? $plain;
        $labels = [
            'Battery' => 'Batterie',
            'Max speed' => 'Vitesse maximale',
            'Dual Motor' => 'Motorisation',
            'Speed level' => 'Niveaux de vitesse',
            'Max range' => 'Autonomie maximale',
            'Max load' => 'Charge maximale',
            'Charging time' => 'Temps de charge',
            'Waterproof level' => 'Indice de protection',
            'Brake system' => 'Système de freinage',
            'Net weight' => 'Poids net',
            'Expend size' => 'Dimensions dépliées',
            'Expanded size' => 'Dimensions dépliées',
            'Unfolded size' => 'Dimensions dépliées',
            'Unfolded dimensions' => 'Dimensions dépliées',
            'Fold size' => 'Dimensions pliées',
            'Packing size' => 'Dimensions emballage',
        ];
        $keys = array_keys($labels);
        $key_pattern = implode('|', array_map(static fn($k)=>preg_quote($k, '/'), $keys));

        // Marketplace text is frequently flattened with no separator at all:
        // "20.8AhMax speed...e-brakeNet weight...". Insert a synthetic boundary
        // before every known product-fact label, even when there is no word boundary.
        $segmented = preg_replace('/(?=(' . $key_pattern . '))/iu', "\n", $plain);
        $segments = preg_split('/\n+/u', (string)$segmented, -1, PREG_SPLIT_NO_EMPTY);
        $facts = [];
        foreach ($segments as $segment) {
            $segment = trim($segment);
            foreach ($labels as $source_label => $target_label) {
                if (stripos($segment, $source_label) !== 0) continue;
                $value = trim(substr($segment, strlen($source_label)));
                $value = preg_replace('/^\s*[:：]?\s*/u', '', (string)$value);
                $value = trim((string)preg_replace('/\s{2,}/u', ' ', (string)$value), " \t\n\r\0\x0B,;|-");
                if ($value === '' || mb_strlen($value) > 260) break;
                if (preg_match('/(?:@|https?:\/\/|www\.|whatsapp|office\s+hours|address\s*:|adresse\s*:)/iu', $value)) break;
                $facts[$target_label] = sanitize_text_field($value);
                break;
            }
        }
        return $facts;
    }

    private function recover_inline_product_media(string $description, string $name, array $images, array $report): array {
        // 5.3.55 Universal Gallery Cohort Completion Authority.
        // The previous lane only ran when fewer than 2 media already existed. That made a
        // partial 3/6 or 3/7 gallery look "good enough" and silently discarded source-owned
        // views already present in the exact product description. Completion is now additive:
        // U = validated_gallery ∪ exact_description_images, followed by identity-safe dedupe.
        $images = array_values(array_unique(array_filter(array_map('esc_url_raw', $images))));
        if ($description === '' || !preg_match_all("~<img\\b[^>]*(?:src|data-src)=[\"']([^\"']+)[\"'][^>]*>~iu", $description, $m, PREG_SET_ORDER)) {
            $report['cohort_completion'] = [
                'version'=>'universal-gallery-cohort-v2',
                'initial_count'=>count($images),
                'description_candidates'=>0,
                'final_count'=>count($images),
                'additive'=>true,
            ];
            return ['images'=>$images, 'report'=>$report];
        }

        $identity = $this->normalize_comparison_text($name);
        $stop = ['electric','scooter','velo','vélo','product','produit','powerful','motor','battery','range','speed','max','dual','the','and','with'];
        $tokens = array_values(array_filter(preg_split('/\\s+/u', $identity, -1, PREG_SPLIT_NO_EMPTY), static function($t) use ($stop){
            return mb_strlen($t) >= 2 && !in_array($t, $stop, true);
        }));

        // Hosts already validated by Cloud/Browser are strong cohort evidence. This is crucial
        // for marketplace CDNs whose opaque URLs contain no product-name tokens.
        $validated_hosts = [];
        foreach ($images as $known) {
            $host = strtolower((string)wp_parse_url($known, PHP_URL_HOST));
            if ($host !== '') $validated_hosts[$host] = true;
        }
        foreach ((array)($report['accepted'] ?? []) as $item) {
            $known = is_array($item) ? (string)($item['url'] ?? '') : (string)$item;
            $host = strtolower((string)wp_parse_url($known, PHP_URL_HOST));
            if ($host !== '') $validated_hosts[$host] = true;
        }

        $recovered = [];
        foreach ($m as $match) {
            $src = esc_url_raw(html_entity_decode((string)($match[1] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if ($src === '') continue;
            $host = strtolower((string)wp_parse_url($src, PHP_URL_HOST));
            $probe = $this->normalize_comparison_text((string)wp_parse_url($src, PHP_URL_PATH));
            $hits = 0;
            foreach (array_unique($tokens) as $token) if ($token !== '' && strpos($probe, $token) !== false) $hits++;

            // Two independent acceptance lanes:
            // A) same CDN/asset host as an already validated product image;
            // B) strong product identity in the URL path (legacy fallback).
            $host_corroborated = $host !== '' && !empty($validated_hosts[$host]);
            $identity_corroborated = $hits >= 2;
            if (!$host_corroborated && !$identity_corroborated) continue;

            $canonical = $this->canonical_media_evidence_url($src);
            if ($canonical === '') continue;
            $recovered[$canonical] = [
                'url'=>$src,
                'source'=>'inline-product-description-cohort',
                'ownership_verified'=>true,
                'role'=>'product-gallery',
                'reasons'=>array_values(array_filter([
                    'exact_product_description_image',
                    $host_corroborated ? 'validated_product_cdn_host_match' : '',
                    $identity_corroborated ? 'product_identity_token_match' : '',
                    'additive_gallery_completion',
                ])),
                'view_key'=>'description-cohort-' . (count($recovered)+1),
            ];
            if (count($recovered) >= 40) break;
        }

        if (!$recovered) {
            $report['cohort_completion'] = [
                'version'=>'universal-gallery-cohort-v2',
                'initial_count'=>count($images),
                'description_candidates'=>count($m),
                'recovered_count'=>0,
                'final_count'=>count($images),
                'additive'=>true,
            ];
            return ['images'=>$images, 'report'=>$report];
        }

        // Canonical URL union: a description image can augment an already non-empty Cloud
        // gallery. Never replace a validated URL; only add missing canonical views.
        $merged = [];
        foreach ($images as $known) {
            $canonical = $this->canonical_media_evidence_url($known);
            if ($canonical !== '') $merged[$canonical] = $known;
        }
        foreach ($recovered as $canonical => $item) if (!isset($merged[$canonical])) $merged[$canonical] = $item['url'];

        $accepted = [];
        $accepted_seen = [];
        foreach ((array)($report['accepted'] ?? []) as $item) {
            $url = is_array($item) ? (string)($item['url'] ?? '') : (string)$item;
            $key = $this->canonical_media_evidence_url($url);
            if ($key === '' || isset($accepted_seen[$key])) continue;
            $accepted_seen[$key] = true;
            $accepted[] = $item;
        }
        foreach ($recovered as $canonical => $item) {
            if (isset($accepted_seen[$canonical])) continue;
            $accepted_seen[$canonical] = true;
            $accepted[] = $item;
        }

        $report['accepted'] = $accepted;
        $report['recovery_lane'] = 'universal_gallery_cohort_completion_v2';
        $report['recovered_count'] = count(array_diff_key($recovered, array_fill_keys(array_map([$this,'canonical_media_evidence_url'], $images), true)));
        $report['cohort_completion'] = [
            'version'=>'universal-gallery-cohort-v2',
            'initial_count'=>count($images),
            'description_candidates'=>count($m),
            'recovered_count'=>max(0, count($merged)-count($images)),
            'final_count'=>count($merged),
            'coverage_ratio'=>count($merged) > 0 ? 1.0 : 0.0,
            'additive'=>true,
            'host_corroboration'=>true,
            'no_two_image_early_exit'=>true,
        ];
        return ['images'=>array_values($merged), 'report'=>$report];
    }

    private function canonical_media_evidence_url(string $url): string {
        $url = esc_url_raw(html_entity_decode(trim($url), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($url === '') return '';
        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['host'])) return $url;
        $scheme = strtolower((string)($parts['scheme'] ?? 'https'));
        $host = strtolower((string)$parts['host']);
        $path = (string)($parts['path'] ?? '/');
        // Strip common resolution/crop query parameters while preserving asset identity.
        $query = [];
        if (!empty($parts['query'])) {
            parse_str((string)$parts['query'], $query);
            foreach (array_keys($query) as $key) if (preg_match('/^(?:w|h|width|height|fit|crop|quality|q|format|fm|auto)$/i', (string)$key)) unset($query[$key]);
            ksort($query);
        }
        return $scheme . '://' . $host . $path . ($query ? '?' . http_build_query($query) : '');
    }

    private function recover_structured_measurements(array $raw, array $attributes, string $description): array {
        $positive_decimal = function ($value): string {
            $decimal = trim((string)$value) !== '' ? $this->decimal($value) : '';
            return ($decimal !== '' && (float)$decimal > 0) ? $decimal : '';
        };
        $result = [
            'weight' => $positive_decimal($raw['weight'] ?? ''),
            'length' => $positive_decimal($raw['length'] ?? ''),
            'width' => $positive_decimal($raw['width'] ?? ''),
            'height' => $positive_decimal($raw['height'] ?? ''),
        ];
        $weight_unit = (string)get_option('woocommerce_weight_unit', 'kg');
        $dimension_unit = (string)get_option('woocommerce_dimension_unit', 'cm');

        $rows = [];
        foreach ($attributes as $label => $value) $rows[] = [(string)$label, (string)$value];
        foreach ((array)($raw['specifications'] ?? []) as $row) {
            if (!is_array($row)) continue;
            $rows[] = [(string)($row['label'] ?? ($row['name'] ?? '')), (string)($row['value'] ?? '')];
        }

        foreach ($rows as [$label, $value]) {
            $normalized = $this->normalize_comparison_text($label);
            if ($result['weight'] === '' && preg_match('/\b(?:poids|weight|masse)\b/u', $normalized)) {
                $candidate = $this->parse_weight_value($value, $weight_unit);
                if ($candidate !== '') $result['weight'] = $candidate;
            }
            if (($result['length'] === '' || $result['width'] === '' || $result['height'] === '') && preg_match('/\b(?:dimensions?|dimension du produit|taille du produit|taille du velo|taille du vélo|bike size|product dimensions?)\b/u', $normalized)) {
                $dims = $this->parse_dimensions_value($value, $dimension_unit);
                foreach (['length','width','height'] as $key) if ($result[$key] === '' && $dims[$key] !== '') $result[$key] = $dims[$key];
            }
            $individual_dimension_labels = [
                'length' => '/\b(?:longueur|length|profondeur|depth)\b/u',
                'width'  => '/\b(?:largeur|width)\b/u',
                'height' => '/\b(?:hauteur|height)\b/u',
            ];
            foreach ($individual_dimension_labels as $dimension_key => $pattern) {
                if ($result[$dimension_key] !== '' || !preg_match($pattern, $normalized)) continue;
                if (preg_match('/(\d+(?:[.,]\d+)?)\s*(mm|cm|m|in|inch|inches)?/iu', $value, $m)) {
                    $unit = $m[2] ?: $dimension_unit;
                    $result[$dimension_key] = $this->convert_dimension((float)str_replace(',', '.', $m[1]), $unit, $dimension_unit);
                }
            }
        }

        // Shipping Dimensions Authority: les mesures peuvent arriver par le DOM rendu,
        // les attributs, specifications[] ou specifications_html. On fusionne ces preuves
        // avant le dernier secours afin de ne jamais laisser WooCommerce sans dimensions
        // quand la fiche externe les expose explicitement.
        $measurement_corpus = $description . ' ' . (string)($raw['specifications_html'] ?? '');
        foreach ($rows as [$label, $value]) $measurement_corpus .= ' ' . $label . ': ' . $value;
        $plain = html_entity_decode(preg_replace('/<[^>]+>/', ' ', $measurement_corpus), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = preg_replace('/[\p{Cf}\x{00AD}]+/u', ' ', (string)$plain);
        $plain = trim(preg_replace('/\s{2,}/u', ' ', (string)$plain));
        if ($result['weight'] === '' && preg_match('/\b(?:poids\s+net|net\s+weight)\s*[:\-]?\s*(\d+(?:[.,]\d+)?)(?:\s*[±+]\s*\d+(?:[.,]\d+)?)?\s*(kg|kilogrammes?|g|grammes?|lb|lbs|pounds?)/iu', $plain, $m)) {
            $result['weight'] = $this->convert_weight((float)str_replace(',', '.', $m[1]), $m[2], $weight_unit);
        }
        if ($result['weight'] === '' && preg_match('/\b(?:poids|weight)\s*[:\-]?\s*(?:(?:poids\s+brut|gross\s+weight)\s*[:\-]?\s*\d+(?:[.,]\d+)?\s*(?:kg|kilogrammes?|g|grammes?|lb|lbs|pounds?)\s*[\/;,]\s*)?(?:(?:poids\s+net|net\s+weight)\s*[:\-]?\s*)?(\d+(?:[.,]\d+)?)\s*(kg|kilogrammes?|g|grammes?|lb|lbs|pounds?)/iu', $plain, $m)) {
            $result['weight'] = $this->convert_weight((float)str_replace(',', '.', $m[1]), $m[2], $weight_unit);
        }
        if (($result['length'] === '' || $result['width'] === '' || $result['height'] === '') && preg_match('/\b(?:dimensions?(?:\s+du\s+produit)?|taille\s+du\s+(?:produit|velo|vélo)|bike\s+size|product\s+dimensions?)\s*(?:\([^)]*\))?\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*(?:\(\s*)?(mm|cm|m|in|inch|inches)?(?:\s*\))?/iu', $plain, $m)) {
            $unit = $m[4] ?: $dimension_unit;
            $values = [$m[1],$m[2],$m[3]];
            foreach (['length','width','height'] as $i => $key) if ($result[$key] === '') $result[$key] = $this->convert_dimension((float)str_replace(',', '.', $values[$i]), $unit, $dimension_unit);
        }
        return $result;
    }

    private function parse_weight_value(string $value, string $target_unit): string {
        if (!preg_match('/(\d+(?:[.,]\d+)?)(?:\s*[±+]\s*\d+(?:[.,]\d+)?)?\s*(kg|kilogrammes?|g|grammes?|lb|lbs|pounds?)/iu', $value, $m)) return '';
        return $this->convert_weight((float)str_replace(',', '.', $m[1]), $m[2], $target_unit);
    }

    private function parse_dimensions_value(string $value, string $target_unit): array {
        $out = ['length'=>'','width'=>'','height'=>''];
        if (!preg_match('/(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*(?:\(\s*)?(mm|cm|m|in|inch|inches)?(?:\s*\))?/iu', $value, $m)) return $out;
        $unit = $m[4] ?: $target_unit;
        foreach (['length','width','height'] as $i => $key) $out[$key] = $this->convert_dimension((float)str_replace(',', '.', $m[$i+1]), $unit, $target_unit);
        return $out;
    }

    private function convert_weight(float $value, string $from, string $to): string {
        $from = mb_strtolower(remove_accents($from));
        if (preg_match('/^(?:kilogramme|kilogrammes|kg)$/', $from)) $from = 'kg';
        elseif (preg_match('/^(?:gramme|grammes|g)$/', $from)) $from = 'g';
        elseif (preg_match('/^(?:lb|lbs|pound|pounds)$/', $from)) $from = 'lbs';
        if (function_exists('wc_get_weight')) return wc_format_decimal(wc_get_weight($value, $to, $from), 4);
        return wc_format_decimal($value, 4);
    }

    private function convert_dimension(float $value, string $from, string $to): string {
        $from = mb_strtolower(remove_accents($from));
        if (in_array($from, ['inch','inches'], true)) $from = 'in';
        if (function_exists('wc_get_dimension')) return wc_format_decimal(wc_get_dimension($value, $to, $from), 4);
        return wc_format_decimal($value, 4);
    }

    private function normalize_comparison_text(string $value): string {
        $value = remove_accents(mb_strtolower(trim($value)));
        $value = preg_replace('/[^a-z0-9]+/u', ' ', $value);
        return trim(preg_replace('/\s{2,}/u', ' ', (string)$value));
    }

    private function meaningful_words(string $value): array {
        $stop = ['avec','sans','pour','dans','sur','une','des','les','le','la','un','du','de','et','ou','au','aux','ce','cet','cette','ces','son','sa','ses','votre','vos','plus','par','est','sont','offre','produit'];
        $words = preg_split('/\s+/u', $value, -1, PREG_SPLIT_NO_EMPTY);
        return array_values(array_unique(array_filter($words, static function ($word) use ($stop) {
            return mb_strlen($word) >= 3 && !in_array($word, $stop, true);
        })));
    }

    private function is_commerce_noise_attribute(string $label, string $value = ''): bool {
        $label_normalized = $this->normalize_comparison_text($label);
        $value_normalized = $this->normalize_comparison_text($value);
        $pattern = '/\b(?:financement|financing|paiement|payment|mensualite|credit|taeg|taux|apport|acompte|echeance|j\s*(?:\+\s*)?\d+|3\s*x|4\s*x|klarna|paypal|alma|oney|cofidis|sofinco|frais|livraison|delivery|vendeur|seller|merchant|offre|offer|prix|price|remise|discount|cashback|eco\s*participation|assurance)\b/u';
        if (preg_match($pattern, $label_normalized)) return true;

        // A generic 3X/4X row is a financing selector, never a technical feature.
        if (preg_match('/^(?:3\s*x|4\s*x)(?:\s+(?:3\s*x|4\s*x))*$/u', trim($label_normalized . ' ' . $value_normalized))) return true;
        return false;
    }

    private function sanitize_specification_rows(array $rows): array {
        return MACE5311_SPI_Attribute_Firewall::sanitize_rows($rows);
    }

    private function sanitize_specifications_html(string $html): string {
        return MACE5311_SPI_Attribute_Firewall::sanitize_html($html);
    }

    private function format_description(string $value, bool $short = false, string $source_format = ''): string {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace('~<(script|style|noscript|iframe|form|button|input|svg|canvas)\b[^>]*>.*?</\1>~is', '', $value);
        $value = trim($value);
        if ($value === '') return '';

        $has_structure = (bool) preg_match('~<(p|div|section|article|ul|ol|li|br|h[1-6]|table|thead|tbody|tfoot|tr|th|td|dl|dt|dd|blockquote|pre|figure|figcaption)\b~i', $value);
        $source_fidelity = !$short && in_array($source_format, [
            'source-rendered-semantic-html-v2',
            'source-heading-range-html-v2',
            'source-dom-html-v1',
        ], true);

        // 5.3.27 Source Layout Fidelity: when Browser Bridge / Cloud explicitly
        // marks the description as source-authoritative HTML, the plugin must not
        // reinterpret, regroup or append unrelated product sections. Its only job
        // is safe HTML sanitization while preserving source order and block layout.
        if (!$has_structure && !$source_fidelity) {
            $plain = wp_strip_all_tags($value, false);
            $plain = preg_replace('/[\p{Cf}\x{00AD}]+/u', ' ', (string)$plain);
            $plain = preg_replace('/\r\n?|\x{2028}|\x{2029}/u', "\n", (string)$plain);

            // 5.3.25 Safe Presentation Restore: marketplace captures can be perfectly
            // complete while arriving as one flattened lowercase string. Restore only
            // explicit section boundaries and sentence boundaries; never rewrite facts.
            $section_pattern = '(?:caract[ée]ristiques?(?:\s+techniques?)?|fonctionnalit[ée]s?|sp[ée]cifications?|points?\s+forts?|avantages?|contenu(?:\s+de\s+la\s+bo[iî]te)?|livr[ée]\s+avec|dimensions?\s+du\s+produit)';
            $plain = preg_replace('/\s+(?=(' . $section_pattern . ')\s*:)/iu', "\n", (string)$plain);
            $plain = preg_replace('/^(' . $section_pattern . ')\s*:\s*/imu', "$1 :\n", (string)$plain);
            $plain = preg_replace('/([.!?])\s+(?=[\p{L}0-9])/u', "$1\n", (string)$plain);

            $lines = array_values(array_filter(array_map('trim', preg_split('/\n+/u', (string)$plain))));
            $blocks = []; $list = [];
            $flush = static function () use (&$blocks, &$list): void {
                if ($list) {
                    $blocks[] = '<ul><li>' . implode('</li><li>', array_map('esc_html', $list)) . '</li></ul>';
                    $list = [];
                }
            };
            foreach ($lines as $line) {
                if (preg_match('/^(?:[-•*]|✓|✔)\s+(.+)$/u', $line, $m)) { $list[] = $m[1]; continue; }
                $flush();

                if (preg_match('/^(' . $section_pattern . ')\s*:?$/iu', $line, $m)) {
                    $heading = trim((string)$m[1]);
                    $heading = mb_strtoupper(mb_substr($heading, 0, 1)) . mb_substr($heading, 1);
                    $blocks[] = '<h3>' . esc_html($heading) . '</h3>';
                    continue;
                }

                if (preg_match('/^([^:]{2,80}):\s+(.+)$/u', $line, $m)) {
                    $blocks[] = '<p><strong>' . esc_html(trim($m[1])) . ' :</strong> ' . esc_html(trim($m[2])) . '</p>';
                } else {
                    $blocks[] = '<p>' . esc_html($line) . '</p>';
                }
            }
            $flush();
            $value = implode("\n", $blocks);
        } else {
            // 5.3.27 Source Layout Fidelity: Browser Bridge can return a faithful rendered DOM
            // made mostly of <div>/<section>/<article> blocks. Those elements are semantic
            // layout boundaries even when there are no <p> tags. Never strip/flatten them.
            // Preserve source ordering and native block boundaries exactly; wpautop is only
            // allowed when the fragment does not already carry block-level structure.
            $has_block_dom = (bool) preg_match('~<(?:p|div|section|article|ul|ol|li|h[1-6]|table|dl|dt|dd|blockquote|pre)\b~i', $value);
            if (!$has_block_dom) $value = wpautop($value, false);
        }

        $allowed = wp_kses_allowed_html('post');
        // WordPress versions/themes differ slightly in their HTML5 KSES map.
        // Explicitly preserve harmless structural elements required to reproduce
        // source presentation faithfully. No executable/style attributes are added.
        foreach (['div','section','article','figure','figcaption','blockquote','pre','dl','dt','dd','thead','tbody','tfoot'] as $tag) {
            if (!isset($allowed[$tag])) $allowed[$tag] = [];
        }
        foreach (['table','tr','ul','ol','li','p','h1','h2','h3','h4','h5','h6','strong','b','em','i','u','small','sup','sub','br','hr'] as $tag) {
            if (!isset($allowed[$tag])) $allowed[$tag] = [];
        }
        if (isset($allowed['th'])) $allowed['th'] = array_merge($allowed['th'], ['scope'=>true,'colspan'=>true,'rowspan'=>true]);
        else $allowed['th'] = ['scope'=>true,'colspan'=>true,'rowspan'=>true];
        if (isset($allowed['td'])) $allowed['td'] = array_merge($allowed['td'], ['colspan'=>true,'rowspan'=>true]);
        else $allowed['td'] = ['colspan'=>true,'rowspan'=>true];

        $formatted = wp_kses($value, $allowed);
        if ($short && strlen(wp_strip_all_tags($formatted)) > 1200) {
            $plain_short = trim(wp_strip_all_tags($formatted));
            $sentences = preg_split('/(?<=[.!?])\s+/u', $plain_short, -1, PREG_SPLIT_NO_EMPTY);
            $plain_short = trim(implode(' ', array_slice($sentences ?: [$plain_short], 0, 3)));
            if (!preg_match('/[.!?]$/u', $plain_short)) $plain_short .= '.';
            $formatted = wpautop(esc_html($plain_short), false);
        }
        return $formatted;
    }

    private function decimal($value): string {
        $value = preg_replace('/[^0-9,.\-]/', '', (string)$value);
        if (substr_count($value, ',') === 1 && substr_count($value, '.') === 0) $value = str_replace(',', '.', $value);
        elseif (substr_count($value, '.') > 1) $value = str_replace('.', '', $value);
        return wc_format_decimal($value);
    }
}
