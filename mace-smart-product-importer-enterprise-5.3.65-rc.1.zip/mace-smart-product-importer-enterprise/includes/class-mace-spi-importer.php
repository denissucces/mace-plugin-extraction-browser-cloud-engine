<?php
defined('ABSPATH') || exit;
if (!class_exists('MACE5311_SPI_Materialization_Firewall')) require_once __DIR__ . '/class-mace-spi-materialization-firewall.php';
if (!class_exists('MACE5311_SPI_Content_Firewall')) require_once __DIR__ . '/class-mace-spi-content-firewall.php';
if (!class_exists('MACE5311_SPI_Attribute_Firewall')) require_once __DIR__ . '/class-mace-spi-attribute-firewall.php';

final class MACE5311_SPI_Importer {
    private $client, $extractor, $quality, $logger;
    public function __construct(MACE5311_SPI_Client $client, MACE5311_SPI_Extractor $extractor, MACE5311_SPI_Quality $quality, MACE5311_SPI_Logger $logger) {
        $this->client=$client; $this->extractor=$extractor; $this->quality=$quality; $this->logger=$logger;
    }

    public function import(string $url, array $options = []) {
        $started = microtime(true);
        $fetch = $this->client->fetch($url);
        if (is_wp_error($fetch)) return $fetch;
        return $this->build_from_fetch($url, $fetch, $started, $options);
    }

    public function resume_bridge(string $url, string $code, array $options = []) {
        $started = microtime(true); $fetch = $this->client->bridge_result($code);
        if (is_wp_error($fetch)) return $fetch;
        return $this->build_from_fetch($url, $fetch, $started, $options);
    }

    private function compose_long_description(array $product_data): string {
        $long_description = (string)($product_data['description'] ?? '');
        $description_format = (string)($product_data['description_format'] ?? '');
        $source_fidelity_description = in_array($description_format, [
            'source-rendered-semantic-html-v2',
            'source-heading-range-html-v2',
            'source-dom-html-v1',
        ], true);
        // Source Layout Fidelity contract: never append a separate characteristics
        // table to an authoritative external Description section. That table belongs
        // to WooCommerce attributes/meta, not to post_content.
        if (!$source_fidelity_description && !empty($product_data['specifications_html']) && strpos($long_description, 'mace-product-specifications') === false) {
            $long_description .= "\n\n" . (string)$product_data['specifications_html'];
        }
        return MACE5311_SPI_Content_Firewall::sanitize_html($long_description);
    }

    /**
     * Long Description Presentation Pipeline.
     *
     * Trois principes cumulatifs :
     * 1) le Marketplace Noise Firewall retire uniquement les blocs étrangers à la
     *    fiche produit (cross-sell, recommandations, tri, suggestions) ;
     * 2) le mode « Aérer » découpe seulement les paragraphes très denses sur des
     *    frontières de phrases existantes ;
     * 3) le mode Merchant applique la même segmentation avec une présentation plus
     *    poussée. Toute transformation de présentation est protégée par le
     *    Content Fidelity Guard SHA-256.
     */
    private function prepare_long_description(string $source_html, array $product_data, array $options): array {
        $source_html = trim($source_html);
        $editorial = $this->strip_source_editorial_disclosures($source_html);
        $noise = $this->strip_marketplace_noise_tail((string)$editorial['html']);
        $clean_source_html = (string)$noise['html'];
        $merchant_requested = !empty($options['merchant_long_description']);
        $readability_requested = !empty($options['air_long_description']);
        $base_report = [
            'requested' => $merchant_requested,
            'readability_requested' => $readability_requested,
            'source_format' => (string)($product_data['description_format'] ?? ''),
            'source_chars' => mb_strlen(wp_strip_all_tags($source_html)),
            'source_paragraphs' => preg_match_all('~<p\b~i', $source_html),
            'source_headings' => preg_match_all('~<h[1-6]\b~i', $source_html),
            'source_list_items' => preg_match_all('~<li\b~i', $source_html),
            'source_tables' => preg_match_all('~<table\b~i', $source_html),
            'noise_firewall' => 'marketplace-description-tail-v2-source-disclosure-safe',
            'noise_removed' => !empty($noise['removed']) || !empty($editorial['removed']),
            'noise_marker' => (string)($noise['marker'] ?? ''),
            'source_editorial_disclosures_removed' => count((array)($editorial['removed'] ?? [])),
        ];

        if ($clean_source_html === '') {
            $base_report['mode'] = 'source_fidelity';
            $base_report['guard_passed'] = true;
            $base_report['reason'] = 'empty_source';
            return ['html'=>$clean_source_html, 'mode'=>'source_fidelity', 'report'=>$base_report];
        }

        if (!$merchant_requested && !$readability_requested) {
            $base_report['mode'] = !empty($noise['removed']) ? 'source_fidelity_clean' : 'source_fidelity';
            $base_report['guard_passed'] = true;
            $base_report['reason'] = !empty($noise['removed']) ? 'marketplace_noise_removed' : 'all_presentation_options_disabled';
            return ['html'=>$clean_source_html, 'mode'=>$base_report['mode'], 'report'=>$base_report];
        }

        $candidate = $merchant_requested
            ? $this->merchant_present_long_description($clean_source_html)
            : $this->readability_present_long_description($clean_source_html);
        $guard_passed = $this->long_description_fidelity_guard($clean_source_html, $candidate);
        $base_report['guard_passed'] = $guard_passed;
        $base_report['candidate_chars'] = mb_strlen(wp_strip_all_tags($candidate));
        $base_report['candidate_paragraphs'] = preg_match_all('~<p\b~i', $candidate);
        $base_report['candidate_headings'] = preg_match_all('~<h[1-6]\b~i', $candidate);
        $base_report['candidate_list_items'] = preg_match_all('~<li\b~i', $candidate);
        $base_report['candidate_tables'] = preg_match_all('~<table\b~i', $candidate);

        if (!$guard_passed) {
            $base_report['mode'] = 'source_fidelity_fallback';
            $base_report['reason'] = 'content_fidelity_guard_rejected_candidate';
            return ['html'=>$clean_source_html, 'mode'=>'source_fidelity_fallback', 'report'=>$base_report];
        }

        $base_report['mode'] = $merchant_requested ? 'merchant_professional' : 'source_readability';
        $base_report['reason'] = $merchant_requested ? 'merchant_presentation_only_transformation' : 'paragraph_readability_only_transformation';
        return ['html'=>$candidate, 'mode'=>$base_report['mode'], 'report'=>$base_report];
    }

    private function readability_present_long_description(string $html): string {
        $html = $this->split_dense_description_paragraphs($html, 330, 2);
        if (strpos($html, 'mace-long-description--readable') === false) {
            $html = '<div class="mace-long-description mace-long-description--readable">' . $html . '</div>';
        }
        return $html;
    }

    private function merchant_present_long_description(string $html): string {
        $html = $this->split_dense_description_paragraphs($html, 300, 2);
        if (strpos($html, 'mace-long-description--merchant') === false) {
            $html = '<div class="mace-long-description mace-long-description--merchant">' . $html . '</div>';
        }
        return $html;
    }

    private function split_dense_description_paragraphs(string $html, int $threshold = 330, int $sentences_per_paragraph = 2): string {
        $result = preg_replace_callback('~<p\b([^>]*)>(.*?)</p>~is', function ($match) use ($threshold, $sentences_per_paragraph) {
            $inner = (string)$match[2];
            if (preg_match('~<(?:a|strong|b|em|i|u|span|img|br|sup|sub|code|mark)\b~i', $inner)) return $match[0];
            $plain = trim(html_entity_decode(wp_strip_all_tags($inner), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if (mb_strlen($plain) < $threshold) return $match[0];

            $sentences = preg_split('/(?<=[.!?])\s+(?=[\p{L}\d])/u', $plain, -1, PREG_SPLIT_NO_EMPTY);
            if (!$sentences || count($sentences) < 3) return $match[0];

            $paragraphs = [];
            foreach (array_chunk($sentences, max(1, $sentences_per_paragraph)) as $chunk) {
                $paragraphs[] = '<p class="mace-long-description__paragraph">' . esc_html(trim(implode(' ', $chunk))) . '</p>';
            }
            return implode("\n", $paragraphs);
        }, $html);
        return is_string($result) ? $result : $html;
    }

    private function strip_source_editorial_disclosures(string $html): array {
        $html = trim($html);
        if ($html === '') return ['html'=>'','removed'=>[]];
        $removed = [];
        $is_disclosure = static function (string $text): bool {
            $text = html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (function_exists('remove_accents')) $text = remove_accents($text);
            elseif (function_exists('iconv')) $text = iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$text) ?: $text;
            $text = trim((string)preg_replace('/\s+/u', ' ', $text));
            $text = function_exists('mb_strtolower') ? mb_strtolower($text) : strtolower($text);
            $text = trim($text, " \t\n\r\0\x0B.");
            $blocked = [
                'reponses generees par ia a partir des informations vendeur',
                "reponses generees par l'ia a partir des informations vendeur",
                'contenu genere par ia',
                "contenu genere par l'ia",
                'informations fournies par vendeur',
                'informations fournies par le vendeur',
                'donnees fournies par vendeur',
                'donnees fournies par le vendeur',
            ];
            if (in_array($text, $blocked, true)) return true;
            return (bool)preg_match('/^source\s*:\s*(?:manomano|fnac|rakuten|amazon|cdiscount|boulanger)$/', $text);
        };
        $html = preg_replace_callback('~<(p|div|span|small)\b[^>]*>(.*?)</\1>~is',
            static function ($m) use (&$removed, $is_disclosure) {
                if (!$is_disclosure((string)$m[0])) return $m[0];
                $removed[] = trim(wp_strip_all_tags((string)$m[0]));
                return '';
            }, $html);
        return ['html'=>trim((string)$html),'removed'=>$removed];
    }

    private function strip_marketplace_noise_tail(string $html): array {
        $html = trim($html);
        if ($html === '') return ['html'=>'','removed'=>false,'marker'=>''];

        $marker_pattern = '(?:les\s+internautes\s+ont\s+(?:aussi|[ée]galement)\s+(?:achet[ée]|consult[ée])|les\s+clients?\s+ont\s+(?:aussi|[ée]galement)\s+achet[ée]|vous\s+aimerez\s+aussi|produits?\s+similaires?|articles?\s+similaires?|recommandations?|suggestions?(?:\s+pour\s+vous)?|compl[ée]tez\s+(?:votre\s+)?(?:achat|commande)|frequently\s+bought(?:\s+together)?|customers?\s+also\s+bought)';

        $offset = null; $marker = '';
        if (preg_match('~<h[1-6]\b[^>]*>\s*(?:<[^>]+>\s*)*(' . $marker_pattern . ')(?:\s*</[^>]+>)*\s*</h[1-6]>~iu', $html, $m, PREG_OFFSET_CAPTURE)) {
            $offset = (int)$m[0][1];
            $marker = trim(wp_strip_all_tags((string)$m[1][0]));
        } elseif (preg_match('~<(?:p|div)\b[^>]*>\s*(?:<[^>]+>\s*)*(' . $marker_pattern . ')(?:\s*</[^>]+>)*\s*</(?:p|div)>~iu', $html, $m, PREG_OFFSET_CAPTURE)) {
            $candidate_text = trim(wp_strip_all_tags((string)$m[0][0]));
            if (mb_strlen($candidate_text) <= 140) {
                $offset = (int)$m[0][1];
                $marker = trim(wp_strip_all_tags((string)$m[1][0]));
            }
        }

        if ($offset !== null) $html = rtrim(substr($html, 0, $offset));
        $html = preg_replace('~<li\b[^>]*>\s*</li>~iu', '', $html);
        $html = preg_replace('~<(ul|ol)\b[^>]*>\s*</\1>~iu', '', (string)$html);
        return ['html'=>trim((string)$html),'removed'=>$offset !== null,'marker'=>$marker];
    }

    private function long_description_fidelity_guard(string $source_html, string $candidate_html): bool {
        return hash_equals(
            hash('sha256', $this->canonical_long_description_text($source_html)),
            hash('sha256', $this->canonical_long_description_text($candidate_html))
        );
    }

    private function canonical_long_description_text(string $html): string {
        $plain = html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = preg_replace('/[\p{Cf}\x{00AD}]+/u', '', (string)$plain);
        $plain = preg_replace('/\s+/u', '', (string)$plain);
        return trim((string)$plain);
    }

    private function build_from_fetch(string $url, array $fetch, float $started, array $options = []) {
        $product_data = $this->extractor->extract($fetch, $url);
        if (is_wp_error($product_data)) return $product_data;
        $settings = get_option('mace5311_spi_settings', []);

        // L'identité existante est recherchée avant de générer une UGS. Cela permet
        // de conserver exactement la même UGS MACE lors des réimportations.
        $existing_id = $this->find_existing($product_data, $settings);
        $sku_result = $this->resolve_sku($product_data, $existing_id, $settings);
        $product_data['sku'] = $sku_result['sku'];
        $product_data['sku_origin'] = $sku_result['origin'];
        $product_data['sku_generated'] = $sku_result['generated'];

        $quality = $this->quality->score($product_data);
        if ($quality['score'] < (int)($settings['minimum_score'] ?? 70)) {
            return new WP_Error('low_quality', 'Import refusé : qualité ' . $quality['score'] . ' %. Données manquantes : ' . implode(', ', $quality['missing']) . '.');
        }

        $product = $existing_id ? wc_get_product($existing_id) : new WC_Product_Simple();
        if (!$product) return new WP_Error('product_init', 'Impossible d’initialiser le produit WooCommerce.');

        try {
            $product->set_name($product_data['name']);
            $product->set_status($settings['status'] ?? 'draft');
            $source_long_description = $this->compose_long_description($product_data);
            // Final Shipping Materialization Guard works from the authoritative source
            // description, before any optional presentation-only transformation.
            $product_data = $this->recover_shipping_measurements_before_save($product_data, $source_long_description . "\n" . wp_strip_all_tags((string)($product_data['short_description'] ?? '')));
            // Re-apply the universal contract AFTER local shipping/measurement recovery.
            // Otherwise an importer-side fallback could recreate fields Cloud quarantined.
            $product_data = MACE5311_SPI_Materialization_Firewall::apply($product_data);
            $product_data['short_description'] = MACE5311_SPI_Content_Firewall::sanitize_plain((string)($product_data['short_description'] ?? ''));
            $product_data['short_description'] = MACE5311_SPI_Content_Firewall::translate_to_store_locale((string)$product_data['short_description'], 'short_description');
            $description_presentation = $this->prepare_long_description($source_long_description, $product_data, $options);
            $long_description = (string)$description_presentation['html'];
            $product->set_description($long_description);
            $product->set_short_description($product_data['short_description']);
            // Terminal WooCommerce Price Materialization Gate v1. A rejected price must
            // never survive merely because this is a resume/update operation. When the
            // authority report explicitly marks the source price untrusted, clear any
            // stale _price/_regular_price instead of preserving it. This is fail-closed
            // and only activates on an explicit authority rejection.
            $price_authority = is_array($product_data['price_authority_report'] ?? null) ? $product_data['price_authority_report'] : [];
            $price_materialization = (string)($price_authority['materialization'] ?? '');
            $contract_price_state = MACE5311_SPI_Materialization_Firewall::field_state($product_data, 'price');
            $contract_price_blocked = MACE5311_SPI_Materialization_Firewall::is_blocked_state($contract_price_state);
            if ($contract_price_blocked) {
                $product->set_regular_price('');
                $product->set_sale_price('');
            } elseif ($product_data['regular_price'] !== '') {
                $product->set_regular_price($product_data['regular_price']);
            } elseif ($price_materialization === 'blocked_untrusted') {
                $product->set_regular_price('');
                $product->set_sale_price('');
            }
            if ($product_data['sale_price'] !== '' && $price_materialization !== 'blocked_untrusted' && !$contract_price_blocked) $product->set_sale_price($product_data['sale_price']);
            if ($product_data['sku'] && (!$existing_id || $product->get_sku() !== $product_data['sku'])) $product->set_sku($product_data['sku']);
            $product->set_stock_status($product_data['stock_status']);
            foreach (['weight','length','width','height'] as $dimension) {
                $state = MACE5311_SPI_Materialization_Firewall::field_state($product_data, $dimension);
                if ($dimension !== 'weight' && $state === '') $state = MACE5311_SPI_Materialization_Firewall::field_state($product_data, 'dimensions');
                if (MACE5311_SPI_Materialization_Firewall::is_blocked_state($state)) {
                    // Explicitly clear stale values on resume/update; omission alone would preserve corruption.
                    $product->{'set_' . $dimension}('');
                } elseif ($product_data[$dimension] !== '') {
                    $product->{'set_' . $dimension}($product_data[$dimension]);
                }
            }
            $product_id = $product->save();
            // Écriture finale directe du post_excerpt après WC_Product::save().
            // Elle empêche un ancien extrait promotionnel de survivre dans le produit
            // mis à jour ou d'être réinjecté par un hook exécuté plus tôt.
            if ($product_id && array_key_exists('short_description', $product_data)) {
                wp_update_post([
                    'ID' => $product_id,
                    'post_excerpt' => wp_kses_post((string)$product_data['short_description']),
                ]);
                clean_post_cache($product_id);
            }
        } catch (Throwable $e) {
            return new WP_Error('save_exception', 'WooCommerce a refusé la création : ' . $e->getMessage());
        }
        if (!$product_id) return new WP_Error('save_failed', 'WooCommerce n’a pas enregistré le produit.');

        update_post_meta($product_id, '_mace5311_spi_source_url', esc_url_raw($url));
        update_post_meta($product_id, '_mace5311_spi_method', sanitize_text_field($fetch['method']));
        update_post_meta($product_id, '_mace5311_spi_quality', (int)$quality['score']);
        update_post_meta($product_id, '_mace5311_spi_last_import', current_time('mysql', true));
        if (!empty($fetch['request_id'])) update_post_meta($product_id, '_mace5311_spi_request_id', sanitize_text_field($fetch['request_id']));
        if ($product_data['gtin']) { update_post_meta($product_id, '_global_unique_id', $product_data['gtin']); update_post_meta($product_id, '_mace5311_spi_gtin', $product_data['gtin']); }
        if (MACE5311_SPI_Materialization_Firewall::has_contract($product_data)) {
            // Contract-aware writes are authoritative even when empty: this clears stale
            // quarantined specification rows from a previous import.
            update_post_meta($product_id, '_mace5311_spi_specifications_html', MACE5311_SPI_Attribute_Firewall::sanitize_html((string)($product_data['specifications_html'] ?? '')));
            update_post_meta($product_id, '_mace5311_spi_specifications_json', wp_json_encode(MACE5311_SPI_Attribute_Firewall::sanitize_rows((array)($product_data['specifications'] ?? []))));
        } else {
            if (!empty($product_data['specifications_html'])) update_post_meta($product_id, '_mace5311_spi_specifications_html', MACE5311_SPI_Attribute_Firewall::sanitize_html((string)$product_data['specifications_html']));
            if (!empty($product_data['specifications'])) update_post_meta($product_id, '_mace5311_spi_specifications_json', wp_json_encode(MACE5311_SPI_Attribute_Firewall::sanitize_rows((array)$product_data['specifications'])));
        }
        if (!empty($product_data['specifications_report'])) update_post_meta($product_id, '_mace5311_spi_specifications_report', wp_json_encode($product_data['specifications_report']));
        if (!empty($product_data['direct_product_sections'])) update_post_meta($product_id, '_mace5311_spi_direct_product_sections', wp_json_encode($product_data['direct_product_sections']));
        if (!empty($product_data['acquisition_path_registry'])) update_post_meta($product_id, '_mace5311_spi_acquisition_path_registry', wp_json_encode($product_data['acquisition_path_registry']));
        update_post_meta($product_id, '_mace5311_spi_description_format', sanitize_key((string)($product_data['description_format'] ?? '')));
        if (!empty($product_data['description_report'])) update_post_meta($product_id, '_mace5311_spi_description_report', wp_json_encode($product_data['description_report']));
        update_post_meta($product_id, '_mace5311_spi_source_description_html', wp_kses_post((string)$source_long_description));
        update_post_meta($product_id, '_mace5311_spi_long_description_mode', sanitize_key((string)($description_presentation['mode'] ?? 'source_fidelity')));
        update_post_meta($product_id, '_mace5311_spi_long_description_presentation_report', wp_json_encode($description_presentation['report'] ?? []));
        if ($product_data['currency']) update_post_meta($product_id, '_mace5311_spi_source_currency', $product_data['currency']);
        update_post_meta($product_id, '_mace5311_spi_sku_origin', sanitize_key((string)($product_data['sku_origin'] ?? 'source')));
        update_post_meta($product_id, '_mace5311_spi_generated_sku', !empty($product_data['sku_generated']) ? sanitize_text_field((string)$product_data['sku']) : '');
        update_post_meta($product_id, '_mace5311_spi_identity_version', 'short-alphanumeric-v1');
        update_post_meta($product_id, '_mace5311_spi_short_description_generated', !empty($product_data['short_description_generated']) ? 'yes' : 'no');
        update_post_meta($product_id, '_mace5311_spi_short_description_source', sanitize_text_field((string)($product_data['short_description_source'] ?? 'source')));
        update_post_meta($product_id, '_mace5311_spi_short_description_quality', (int)($product_data['short_description_quality'] ?? 0));
        update_post_meta($product_id, '_mace5311_spi_short_description_mode', sanitize_key((string)($product_data['short_description_mode'] ?? 'automatic')));
        update_post_meta($product_id, '_mace5311_spi_short_description_rejection_reason', sanitize_text_field((string)($product_data['short_description_rejection_reason'] ?? '')));
        update_post_meta($product_id, '_mace5311_spi_short_description_pipeline', wp_json_encode([
            'mode' => (string)($product_data['short_description_mode'] ?? 'automatic'),
            'generated' => !empty($product_data['short_description_generated']),
            'source' => (string)($product_data['short_description_source'] ?? 'source'),
            'quality' => (int)($product_data['short_description_quality'] ?? 0),
            'source_rejection_reason' => (string)($product_data['short_description_rejection_reason'] ?? ''),
            'final_length' => mb_strlen(wp_strip_all_tags((string)($product_data['short_description'] ?? ''))),
            'format' => (string)($product_data['short_description_format'] ?? 'professional'),
            'pipeline' => 'extract-clean-generate-format-final-write-v3',
        ]));
        if ($product_data['brand']) $this->set_brand($product_id, $product_data['brand']);
        $this->set_categories($product_id, $product_data['categories']);
        $attribute_count = $this->set_attributes($product, $product_data['attributes']);
        $image_result = !empty($settings['download_images']) ? $this->set_images($product_id, $product_data['images'], (int)($settings['max_images'] ?? 15), $product_data['image_report'] ?? [], $product_data, $settings) : ['count'=>0,'failed'=>[]];
        $brand_logo_result = ['attachment_id'=>0,'error'=>''];
        if (!empty($settings['import_brand_logo']) && !empty($product_data['brand_logo'])) {
            $brand_logo_result = $this->set_brand_logo($product_id, $product_data['brand_logo']);
        }
        $image_count = (int)$image_result['count'];
        update_post_meta($product_id, '_mace5311_spi_import_report', wp_json_encode(['quality'=>$quality,'price'=>$product_data['price_report'] ?? [],'price_authority'=>$product_data['price_authority_report'] ?? [],'materialization'=>['contract'=>$product_data['materialization_contract'] ?? [],'cloud_report'=>$product_data['cloud_materialization_firewall_report'] ?? [],'plugin_report'=>$product_data['materialization_firewall_report'] ?? []],'description'=>['format'=>$product_data['description_format'] ?? '','report'=>$product_data['description_report'] ?? [],'presentation_mode'=>$description_presentation['mode'] ?? 'source_fidelity','presentation_report'=>$description_presentation['report'] ?? []],'measurements'=>['weight'=>$product_data['weight'] ?? '','length'=>$product_data['length'] ?? '','width'=>$product_data['width'] ?? '','height'=>$product_data['height'] ?? ''],'images'=>$image_result,'image_selection'=>$product_data['image_report'] ?? [],'brand_logo'=>$brand_logo_result,'sku'=>['value'=>$product_data['sku'],'origin'=>$product_data['sku_origin'] ?? 'source','generated'=>!empty($product_data['sku_generated'])],'attributes'=>$attribute_count,'specifications'=>['count'=>count((array)($product_data['specifications'] ?? [])),'report'=>$product_data['specifications_report'] ?? [],'path_registry'=>$product_data['acquisition_path_registry'] ?? []],'diagnostics'=>$fetch['diagnostics'] ?? []]));
        $this->record_golden_route_memory($product_id, $product_data, $fetch, $quality, $image_count, $attribute_count);

        $duration = round(microtime(true) - $started, 2);
        $this->logger->log('info', 'Import terminé', ['product_id'=>$product_id,'method'=>$fetch['method'],'score'=>$quality['score'],'duration'=>$duration]);
        return ['product_id'=>$product_id,'quality'=>$quality,'fetch'=>$fetch,'images'=>$image_count,'image_failures'=>count($image_result['failed']),'attributes'=>$attribute_count,'specifications'=>count((array)($product_data['specifications'] ?? [])),'updated'=>(bool)$existing_id,'duration'=>$duration,'description_mode'=>$description_presentation['mode'] ?? 'source_fidelity'];
    }

    /**
     * Retourne une UGS fiable, stable et compatible avec WooCommerce / Merchant.
     * Une UGS déjà attribuée à un produit existant est immuable. Pour un nouveau produit,
     * l'administration peut conserver la source, utiliser le générateur MACE, ou composer
     * une UGS déterministe incluant les initiales de sa société.
     */
    private function resolve_sku(array $product, int $existing_id, array $settings = []): array {
        $source_sku = $this->sanitize_source_sku((string)($product['sku'] ?? ''));

        // Identité permanente : ne jamais renommer une UGS existante lors d'une réimportation.
        if ($existing_id > 0) {
            $existing_product = wc_get_product($existing_id);
            if ($existing_product && $existing_product->get_sku() !== '') {
                $existing_sku = (string)$existing_product->get_sku();
                $origin = sanitize_key((string)get_post_meta($existing_id, '_mace5311_spi_sku_origin', true));
                if ($origin === '') $origin = 'source';
                return [
                    'sku' => $existing_sku,
                    'origin' => $origin,
                    'generated' => $origin !== 'source',
                ];
            }
        }

        $strategy = in_array((string)($settings['sku_strategy'] ?? 'source_preferred'), ['source_preferred','mace_generated','company_custom'], true)
            ? (string)$settings['sku_strategy'] : 'source_preferred';

        if ($strategy === 'source_preferred' && $source_sku !== '') {
            $owner_id = (int)wc_get_product_id_by_sku($source_sku);
            if ($owner_id === 0 || $owner_id === $existing_id) {
                return ['sku'=>$source_sku, 'origin'=>'source', 'generated'=>false];
            }
        }

        $seed_parts = [
            (string)($product['source_url'] ?? ''),
            (string)($product['brand'] ?? ''),
            (string)($product['name'] ?? ''),
            (string)($product['gtin'] ?? ''),
        ];
        $seed = implode('|', array_filter($seed_parts, static function($value) { return $value !== ''; }));
        if ($seed === '') $seed = wp_generate_uuid4();

        for ($attempt = 0; $attempt < 100; $attempt++) {
            $sku = $strategy === 'company_custom'
                ? $this->build_company_sku($seed, $attempt, $settings)
                : $this->build_short_sku($seed, $attempt);
            $owner_id = (int)wc_get_product_id_by_sku($sku);
            if ($owner_id === 0 || $owner_id === $existing_id) {
                return [
                    'sku'=>$sku,
                    'origin'=>$strategy === 'company_custom' ? 'company_generated' : 'mace_generated',
                    'generated'=>true,
                ];
            }
        }

        // Repli exceptionnel, toujours ASCII et stable pour WooCommerce/Merchant.
        do {
            $sku = 'MC' . strtoupper(wp_generate_password(10, false, false));
            $sku = substr(preg_replace('/[^A-Z0-9]/', '', $sku), 0, 12);
        } while (wc_get_product_id_by_sku($sku));
        return ['sku'=>$sku, 'origin'=>'mace_generated', 'generated'=>true];
    }

    private function sanitize_source_sku(string $sku): string {
        $sku = trim(wp_strip_all_tags($sku));
        if ($sku === '') return '';
        return wc_clean($sku);
    }

    private function build_short_sku(string $seed, int $attempt): string {
        $material = $seed . '|' . $attempt;
        $hash = strtoupper(hash('sha256', $material));
        $digit = (string)(hexdec(substr($hash, 0, 2)) % 10);
        return 'MC' . $digit . substr($hash, 2, 7);
    }

    private function build_company_sku(string $seed, int $attempt, array $settings): string {
        $initials = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string)($settings['sku_company_initials'] ?? '')));
        $initials = substr($initials, 0, 8);
        if ($initials === '') $initials = 'MC';

        $position = in_array((string)($settings['sku_company_position'] ?? 'prefix'), ['prefix','middle','suffix'], true)
            ? (string)$settings['sku_company_position'] : 'prefix';
        $use_separator = !array_key_exists('sku_use_separator', $settings) || !empty($settings['sku_use_separator']);
        $sep = $use_separator ? '-' : '';
        $separators = $position === 'middle' ? 2 : 1;
        if (!$use_separator) $separators = 0;

        $target = max(8, min(32, (int)($settings['sku_total_length'] ?? 12)));
        $min_target = strlen($initials) + $separators + 4;
        if ($target < $min_target) $target = $min_target;
        if ($target > 50) $target = 50; // Google Merchant ID supports 1–50 characters.

        $body_len = max(4, $target - strlen($initials) - $separators);
        $hash = strtoupper(hash('sha256', $seed . '|' . $attempt));
        $digit = (string)(hexdec(substr($hash, 0, 2)) % 10);
        $body = substr($digit . substr($hash, 2), 0, $body_len);

        if ($position === 'suffix') {
            $sku = $body . $sep . $initials;
        } elseif ($position === 'middle') {
            $left_len = (int)ceil($body_len / 2);
            $sku = substr($body, 0, $left_len) . $sep . $initials . $sep . substr($body, $left_len);
        } else {
            $sku = $initials . $sep . $body;
        }

        return substr(preg_replace('/[^A-Z0-9-]/', '', strtoupper($sku)), 0, 50);
    }

    private function find_existing(array $product, array $settings): int {
        if (empty($settings['update_existing'])) return 0;
        if ($product['sku']) { $id = wc_get_product_id_by_sku($product['sku']); if ($id) return (int)$id; }
        $ids = get_posts(['post_type'=>'product','post_status'=>'any','fields'=>'ids','numberposts'=>1,'meta_key'=>'_mace5311_spi_source_url','meta_value'=>$product['source_url']]);
        return (int)($ids[0] ?? 0);
    }

    private function set_categories(int $product_id, array $categories): void {
        if (!$categories) return;
        $parent = 0; $ids = [];
        foreach ($categories as $name) {
            $term = term_exists($name, 'product_cat', $parent);
            if (!$term) $term = wp_insert_term($name, 'product_cat', ['parent'=>$parent]);
            if (!is_wp_error($term)) {
                $term_id = (int)(is_array($term) ? $term['term_id'] : $term);
                $ids[] = $term_id; $parent = $term_id;
            }
        }
        if ($ids) wp_set_object_terms($product_id, $ids, 'product_cat', false);
    }

    private function set_brand(int $product_id, string $brand): void {
        $brand = trim(wp_strip_all_tags($brand));
        if ($brand === '') return;
        $taxonomy = $this->discover_brand_taxonomy();
        if ($taxonomy === '') {
            update_post_meta($product_id, '_mace5311_spi_brand', sanitize_text_field($brand));
            update_post_meta($product_id, '_mace5311_spi_brand_status', 'stored_as_meta_no_taxonomy');
            return;
        }
        $term = term_exists($brand, $taxonomy);
        $created = false;
        if (!$term) {
            $term = wp_insert_term($brand, $taxonomy, ['slug'=>sanitize_title($brand)]);
            $created = !is_wp_error($term);
        }
        if (!is_wp_error($term)) {
            $term_id = (int)(is_array($term) ? $term['term_id'] : $term);
            wp_set_object_terms($product_id, [$term_id], $taxonomy, false);
            update_post_meta($product_id, '_mace5311_spi_brand', sanitize_text_field($brand));
            update_post_meta($product_id, '_mace5311_spi_brand_taxonomy', sanitize_key($taxonomy));
            update_post_meta($product_id, '_mace5311_spi_brand_term_id', $term_id);
            update_post_meta($product_id, '_mace5311_spi_brand_status', $created ? 'created_and_associated' : 'existing_associated');
        }
    }

    private function set_attributes(WC_Product $product, array $attributes): int {
        $attributes = MACE5311_SPI_Attribute_Firewall::sanitize_map($attributes);
        if (!$attributes) { $product->set_attributes([]); $product->save(); return 0; }
        $list = [];
        foreach ($attributes as $name => $value) {
            if ($name === '' || $value === '') continue;
            $attribute = new WC_Product_Attribute();
            $attribute->set_name($name);
            $attribute->set_options([$value]);
            $attribute->set_visible(true);
            $attribute->set_variation(false);
            $list[] = $attribute;
        }
        $product->set_attributes($list);
        $product->save();
        return count($list);
    }

    private function discover_brand_taxonomy(): string {
        foreach (['product_brand','pwb-brand','yith_product_brand','pa_marque','pa_brand','mace_product_brand'] as $candidate) {
            if (taxonomy_exists($candidate)) return $candidate;
        }
        $objects = get_object_taxonomies('product', 'objects');
        foreach ($objects as $taxonomy => $object) {
            $label = remove_accents(mb_strtolower((string)($object->labels->singular_name ?? $object->label ?? $taxonomy)));
            if (preg_match('/\b(?:marque|brand|fabricant)\b/u', $label)) return (string)$taxonomy;
        }
        return '';
    }

    private function set_brand_logo(int $product_id, string $url): array {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attachment_id = media_sideload_image($url, $product_id, 'Logo de marque', 'id');
        if (is_wp_error($attachment_id)) return ['attachment_id'=>0,'error'=>$attachment_id->get_error_message()];
        update_post_meta($product_id, '_mace5311_spi_brand_logo_id', (int)$attachment_id);
        update_post_meta($product_id, '_mace5311_spi_brand_logo_url', esc_url_raw($url));
        return ['attachment_id'=>(int)$attachment_id,'error'=>''];
    }

    private function set_images(int $product_id, array $urls, int $max, array $report = [], array $product_data = [], array $settings = []): array {
        if (!$urls) return ['count'=>0,'failed'=>[],'removed'=>0];
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Double verrouillage côté WordPress : si le Cloud fournit une liste acceptée,
        // aucune autre URL ne peut entrer dans la galerie.
        $accepted = []; $accepted_meta = [];
        foreach ((array)($report['accepted'] ?? []) as $item) {
            $candidate = is_array($item) ? (string)($item['url'] ?? '') : (string)$item;
            if ($candidate !== '') {
                $canonical = $this->canonical_image_url($candidate);
                $accepted[$canonical] = true;
                $accepted_meta[$canonical] = is_array($item) ? $item : [];
            }
        }
        $strict_urls = [];
        foreach ($urls as $url) {
            $url = esc_url_raw((string)$url);
            if ($url === '') continue;
            if ($accepted && empty($accepted[$this->canonical_image_url($url)])) continue;
            $strict_urls[$this->canonical_image_url($url)] = $url;
        }
        $strict_urls = array_values(array_slice($strict_urls, 0, max(1, $max), true));
        if (!$strict_urls) return ['count'=>0,'failed'=>[],'removed'=>0,'error'=>'Aucune image n’a satisfait la liste blanche produit.'];

        $attachment_ids = []; $failed = []; $renamed = 0; $alts = 0; $duplicates = 0; $fingerprints = [];
        foreach ($strict_urls as $index => $url) {
            $attachment_id = $this->sideload_product_image($url, $product_id, $product_data, $index + 1, $settings);
            if (!is_wp_error($attachment_id)) {
                $attachment_id = (int)$attachment_id;
                $canonical = $this->canonical_image_url($url);
                $meta = $accepted_meta[$canonical] ?? [];
                $fingerprint = $this->image_fingerprint($attachment_id);
                $source = sanitize_key((string)($meta['source'] ?? ''));
                $strong_ownership = !empty($meta['ownership_verified']) || in_array($source, [
                    'fnac-product-media-ownership','fnac-product-family-id','official-gallery-dom','json-ld-product','variant-image','inline-product-description-cohort'
                ], true);
                $fingerprint['ownership_verified'] = $strong_ownership;
                $fingerprint['view_key'] = sanitize_text_field((string)($meta['view_key'] ?? ''));
                $duplicate_of = $this->find_duplicate_fingerprint($fingerprint, $fingerprints);
                if ($duplicate_of !== 0) {
                    $new_pixels = (int)($fingerprint['pixels'] ?? 0);
                    $old_pixels = (int)($fingerprints[$duplicate_of]['pixels'] ?? 0);
                    if ($new_pixels > $old_pixels) {
                        $pos = array_search($duplicate_of, $attachment_ids, true);
                        if ($pos !== false) $attachment_ids[$pos] = $attachment_id;
                        wp_delete_attachment($duplicate_of, true);
                        unset($fingerprints[$duplicate_of]);
                        $fingerprints[$attachment_id] = $fingerprint;
                    } else {
                        wp_delete_attachment($attachment_id, true);
                    }
                    $duplicates++;
                    continue;
                }
                $fingerprints[$attachment_id] = $fingerprint;
                $attachment_ids[] = $attachment_id;
                update_post_meta($attachment_id, '_mace5311_spi_managed_media', 1);
                update_post_meta((int)$attachment_id, '_mace5311_spi_source_image_url', $url);
                $role = sanitize_key((string)($meta['role'] ?? ($index === 0 ? 'featured' : 'product-gallery')));
                update_post_meta((int)$attachment_id, '_mace5311_spi_image_role', $role);
                update_post_meta((int)$attachment_id, '_mace5311_spi_image_source', sanitize_text_field((string)($meta['source'] ?? '')));
                update_post_meta((int)$attachment_id, '_mace5311_spi_image_reasons', wp_json_encode((array)($meta['reasons'] ?? [])));
                update_post_meta((int)$attachment_id, '_mace5311_spi_variant_cues', wp_json_encode((array)($meta['variant_cues'] ?? [])));
                if (!empty($settings['rename_images'])) $renamed++;
                if (!empty($settings['generate_image_alt'])) $alts++;
            } else $failed[] = ['url'=>$url,'error'=>$attachment_id->get_error_message()];
        }
        if (!$attachment_ids) return ['count'=>0,'failed'=>$failed,'removed'=>0];

        // Remplacement atomique de la galerie : les anciennes images, y compris les
        // intrus hérités des versions précédentes, ne restent plus attachées au produit.
        $old_ids = array_values(array_unique(array_filter(array_merge(
            [(int)get_post_thumbnail_id($product_id)],
            array_map('intval', explode(',', (string)get_post_meta($product_id, '_product_image_gallery', true))),
            array_map('intval', (array)get_post_meta($product_id, '_mace5311_spi_image_ids', true))
        ))));
        $featured_id = array_shift($attachment_ids);
        set_post_thumbnail($product_id, $featured_id);
        update_post_meta($product_id, '_product_image_gallery', implode(',', $attachment_ids));
        $new_ids = array_merge([$featured_id], $attachment_ids);
        update_post_meta($product_id, '_mace5311_spi_image_ids', $new_ids);

        $removed = 0;
        foreach (array_diff($old_ids, $new_ids) as $old_id) {
            if (!$old_id) continue;
            // Les médias attachés au produit sont supprimés uniquement lors d’un remplacement MACE.
            if ((int)get_post_field('post_parent', $old_id) === $product_id) {
                wp_delete_attachment($old_id, true);
                $removed++;
            }
        }
        return ['count'=>count($new_ids),'failed'=>$failed,'removed'=>$removed,'duplicates_removed'=>$duplicates,'accepted_urls'=>$strict_urls,'renamed'=>$renamed,'alt_texts'=>$alts];
    }


    private function sideload_product_image(string $url, int $product_id, array $product, int $index, array $settings) {
        $tmp = download_url($url, 45);
        if (is_wp_error($tmp)) return $tmp;
        $path = wp_parse_url($url, PHP_URL_PATH) ?: '';
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','webp','gif'], true)) $ext = 'jpg';
        $brand = sanitize_title((string)($product['brand'] ?? ''));
        $name = sanitize_title((string)($product['name'] ?? 'produit'));
        $ref = sanitize_title((string)($product['sku'] ?: ($product['gtin'] ?? '')));
        $parts = array_values(array_filter([$brand, $name, $ref, $index === 1 ? 'vue-principale' : 'vue-' . $index]));
        $base = implode('-', $parts);
        if ($base === '') $base = 'produit-image-' . $index;
        $base = substr($base, 0, 150);
        $hash = substr(hash('sha256', $this->canonical_image_url($url)), 0, 8);
        $filename = !empty($settings['rename_images']) ? $base . '-' . $hash . '.' . $ext : basename($path ?: ('image-' . $index . '.' . $ext));
        $file = ['name'=>$filename,'tmp_name'=>$tmp];
        $title = trim(implode(' ', array_filter([(string)($product['brand'] ?? ''), (string)($product['name'] ?? ''), $index === 1 ? 'vue principale' : 'vue ' . $index])));
        $attachment_id = media_handle_sideload($file, $product_id, $title);
        if (is_wp_error($attachment_id)) { @unlink($tmp); return $attachment_id; }
        if (!empty($settings['generate_image_alt'])) {
            update_post_meta((int)$attachment_id, '_wp_attachment_image_alt', sanitize_text_field($title));
            wp_update_post(['ID'=>(int)$attachment_id,'post_title'=>sanitize_text_field($title),'post_excerpt'=>'','post_content'=>sanitize_textarea_field($title)]);
        }
        return (int)$attachment_id;
    }

    private function image_fingerprint(int $attachment_id): array {
        $file = get_attached_file($attachment_id);
        if (!$file || !is_readable($file)) return [];
        $size = @getimagesize($file);
        $fingerprint = [
            'sha256' => hash_file('sha256', $file),
            'width' => (int)($size[0] ?? 0),
            'height' => (int)($size[1] ?? 0),
            'pixels' => (int)($size[0] ?? 0) * (int)($size[1] ?? 0),
            'dhash' => '',
            'ahash' => '',
        ];
        if (function_exists('imagecreatefromstring')) {
            $bytes = @file_get_contents($file);
            $source = $bytes !== false ? @imagecreatefromstring($bytes) : false;
            if ($source) {
                $small = imagecreatetruecolor(9, 8);
                imagecopyresampled($small, $source, 0, 0, 0, 0, 9, 8, imagesx($source), imagesy($source));
                $bits = '';
                for ($y=0; $y<8; $y++) {
                    for ($x=0; $x<8; $x++) {
                        $a = imagecolorat($small, $x, $y); $b = imagecolorat($small, $x+1, $y);
                        $ga = ((($a >> 16) & 255) * 30 + (($a >> 8) & 255) * 59 + ($a & 255) * 11) / 100;
                        $gb = ((($b >> 16) & 255) * 30 + (($b >> 8) & 255) * 59 + ($b & 255) * 11) / 100;
                        $bits .= $ga > $gb ? '1' : '0';
                    }
                }
                $hex = '';
                foreach (str_split($bits, 4) as $nibble) $hex .= dechex(bindec($nibble));
                $fingerprint['dhash'] = $hex;

                $avg_img = imagecreatetruecolor(8, 8);
                imagecopyresampled($avg_img, $source, 0, 0, 0, 0, 8, 8, imagesx($source), imagesy($source));
                $gray = []; $sum = 0.0;
                for ($yy=0; $yy<8; $yy++) for ($xx=0; $xx<8; $xx++) {
                    $c = imagecolorat($avg_img, $xx, $yy);
                    $g = ((($c >> 16) & 255) * 30 + (($c >> 8) & 255) * 59 + ($c & 255) * 11) / 100;
                    $gray[] = $g; $sum += $g;
                }
                $average = $sum / 64;
                $abits = '';
                foreach ($gray as $g) $abits .= $g >= $average ? '1' : '0';
                $ahex = '';
                foreach (str_split($abits, 4) as $nibble) $ahex .= dechex(bindec($nibble));
                $fingerprint['ahash'] = $ahex;
                imagedestroy($avg_img);
                imagedestroy($small); imagedestroy($source);
            }
        }
        return $fingerprint;
    }

    private function find_duplicate_fingerprint(array $candidate, array $existing): int {
        if (!$candidate) return 0;
        foreach ($existing as $attachment_id => $fingerprint) {
            if (!empty($candidate['sha256']) && hash_equals((string)$fingerprint['sha256'], (string)$candidate['sha256'])) return (int)$attachment_id;
            // Une vue déjà validée par le Product Media Ownership Engine ne doit jamais
            // être supprimée uniquement parce qu'elle ressemble visuellement à un autre angle.
            // Pour ces médias, seuls les octets réellement identiques sont des doublons.
            if (!empty($candidate['ownership_verified']) || !empty($fingerprint['ownership_verified'])) continue;
            $ratio_a = ($candidate['height'] ?? 0) > 0 ? ($candidate['width'] / $candidate['height']) : 0;
            $ratio_b = ($fingerprint['height'] ?? 0) > 0 ? ($fingerprint['width'] / $fingerprint['height']) : 0;
            if (abs($ratio_a - $ratio_b) <= 0.06) {
                $d_distance = (!empty($candidate['dhash']) && !empty($fingerprint['dhash']))
                    ? $this->hex_hamming_distance((string)$candidate['dhash'], (string)$fingerprint['dhash']) : 999;
                $a_distance = (!empty($candidate['ahash']) && !empty($fingerprint['ahash']))
                    ? $this->hex_hamming_distance((string)$candidate['ahash'], (string)$fingerprint['ahash']) : 999;
                // Deux méthodes perceptuelles concordantes, ou une correspondance très forte,
                // suffisent pour reconnaître une même image recompressée/redimensionnée.
                if (($d_distance <= 10 && $a_distance <= 10) || $d_distance <= 5 || $a_distance <= 4) return (int)$attachment_id;
            }
        }
        return 0;
    }

    private function hex_hamming_distance(string $a, string $b): int {
        if (strlen($a) !== strlen($b)) return PHP_INT_MAX;
        $distance = 0;
        for ($i=0, $len=strlen($a); $i<$len; $i++) $distance += substr_count(decbin(hexdec($a[$i]) ^ hexdec($b[$i])), '1');
        return $distance;
    }

    private function canonical_image_url(string $url): string {
        $parts = wp_parse_url($url);
        if (!$parts || empty($parts['host'])) return $url;
        $query = [];
        if (!empty($parts['query'])) {
            parse_str($parts['query'], $query);
            foreach (array_keys($query) as $key) {
                if (preg_match('/^(?:w|h|width|height|quality|q|fit|crop|format|fm|auto|dpr)$/i', (string)$key)) unset($query[$key]);
            }
        }
        $scheme = $parts['scheme'] ?? 'https';
        $path = $parts['path'] ?? '';
        return strtolower($scheme . '://' . $parts['host']) . $path . ($query ? '?' . http_build_query($query) : '');
    }
    private function record_golden_route_memory(int $product_id, array $data, array $fetch, array $quality, int $image_count, int $attribute_count): void {
        if ($product_id <= 0 || (int)($quality['score'] ?? 0) < 70) return;
        $registry = is_array($data['acquisition_path_registry'] ?? null) ? $data['acquisition_path_registry'] : [];
        $active_lanes = array_values(array_unique(array_filter(array_map('sanitize_key', (array)($registry['active_lanes'] ?? [])))));
        $validated_fields = array_values(array_unique(array_filter(array_map('sanitize_key', (array)($registry['validated_fields'] ?? [])))));
        if ($image_count > 0 && !in_array('images', $validated_fields, true)) $validated_fields[] = 'images';
        if ($attribute_count > 0 && !in_array('attributes', $validated_fields, true)) $validated_fields[] = 'attributes';

        $blueprint = [
            'schema' => 'mace-golden-route-memory-v1',
            'plugin_version' => MACE5311_SPI_VERSION,
            'method' => sanitize_key((string)($fetch['method'] ?? 'unknown')),
            'policy' => 'additive_only_non_regression',
            'quality' => (int)($quality['score'] ?? 0),
            'active_lanes' => $active_lanes,
            'validated_fields' => $validated_fields,
            'measurements' => [
                'weight' => trim((string)($data['weight'] ?? '')) !== '',
                'dimensions' => trim((string)($data['length'] ?? '')) !== '' && trim((string)($data['width'] ?? '')) !== '' && trim((string)($data['height'] ?? '')) !== '',
            ],
            'media_count' => $image_count,
            'attribute_count' => $attribute_count,
            'captured_at' => current_time('mysql', true),
        ];
        update_post_meta($product_id, '_mace5311_spi_golden_route_blueprint', wp_json_encode($blueprint));

        // Site-wide learning memory contains only strategy names and success counters;
        // it intentionally stores no marketplace URL, seller identity, e-mail or phone.
        $memory = get_option('mace5311_spi_golden_route_memory', []);
        if (!is_array($memory)) $memory = [];
        if (empty($memory['schema'])) $memory['schema'] = 'mace-golden-route-memory-v1';
        if (empty($memory['lanes']) || !is_array($memory['lanes'])) $memory['lanes'] = [];
        if (empty($memory['fields']) || !is_array($memory['fields'])) $memory['fields'] = [];
        foreach ($active_lanes as $lane) $memory['lanes'][$lane] = (int)($memory['lanes'][$lane] ?? 0) + 1;
        foreach ($validated_fields as $field) $memory['fields'][$field] = (int)($memory['fields'][$field] ?? 0) + 1;
        $memory['successful_imports'] = (int)($memory['successful_imports'] ?? 0) + 1;
        $memory['last_success_version'] = MACE5311_SPI_VERSION;
        $memory['last_success_at'] = current_time('mysql', true);
        update_option('mace5311_spi_golden_route_memory', $memory, false);
    }

    private function recover_shipping_measurements_before_save(array $data, string $long_description): array {
        foreach (['weight','length','width','height'] as $key) {
            if (!array_key_exists($key, $data) || (float)$data[$key] <= 0) $data[$key] = '';
        }
        $plain = html_entity_decode(wp_strip_all_tags($long_description), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain = preg_replace('/[\p{Cf}\x{00AD}]+/u', ' ', (string)$plain);
        $plain = preg_replace('/\s+/u', ' ', (string)$plain);
        $dimension_unit = (string)get_option('woocommerce_dimension_unit', 'cm');
        $weight_unit = (string)get_option('woocommerce_weight_unit', 'kg');

        if (($data['length'] === '' || $data['width'] === '' || $data['height'] === '') &&
            preg_match('/\b(?:dimensions?(?:\s+du\s+produit)?|taille\s+du\s+(?:produit|velo|vélo)|bike\s+size|product\s+dimensions?)\s*(?:\([^)]*\))?\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*[x×*]\s*(\d+(?:[.,]\d+)?)\s*(?:\(\s*)?(mm|cm|m|in|inch|inches)?(?:\s*\))?/iu', $plain, $m)) {
            $source_unit = $m[4] ?: $dimension_unit;
            $values = [$m[1], $m[2], $m[3]];
            foreach (['length','width','height'] as $i => $key) {
                if ($data[$key] !== '') continue;
                $value = (float)str_replace(',', '.', $values[$i]);
                $converted = function_exists('wc_get_dimension') ? wc_get_dimension($value, $dimension_unit, $source_unit) : $value;
                $data[$key] = wc_format_decimal($converted, 4);
            }
        }

        // Weight Evidence Resolver v2 — additive, product-weight-first and tolerance-aware.
        // Important: marketplace/specification text is often flattened (e.g. "Net Poids: 33.1±0.5kg")
        // and labels may mix languages. Resolve authoritative product/net weight before generic fallbacks.
        if ($data['weight'] === '') {
            $weight_patterns = [
                // Highest authority: explicit net/product/item weight labels, including mixed-language order.
                '/\b(?:poids\s+net|net\s+poids|net\s+weight|weight\s+net|poids\s+(?:du\s+)?produit|product\s+weight|item\s+weight|poids\s+article)\s*[:=\-]?\s*(\d+(?:[.,]\d+)?)(?:\s*(?:±|\+\/\-|\-\/\+|\+)\s*\d+(?:[.,]\d+)?)?\s*(kg|kgs?|kilogrammes?|g|grammes?|lb|lbs|pounds?|oz|ounces?)/iu',
                // Generic weight labels, but exclude obvious package/shipping/gross contexts via a bounded prefix check below.
                '/\b(?:poids|weight|masse)\s*[:=\-]?\s*(\d+(?:[.,]\d+)?)(?:\s*(?:±|\+\/\-|\-\/\+|\+)\s*\d+(?:[.,]\d+)?)?\s*(kg|kgs?|kilogrammes?|g|grammes?|lb|lbs|pounds?|oz|ounces?)/iu',
            ];
            foreach ($weight_patterns as $pattern_index => $pattern) {
                if (!preg_match_all($pattern, $plain, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) continue;
                foreach ($matches as $match) {
                    $offset = (int)$match[0][1];
                    $prefix = mb_strtolower(mb_substr($plain, max(0, $offset - 32), min(32, $offset), 'UTF-8'), 'UTF-8');
                    if ($pattern_index > 0 && preg_match('/(?:colis|emballage|pack(?:ing|age)?|shipping|gross|brut|expédition|expedition)\s*$/iu', $prefix)) continue;

                    $source_unit = mb_strtolower(remove_accents($match[2][0]));
                    if (preg_match('/^(?:kg|kgs|kilogrammes?)$/', $source_unit)) $source_unit = 'kg';
                    elseif (preg_match('/^(?:g|grammes?)$/', $source_unit)) $source_unit = 'g';
                    elseif (preg_match('/^(?:lb|lbs|pounds?)$/', $source_unit)) $source_unit = 'lbs';
                    elseif (preg_match('/^(?:oz|ounces?)$/', $source_unit)) $source_unit = 'oz';
                    $value = (float)str_replace(',', '.', $match[1][0]);
                    if ($value <= 0) continue;
                    $converted = function_exists('wc_get_weight') ? wc_get_weight($value, $weight_unit, $source_unit) : $value;
                    if ((float)$converted <= 0) continue;
                    $data['weight'] = wc_format_decimal($converted, 4);
                    $data['weight_source'] = $pattern_index === 0 ? 'authoritative_product_weight_evidence' : 'generic_weight_evidence';
                    $data['weight_raw_evidence'] = (string)$match[0][0];
                    break 2;
                }
            }
        }
        return $data;
    }


}
