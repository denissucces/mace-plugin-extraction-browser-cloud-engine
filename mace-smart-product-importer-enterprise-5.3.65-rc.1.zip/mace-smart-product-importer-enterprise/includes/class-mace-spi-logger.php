<?php
defined('ABSPATH') || exit;

final class MACE5311_SPI_Logger {
    public function log(string $level, string $message, array $context = []): void {
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->log($level, $message, ['source' => 'mace-smart-product-importer-5311-h5q7'] + $context);
        }
    }
}
