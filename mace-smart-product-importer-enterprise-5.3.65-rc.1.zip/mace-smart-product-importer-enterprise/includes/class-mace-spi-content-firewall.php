<?php
defined('ABSPATH') || exit;

/**
 * Storefront Content Firewall + locale normalizer.
 *
 * This class is deliberately source-agnostic: every customer-facing text passes
 * through the same rules regardless of whether it came from Cloud, Browser Bridge,
 * JSON-LD, HTML, Shopify state or a standalone adapter.
 */
final class MACE5311_SPI_Content_Firewall {
    private static function lower(string $value): string { return function_exists('mb_strtolower') ? mb_strtolower($value) : strtolower($value); }

    private static function filter_settings(): array {
        $s = function_exists('get_option') ? get_option('mace5311_spi_settings', []) : [];
        return is_array($s) ? $s : [];
    }

    private static function filter_enabled(): bool {
        $s = self::filter_settings();
        return !array_key_exists('advanced_autonomous_filtering', $s) || !empty($s['advanced_autonomous_filtering']);
    }

    private static function rule_lines(string $value): array {
        $out=[];
        foreach (preg_split('/\R/u', $value) ?: [] as $line) {
            $line=trim((string)$line);
            if ($line==='' || strpos($line,'#')===0) continue;
            if (!in_array($line,$out,true)) $out[]=$line;
            if (count($out)>=250) break;
        }
        return $out;
    }

    private static function norm_rule(string $value): string {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (class_exists('Transliterator')) {
            $tr = \Transliterator::create('NFD; [:Nonspacing Mark:] Remove; NFC');
            if ($tr) $value = (string)$tr->transliterate($value);
        }
        $value = self::lower($value);
        $value = preg_replace('/[^\p{L}\p{N}]+/u',' ',(string)$value);
        return trim(preg_replace('/\s+/u',' ',(string)$value));
    }

    public static function is_custom_forbidden(string $text): bool {
        if (!self::filter_enabled()) return false;
        $s=self::filter_settings(); $raw=trim(html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($raw==='') return false;
        $protected='/^(?:ean|gtin(?:8|12|13|14)?|upc|isbn(?:10|13)?|mpn|r[eé]f\.?\s*fabricant|r[eé]f[eé]rence\s*fabricant)$/iu';
        if (preg_match($protected,$raw)) return false;
        $hay = !empty($s['filter_case_insensitive']) || !array_key_exists('filter_case_insensitive',$s) ? self::norm_rule($raw) : $raw;
        foreach (self::rule_lines((string)($s['filter_blocked_terms']??'')) as $term) {
            $needle = !empty($s['filter_case_insensitive']) || !array_key_exists('filter_case_insensitive',$s) ? self::norm_rule($term) : $term;
            if ($needle!=='' && mb_strpos($hay,$needle)!==false) return true;
        }
        if (!empty($s['filter_concatenated_noise']) || !array_key_exists('filter_concatenated_noise',$s)) {
            foreach (self::rule_lines((string)($s['filter_blocked_prefixes']??'MMID')) as $prefix) {
                $p=preg_quote(trim($prefix),'/'); if($p!=='' && preg_match('/(?:^|[^\p{L}\p{N}])'.$p.'[\s:_\-]*[A-Z0-9]{4,}\b/iu',$raw)) return true;
                if($p!=='' && preg_match('/^'.$p.'[A-Z0-9]{4,}$/iu',preg_replace('/\s+/u','',$raw))) return true;
            }
        }
        foreach (self::rule_lines((string)($s['filter_blocked_regex']??'')) as $rx) {
            if (strlen($rx)>300) continue;
            $ok=@preg_match('/'.$rx.'/iu',$raw);
            if ($ok===1) return true;
        }
        return false;
    }

    private static function apply_custom_rules(string $text): string {
        if (!self::filter_enabled()) return $text;
        $s=self::filter_settings();
        if (!empty($s['filter_urls']) || !array_key_exists('filter_urls',$s)) {
            $text=preg_replace('~\b(?:https?://|www\.)\S+~iu',' ',(string)$text);
            $text=preg_replace('/\b(?:mailto|tel|sms|whatsapp)\s*:\s*\S+/iu',' ',(string)$text);
        }
        if (!empty($s['filter_personal_data']) || !array_key_exists('filter_personal_data',$s)) {
            $text=preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu',' ',(string)$text);
            $text=preg_replace('/(?:^|\s)\+\d(?:[\s().\-]*\d){7,}(?=\s|$)/u',' ',(string)$text);
        }
        foreach (self::rule_lines((string)($s['filter_blocked_terms']??'')) as $term) {
            $term=trim($term); if($term==='') continue;
            $text=preg_replace('/'.preg_quote($term,'/').'/iu',' ',(string)$text);
        }
        if (!empty($s['filter_concatenated_noise']) || !array_key_exists('filter_concatenated_noise',$s)) {
            foreach (self::rule_lines((string)($s['filter_blocked_prefixes']??'MMID')) as $prefix) {
                $p=preg_quote(trim($prefix),'/'); if($p==='') continue;
                $text=preg_replace('/\b'.$p.'[\s:_\-]*[A-Z0-9]{4,}\b/iu',' ',(string)$text);
            }
        }
        foreach (self::rule_lines((string)($s['filter_blocked_regex']??'')) as $rx) {
            if(strlen($rx)>300) continue;
            $next=@preg_replace('/'.$rx.'/iu',' ',(string)$text);
            if(is_string($next)) $text=$next;
        }
        return trim(preg_replace('/\s{2,}/u',' ',(string)$text));
    }


    /**
     * Export a bounded, non-secret filtering policy for Cloud + Browser Bridge.
     * This contains only administrator exclusion rules; credentials and site secrets
     * are never included. Unknown/newer policy fields are safe to ignore downstream.
     */
    public static function export_filtering_policy(): array {
        $s = self::filter_settings();
        $rules = static function(string $value, int $limit): array {
            $out = [];
            foreach (preg_split('/\R/u', $value) ?: [] as $line) {
                $line = trim((string)$line);
                if ($line === '' || strpos($line, '#') === 0) continue;
                $line = function_exists('mb_substr') ? mb_substr($line, 0, 300) : substr($line, 0, 300);
                if (!in_array($line, $out, true)) $out[] = $line;
                if (count($out) >= $limit) break;
            }
            return $out;
        };

        $policy = [
            'version' => 'h5q7-admin-filter-policy-v1',
            'enabled' => self::filter_enabled(),
            'case_insensitive' => !array_key_exists('filter_case_insensitive', $s) || !empty($s['filter_case_insensitive']),
            'remove_urls' => !array_key_exists('filter_urls', $s) || !empty($s['filter_urls']),
            'remove_personal_data' => !array_key_exists('filter_personal_data', $s) || !empty($s['filter_personal_data']),
            'remove_concatenated_noise' => !array_key_exists('filter_concatenated_noise', $s) || !empty($s['filter_concatenated_noise']),
            'blocked_terms' => $rules((string)($s['filter_blocked_terms'] ?? ''), 250),
            'blocked_prefixes' => $rules((string)($s['filter_blocked_prefixes'] ?? 'MMID'), 100),
            'blocked_regex' => $rules((string)($s['filter_blocked_regex'] ?? ''), 50),
            'protected_identifiers' => ['EAN','GTIN','UPC','ISBN','MPN','Réf. fabricant','Référence fabricant'],
            'scope' => ['title','short_description','description','attributes','categories','brand','browser_rendered_html'],
            'additive_only' => true,
        ];
        $encoded = function_exists('wp_json_encode') ? wp_json_encode($policy) : json_encode($policy);
        $policy['policy_hash'] = hash('sha256', (string)$encoded);
        return $policy;
    }

    public static function storefront_locale(): string {
        $locale = function_exists('get_locale') ? (string)get_locale() : 'fr_FR';
        return strtolower(str_replace('-', '_', $locale));
    }

    public static function contains_contact_or_personal_data(string $text): bool {
        $plain = html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu', $plain)) return true;
        if (preg_match('/\b(?:office\s*hours?|business\s*hours?|opening\s*hours?|horaires?\s*d[’\' ]?ouverture|whats\s*app|telegram|customer\s*service|service\s*client|contact\s*us|contactez[- ]nous|e-?mail|courriel|telephone|téléphone|phone|mobile|adresse|address)\s*[:：]?/iu', $plain)) return true;
        if (preg_match('/(?:^|\s)\+\d(?:[\s().\-]*\d){7,}(?:\s|$)/u', $plain)) return true;
        if (preg_match('~\b(?:https?://|www\.)\S+~iu', $plain)) return true;
        return false;
    }

    /** Remove source/contact tail and customer-inappropriate identifiers from plain text. */
    public static function sanitize_plain(string $text): string {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/[\p{Cf}\x{00AD}]+/u', ' ', (string)$text);

        // Contact blocks are commonly appended to otherwise-valid technical facts with
        // no punctuation. Once a contact marker starts, the remainder is not a product fact.
        $tail_marker = '/\b(?:office\s*hours?|business\s*hours?|opening\s*hours?|customer\s*service|contact\s*us|contactez[- ]nous|whats\s*app|telegram|e-?mail|courriel|telephone|téléphone|phone|mobile|address|adresse)\s*[:：]?/iu';
        if (preg_match($tail_marker, $text, $m, PREG_OFFSET_CAPTURE)) {
            $text = substr($text, 0, (int)$m[0][1]);
        }

        // Absolute guards in case contact data appears before a separator rather than as a tail.
        $text = preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu', ' ', (string)$text);
        $text = preg_replace('/(?:^|\s)\+\d(?:[\s().\-]*\d){7,}(?=\s|$)/u', ' ', (string)$text);
        $text = preg_replace('~\b(?:https?://|www\.)\S+~iu', ' ', (string)$text);
        $text = preg_replace('/\b(?:mailto|tel|sms|whatsapp)\s*:\s*\S+/iu', ' ', (string)$text);
        $text = preg_replace('/\s{2,}/u', ' ', (string)$text);
        $text = self::apply_custom_rules((string)$text);
        return trim((string)$text, " \t\n\r\0\x0B,;|-.");
    }

    /**
     * Sanitize customer-facing HTML while preserving product images and formatting.
     * Contact/source blocks are removed before presentation or translation.
     */
    public static function sanitize_html(string $html): string {
        $html = trim($html);
        if ($html === '') return '';

        // Entire semantic blocks carrying contact/source metadata are never useful product content.
        $html = preg_replace('~<(p|div|li|section|aside|tr|small)\b[^>]*>[^<]*(?:office\s*hours?|business\s*hours?|opening\s*hours?|customer\s*service|contact\s*us|whats\s*app|telegram|e-?mail|telephone|téléphone|phone|address|adresse)[\s\S]*?</\1>~iu', '', $html);
        $html = preg_replace('~<a\b[^>]*href=["\'](?:mailto:|tel:|sms:|https?://)[^"\']*["\'][^>]*>(.*?)</a>~isu', '$1', (string)$html);

        if (class_exists('DOMDocument')) {
            $previous = libxml_use_internal_errors(true);
            $doc = new DOMDocument('1.0', 'UTF-8');
            $wrapper_id = 'mace-content-root';
            $loaded = $doc->loadHTML('<?xml encoding="utf-8" ?><div id="'.$wrapper_id.'">'.$html.'</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
            if ($loaded) {
                $xpath = new DOMXPath($doc);

                // Product Boundary Firewall v1: remove structural storefront chrome before
                // touching text. This prevents footer/navigation/account/payment blocks from
                // ever being materialized in descriptions, regardless of marketplace.
                $structural = $xpath->query('//*[@id="'.$wrapper_id.'"]//*[self::footer or self::nav or self::aside or @role="navigation" or @role="contentinfo" or @role="dialog"]');
                if ($structural) {
                    $remove = [];
                    foreach ($structural as $node) $remove[] = $node;
                    foreach (array_reverse($remove) as $node) if ($node->parentNode) $node->parentNode->removeChild($node);
                }

                $chromePattern = '/(?:vos\s+produits\s+vus\s+r[eé]cemment|vous\s+[eê]tes\s+ici|newsletter|paiement\s+s[eé]curis[eé]|suivi\s+de\s+commande|retour\s*\/\s*r[eé]tractation|besoin\s+d.?aide|nous\s+contacter|notifier\s+un\s+contenu\s+illicite|devenir\s+marchand|programme\s+d.?affiliation|conditions\s+g[eé]n[eé]rales|nos\s+inspirations|top\s+ventes?|d[eé]couvrir\s+manoexpress|plan\s+du\s+site|mentions?\s+l[eé]gales?|protection\s+des\s+donn[eé]es|trust\s+center|accessibilit[eé]|catalogue|seconde\s+vie|les\s+conseils\s+de\s+nos\s+experts|aide\s+et\s+param[eè]tres|aide\s+et\s+contact|pro\.?\s*cr[eé]ez\s+votre\s+compte|d[eé]couvrir\s+notre\s+app|manomano\s+infos?|©\s*\d{4}\s*manomano|google\s+play|app\s+store|facebook|instagram|linkedin|tiktok|pinterest)/iu';
                $candidateNodes = $xpath->query('//*[@id="'.$wrapper_id.'"]//*[self::section or self::div or self::p or self::li or self::ul or self::ol or self::h2 or self::h3 or self::h4 or self::h5 or self::h6]');
                if ($candidateNodes) {
                    $remove = [];
                    foreach ($candidateNodes as $node) {
                        $plain = trim(preg_replace('/\s+/u', ' ', (string)$node->textContent));
                        if ($plain === '' || mb_strlen($plain) > 1800) continue;
                        if (preg_match($chromePattern, $plain)) $remove[] = $node;
                    }
                    // Remove deepest nodes first so a child removal cannot invalidate traversal.
                    foreach (array_reverse($remove) as $node) if ($node->parentNode) $node->parentNode->removeChild($node);
                }

                foreach ($xpath->query('//*[@id="'.$wrapper_id.'"]//text()') as $node) {
                    $parent = $node->parentNode;
                    if ($parent && in_array(strtolower((string)$parent->nodeName), ['script','style'], true)) continue;
                    $node->nodeValue = self::sanitize_plain((string)$node->nodeValue);
                }
                $root = $doc->getElementById($wrapper_id);
                if ($root) {
                    $result = '';
                    foreach ($root->childNodes as $child) $result .= $doc->saveHTML($child);
                    $html = $result;
                }
            }
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        } else {
            // Conservative fallback for hosts without DOMDocument.
            $html = preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu', ' ', (string)$html);
            $html = preg_replace('/\b(?:office\s*hours?|business\s*hours?|whats\s*app|telegram|e-?mail|telephone|téléphone|phone|address|adresse)\b[^<]*/iu', ' ', (string)$html);
        }
        return trim((string)$html);
    }

    public static function detect_language(string $text): string {
        $plain = self::lower(self::sanitize_plain(wp_strip_all_tags($text)));
        if ($plain === '') return 'und';
        $en = preg_match_all('/\b(?:the|and|with|for|battery|motor|speed|range|weight|size|charging|waterproof|brake|electric|scooter|bike|front|rear|power|maximum|fold)\b/u', $plain, $tmp1);
        $fr = preg_match_all('/\b(?:le|la|les|et|avec|pour|batterie|moteur|vitesse|autonomie|poids|dimensions|charge|frein|electrique|électrique|trottinette|velo|vélo|avant|arriere|arrière|puissance)\b/u', $plain, $tmp2);
        if ($en >= 4 && $en > ($fr * 2 + 1)) return 'en';
        if ($fr >= 3 && $fr >= $en) return 'fr';
        return 'und';
    }

    /**
     * Built-in deterministic translation for common product/specification language.
     * A site can provide a stronger translator through the documented filter without
     * weakening the privacy firewall.
     */
    public static function translate_to_store_locale(string $text, string $context = 'text'): string {
        $clean = self::sanitize_plain($text);
        if ($clean === '') return '';
        $locale = self::storefront_locale();
        $source = self::detect_language($clean);
        if (strpos($locale, 'fr') !== 0 || $source !== 'en') return $clean;

        $filtered = apply_filters('mace5311_spi_translate_product_text', null, $clean, 'en', 'fr', $context);
        if (is_string($filtered) && trim($filtered) !== '') return self::sanitize_plain($filtered);

        // Longest phrases first to prevent partial replacements from damaging meaning.
        $map = [
            'Front and rear disc brake & e-brake'=>'Freins à disque avant et arrière avec frein électrique',
            'Front and rear disc brakes'=>'Freins à disque avant et arrière',
            'Dimensions unfolded'=>'Dimensions dépliées',
            'Unfolded dimensions'=>'Dimensions dépliées',
            'Packing size'=>'Dimensions de l’emballage',
            'Package size'=>'Dimensions de l’emballage',
            'Fold size'=>'Dimensions pliées',
            'Net weight'=>'Poids net',
            'Max load'=>'Charge maximale',
            'Maximum load'=>'Charge maximale',
            'Max speed'=>'Vitesse maximale',
            'Maximum speed'=>'Vitesse maximale',
            'Charging time'=>'Temps de charge',
            'Waterproof level'=>'Indice d’étanchéité',
            'Brake system'=>'Système de freinage',
            'Speed level'=>'Niveaux de vitesse',
            'Electric Scooter'=>'Trottinette électrique',
            'Dual Motor'=>'Double moteur',
            'Powerful Motor'=>'Moteur puissant',
            'Battery'=>'Batterie',
            'Range'=>'Autonomie',
            'Motor'=>'Moteur',
            'Weight'=>'Poids',
            'Dimensions'=>'Dimensions',
            'Waterproof'=>'Étanchéité',
            'Front'=>'Avant',
            'Rear'=>'Arrière',
            'Yes'=>'Oui',
            'No'=>'Non',
        ];
        $translated = $clean;
        foreach ($map as $from => $to) $translated = preg_replace('/\b'.preg_quote($from, '/').'\b/iu', $to, (string)$translated);
        $translated = preg_replace('/\s{2,}/u', ' ', (string)$translated);
        return trim((string)$translated);
    }
}
