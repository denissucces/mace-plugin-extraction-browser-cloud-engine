<?php
defined('ABSPATH') || exit;

final class MACE5311_SPI_Admin {
    private $importer, $client, $logger;
    public function __construct(MACE5311_SPI_Importer $importer, MACE5311_SPI_Client $client, MACE5311_SPI_Logger $logger) {
        $this->importer=$importer; $this->client=$client; $this->logger=$logger;
        add_action('admin_menu', [$this,'menu']);
        add_action('admin_post_mace5311_spi_import', [$this,'import']);
        add_action('admin_post_mace5311_spi_save', [$this,'save']);
        add_action('admin_post_mace5311_spi_health', [$this,'health']);
        add_action('admin_post_mace5311_spi_resume_bridge', [$this,'resume_bridge']);
        add_action('admin_post_mace5311_spi_activate_cloud', [$this,'activate_cloud']);
        add_action('admin_notices', [$this,'notices']);
    }

    private function version_label(): string {
        return preg_replace('/-rc\\.\\d+$/i', ' RC1', MACE5311_SPI_VERSION);
    }

    private function admin_slug(): string {
        $stable = preg_replace('/-rc\\.\\d+$/i', '', MACE5311_SPI_VERSION);
        $digits = preg_replace('/[^0-9]/', '', $stable);
        return 'mace-smart-importer-' . $digits . '-h5q7';
    }

    public function menu(): void {
        $version = preg_replace('/-rc\\.\\d+$/i', '', MACE5311_SPI_VERSION);
        add_submenu_page(
            'woocommerce',
            'MACE Smart Product Importer Enterprise ' . $this->version_label(),
            'MACE ' . $this->version_label(),
            'manage_woocommerce',
            $this->admin_slug(),
            [$this,'page']
        );

        // Hidden compatibility alias: old bookmarks/redirects still reach the current page,
        // while the visible menu and canonical URL always use the current release number.
        add_submenu_page(
            null,
            'MACE Smart Product Importer H5Q7',
            'MACE Smart Product Importer H5Q7',
            'manage_woocommerce',
            'mace-smart-importer-5311-h5q7',
            [$this,'page']
        );
    }

    public function page(): void {
        $s = get_option('mace5311_spi_settings', []); $history = array_reverse(get_option('mace5311_spi_history', []));
        ?>
        <div class="wrap"><h1>MACE Smart Product Importer Enterprise <?php echo esc_html($this->version_label()); ?></h1>
        <div class="notice notice-info inline"><p><strong>Édition H5Q7 :</strong> réglages, actions et historique isolés pour sécuriser les tests et imports.<br><strong>Mode actuel :</strong> import automatique par URL. Lorsque « Utiliser MACE Cloud » est activé, la connexion au Cloud est enregistrée automatiquement et le Cloud peut être essayé en priorité.</p></div>
        <div class="card" style="max-width:1100px;padding:24px"><h2>Importer automatiquement</h2><p>Collez uniquement l’URL du produit. Aucun autre champ produit n’est demandé.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('mace5311_spi_import'); ?><input type="hidden" name="action" value="mace5311_spi_import"><input class="large-text" type="url" name="url" required placeholder="https://...">
        <p style="margin:14px 0 4px"><label><input type="checkbox" name="air_long_description" value="1" checked> <strong>Aérer automatiquement la description longue (paragraphes)</strong></label></p>
        <p class="description" style="max-width:900px">Activé par défaut : MACE sépare uniquement les paragraphes trop denses sur les frontières de phrases déjà présentes, sans reformuler ni supprimer de faits. Décochez seulement si vous voulez une copie visuelle aussi stricte que possible de la source.</p>
        <p style="margin:12px 0 4px"><label><input type="checkbox" name="merchant_long_description" value="1"> <strong>Professionnaliser la description longue (Merchant / WooCommerce)</strong></label></p>
        <p class="description" style="max-width:900px">Option avancée : présentation Merchant plus soignée (espacement, paragraphes denses, titres, listes et tableaux), sans réécrire ni inventer les faits. Le Content Fidelity Guard annule automatiquement toute transformation qui modifierait une information. Le Marketplace Noise Firewall supprime toujours les blocs étrangers à la fiche produit (par ex. « Les internautes ont aussi acheté »).</p>
        <p><?php submit_button('Importer automatiquement','primary','submit',false); ?></p></form></div>

        <div class="card" style="max-width:1100px;padding:24px"><h2>MACE Cloud</h2>
        <?php $cloud_active = !empty($s['cloud_token']) || !empty($s['cloud_api_key']); ?>
        <p><strong>État :</strong> <?php echo $cloud_active ? '<span style="color:#167c2f">● Activé</span>' : '<span style="color:#b32d2e">● Non activé</span>'; ?><?php if (!empty($s['cloud_token_expires'])) echo ' — expiration '.esc_html($s['cloud_token_expires']); ?></p>
        <?php if (!$cloud_active): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:18px"><?php wp_nonce_field('mace5311_spi_activate_cloud'); ?><input type="hidden" name="action" value="mace5311_spi_activate_cloud"><?php submit_button('Activer MACE Cloud automatiquement','primary','submit',false); ?></form><?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('mace5311_spi_save'); ?><input type="hidden" name="action" value="mace5311_spi_save">
        <table class="form-table"><tr><th>Activer le Cloud</th><td><label><input type="checkbox" name="cloud_enabled" value="1" <?php checked(!empty($s['cloud_enabled'])); ?>> Utiliser MACE Cloud</label></td></tr>
        <tr><th>URL MACE Cloud</th><td><input class="large-text" type="url" name="cloud_url" value="<?php echo esc_attr($s['cloud_url'] ?? MACE5311_SPI_CLOUD_URL); ?>" placeholder="https://mace-cloud-extraction-engine-h5q7.onrender.com"><p class="description">Endpoint recommandé : <code><?php echo esc_html(MACE5311_SPI_CLOUD_URL); ?></code>. Un changement d'endpoint invalide automatiquement l'ancien jeton afin d'éviter une fausse connexion.</p></td></tr>
        <tr><th>Clé API avancée</th><td><input class="regular-text" type="password" name="cloud_api_key" value="" autocomplete="new-password" placeholder="Facultatif"><p class="description">Laissez vide lorsque l’activation automatique est utilisée.</p></td></tr>
        <tr><th>Cloud prioritaire</th><td><label><input type="checkbox" name="cloud_first" value="1" <?php checked(!empty($s['cloud_first'])); ?>> Essayer le Cloud avant le mode autonome</label></td></tr>
        <tr><th>Score minimum</th><td><input type="number" name="minimum_score" min="50" max="100" value="<?php echo esc_attr($s['minimum_score'] ?? 70); ?>"> %</td></tr>
        <tr><th>Statut produit</th><td><select name="status"><option value="draft" <?php selected($s['status'] ?? 'draft','draft'); ?>>Brouillon</option><option value="pending" <?php selected($s['status'] ?? '','pending'); ?>>En attente</option><option value="publish" <?php selected($s['status'] ?? '','publish'); ?>>Publié</option></select></td></tr>
        <tr><th>Description courte intelligente</th><td><select name="short_description_mode"><option value="automatic" <?php selected($s['short_description_mode'] ?? 'automatic','automatic'); ?>>Automatique — remplacer seulement si qualité insuffisante</option><option value="always_generate" <?php selected($s['short_description_mode'] ?? '','always_generate'); ?>>Toujours régénérer depuis la description longue</option><option value="preserve_source" <?php selected($s['short_description_mode'] ?? '','preserve_source'); ?>>Toujours conserver la source</option></select><p class="description">Le mode automatique rejette les textes vides, répétitifs ou promotionnels (« Achetez sur… », livraison, retrait magasin) et applique des règles bloquantes aux textes de marketplace, puis génère 1 à 2 phrases factuelles sans inventer d’informations.</p></td></tr>
        <tr><th>Présentation de la description courte</th><td><select name="short_description_format"><option value="professional" <?php selected($s['short_description_format'] ?? 'professional','professional'); ?>>Professionnelle — introduction aérée + points clés</option><option value="standard" <?php selected($s['short_description_format'] ?? '','standard'); ?>>Standard — paragraphes courts</option><option value="plain" <?php selected($s['short_description_format'] ?? '','plain'); ?>>Texte simple</option></select><p class="description">La présentation professionnelle utilise uniquement un HTML WooCommerce léger et éditable : paragraphes, liste et mise en valeur mesurée.</p></td></tr>
        <tr><th>Graphisme énergie / durabilité</th><td><label><input type="checkbox" name="short_environmental_badges" value="1" <?php checked(array_key_exists('short_environmental_badges',$s) ? !empty($s['short_environmental_badges']) : true); ?>> Afficher dans la description courte le graphisme « Classe énergétique / Indice de durabilité / Indice de réparabilité » lorsqu’une preuve existe</label><p class="description">Ce réglage agit uniquement sur la présentation de la description courte. Les valeurs restent toujours conservées dans les attributs et autres données produit, même lorsque cette case est décochée.</p></td></tr>
        <tr><th>Politique UGS / SKU</th><td>
        <select name="sku_strategy">
          <option value="source_preferred" <?php selected($s['sku_strategy'] ?? 'source_preferred','source_preferred'); ?>>Source prioritaire — conserver l’UGS source si elle est fiable, sinon générer</option>
          <option value="mace_generated" <?php selected($s['sku_strategy'] ?? '','mace_generated'); ?>>MACE stable — toujours générer une UGS interne stable</option>
          <option value="company_custom" <?php selected($s['sku_strategy'] ?? '','company_custom'); ?>>Société personnalisée — combiner les initiales de la société avec lettres et chiffres</option>
        </select>
        <p class="description">Une UGS déjà attribuée à un produit existant n’est jamais modifiée automatiquement. Cette stabilité est essentielle pour les catalogues, les flux et Google Merchant Center.</p>
        <p style="margin-top:10px"><label>Initiales société <input type="text" name="sku_company_initials" maxlength="8" size="10" value="<?php echo esc_attr($s['sku_company_initials'] ?? ''); ?>" placeholder="GMGT"></label>
        &nbsp; <label>Position <select name="sku_company_position"><option value="prefix" <?php selected($s['sku_company_position'] ?? 'prefix','prefix'); ?>>Début</option><option value="middle" <?php selected($s['sku_company_position'] ?? '','middle'); ?>>Milieu</option><option value="suffix" <?php selected($s['sku_company_position'] ?? '','suffix'); ?>>Fin</option></select></label>
        &nbsp; <label>Longueur cible <input type="number" name="sku_total_length" min="8" max="32" value="<?php echo esc_attr($s['sku_total_length'] ?? 12); ?>" style="width:75px"></label>
        &nbsp; <label><input type="checkbox" name="sku_use_separator" value="1" <?php checked(array_key_exists('sku_use_separator',$s) ? !empty($s['sku_use_separator']) : true); ?>> utiliser « - »</label></p>
        <p class="description">Les UGS générées utilisent uniquement des caractères ASCII sûrs (A–Z, 0–9 et éventuellement « - »), restent uniques et déterministes, et ne remplacent jamais le GTIN/EAN ni la référence fabricant.</p></td></tr>
        <tr><th>Filtrage avancé et autonome</th><td>
        <label><input type="checkbox" name="advanced_autonomous_filtering" value="1" <?php checked(array_key_exists('advanced_autonomous_filtering',$s) ? !empty($s['advanced_autonomous_filtering']) : true); ?>> <strong>Activer le Firewall d’exclusion totale</strong></label>
        <p class="description">Activé par défaut. Couche terminale appliquée aux descriptions, attributs et textes publiables, indépendamment de la source (Cloud, Browser Bridge, HTML, JSON-LD, scripts embarqués, API ou import autonome).</p>
        <p><label><strong>Mots / termes / fragments interdits</strong><br><textarea class="large-text code" rows="5" name="filter_blocked_terms" placeholder="Un élément par ligne. Exemple : MMID
Top ventes
Nom de marketplace"><?php echo esc_textarea($s['filter_blocked_terms'] ?? ''); ?></textarea></label></p>
        <p><label><strong>Préfixes concaténés interdits</strong><br><textarea class="large-text code" rows="3" name="filter_blocked_prefixes" placeholder="Un préfixe par ligne. Exemple : MMID
internalId
sellerRef"><?php echo esc_textarea($s['filter_blocked_prefixes'] ?? "MMID"); ?></textarea></label></p>
        <p><label><strong>Expressions régulières avancées</strong><br><textarea class="large-text code" rows="4" name="filter_blocked_regex" placeholder="Une expression PCRE par ligne, sans délimiteurs. Réservé aux administrateurs avancés."><?php echo esc_textarea($s['filter_blocked_regex'] ?? ''); ?></textarea></label></p>
        <p><label><input type="checkbox" name="filter_urls" value="1" <?php checked(array_key_exists('filter_urls',$s) ? !empty($s['filter_urls']) : true); ?>> Supprimer les URL, domaines, mailto/tel/sms/WhatsApp</label><br>
        <label><input type="checkbox" name="filter_personal_data" value="1" <?php checked(array_key_exists('filter_personal_data',$s) ? !empty($s['filter_personal_data']) : true); ?>> Supprimer les e-mails, téléphones, adresses/contact et données personnelles détectables</label><br>
        <label><input type="checkbox" name="filter_concatenated_noise" value="1" <?php checked(array_key_exists('filter_concatenated_noise',$s) ? !empty($s['filter_concatenated_noise']) : true); ?>> Bloquer les identifiants/termes parasites concaténés à un libellé ou une valeur</label><br>
        <label><input type="checkbox" name="filter_case_insensitive" value="1" <?php checked(array_key_exists('filter_case_insensitive',$s) ? !empty($s['filter_case_insensitive']) : true); ?>> Recherche insensible à la casse et aux accents</label></p>
        <p class="description"><strong>Protection anti-régression :</strong> EAN, GTIN, UPC, ISBN, MPN et Réf. fabricant restent protégés. Les règles personnalisées sont additives : elles n’effacent aucune voie de récupération validée, elles filtrent uniquement la sortie publiable.</p></td></tr>
        <tr><th>Images produit</th><td><label><input type="checkbox" name="download_images" value="1" <?php checked(!empty($s['download_images'])); ?>> Télécharger uniquement les images validées comme appartenant au produit</label><br><label><input type="checkbox" name="import_brand_logo" value="1" <?php checked(!empty($s['import_brand_logo'])); ?>> Importer séparément le logo de la marque lorsqu’il est clairement identifié</label><br><label><input type="checkbox" name="rename_images" value="1" <?php checked(!empty($s['rename_images'])); ?>> Renommer automatiquement les fichiers avec marque, produit, référence et vue</label><br><label><input type="checkbox" name="generate_image_alt" value="1" <?php checked(!empty($s['generate_image_alt'])); ?>> Générer les titres et textes alternatifs descriptifs</label><br><label><input type="checkbox" name="reject_suspected_watermarks" value="1" <?php checked(!empty($s['reject_suspected_watermarks'])); ?>> Rejeter les images suspectées de contenir filigrane, prix ou texte promotionnel</label><br>Maximum galerie <input type="number" name="max_images" min="1" max="30" value="<?php echo esc_attr($s['max_images'] ?? 15); ?>"><p class="description">Les images tierces marquées sont exclues. Le nettoyage automatique de filigranes n’est pas appliqué aux médias externes sans autorisation.</p></td></tr>
        <tr><th>Mise à jour</th><td><label><input type="checkbox" name="update_existing" value="1" <?php checked(!empty($s['update_existing'])); ?>> Mettre à jour par URL ou SKU</label><p class="description">Désactivé par défaut pour éviter qu’un test ou un import de validation modifie involontairement un produit existant. Activez cette option uniquement lorsque vous souhaitez mettre à jour un produit déjà présent, retrouvé par son SKU ou par l’URL source enregistrée.</p></td></tr>
        <tr><th>Délai</th><td><input type="number" name="timeout" min="10" max="90" value="<?php echo esc_attr($s['timeout'] ?? 45); ?>"> secondes</td></tr>
        <tr><th>Domaines autorisés</th><td><textarea class="large-text" rows="2" name="allowed_hosts"><?php echo esc_textarea($s['allowed_hosts'] ?? ''); ?></textarea><p class="description">Vide = tous les domaines publics.</p></td></tr></table><?php submit_button('Enregistrer les réglages'); ?></form>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('mace5311_spi_health'); ?><input type="hidden" name="action" value="mace5311_spi_health"><?php submit_button('Tester la connexion MACE Cloud','secondary','submit',false); ?></form></div>

        <?php $bridge=get_option('mace5311_spi_pending_bridge',[]); if(!empty($bridge['code'])): ?>
<div class="card" style="max-width:1100px;padding:24px;border-left:4px solid #dba617"><h2>MACE Browser Bridge</h2>
<p><strong>Source protégée détectée.</strong> Ouvrez l’URL du produit dans Chrome, utilisez l’extension MACE Browser Bridge et saisissez ce code :</p>
<p style="font-size:28px;font-weight:700;letter-spacing:3px"><code><?php echo esc_html($bridge['code']); ?></code></p>
<p><a class="button" target="_blank" rel="noopener" href="<?php echo esc_url($bridge['url']); ?>">Ouvrir la page produit</a></p>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('mace5311_spi_resume_bridge'); ?><input type="hidden" name="action" value="mace5311_spi_resume_bridge"><?php submit_button('Vérifier la capture et reprendre l’import','primary','submit',false); ?></form></div>
<?php endif; ?>

<div class="card" style="max-width:1100px;padding:24px"><h2>Historique</h2><table class="widefat striped"><thead><tr><th>Date</th><th>Résultat</th><th>Méthode</th><th>Qualité</th><th>Détails</th><th></th></tr></thead><tbody>
        <?php if (!$history): ?><tr><td colspan="6">Aucun import.</td></tr><?php else: foreach (array_slice($history,0,50) as $row): ?><tr><td><?php echo esc_html($row['date']); ?></td><td><?php echo !empty($row['success'])?'✅ Succès':'❌ Échec'; ?></td><td><?php echo esc_html($row['method'] ?? '—'); ?></td><td><?php echo isset($row['score']) && $row['score'] !== null ? esc_html($row['score'].' %') : '—'; ?></td><td><?php echo esc_html($row['message']); ?></td><td><?php if (!empty($row['product_id'])): ?><a class="button" href="<?php echo esc_url(get_edit_post_link((int)$row['product_id'])); ?>">Ouvrir</a><?php endif; ?></td></tr><?php endforeach; endif; ?>
        </tbody></table></div></div><?php
    }

    public function import(): void {
        $this->guard('mace5311_spi_import');
        $url = esc_url_raw(wp_unslash($_POST['url'] ?? ''));
        $import_options = ['air_long_description' => isset($_POST['air_long_description']) ? 1 : 0, 'merchant_long_description' => isset($_POST['merchant_long_description']) ? 1 : 0];
        $result = $this->importer->import($url, $import_options);
        if (is_wp_error($result)) {
            $detail = $result->get_error_message(); $data = $result->get_error_data();
            if ($result->get_error_code()==='bridge_required' && is_array($data) && !empty($data['code'])) {
                update_option('mace5311_spi_pending_bridge',['code'=>sanitize_text_field($data['code']),'url'=>$url,'expires_at'=>sanitize_text_field($data['expires_at']??''),'air_long_description'=>!empty($import_options['air_long_description'])?1:0,'merchant_long_description'=>!empty($import_options['merchant_long_description'])?1:0],false);
                $this->history(false,$url,'Browser Bridge requis ; code '.$data['code'],0,'browser-bridge',null);
                $this->redirect(['mace5311_spi_error'=>rawurlencode('Source protégée : capture Browser Bridge requise. Utilisez le code '.$data['code'].' puis cliquez sur « Vérifier et reprendre ».')]);
            }
            if (is_array($data) && !empty($data['attempts'])) $detail .= ' Tentatives : ' . wp_json_encode($data['attempts']);
            $this->history(false,$url,$detail,0,'',null); $this->redirect(['mace5311_spi_error'=>rawurlencode($detail)]);
        }
        $id=(int)$result['product_id']; $message=($result['updated']?'Produit mis à jour':'Produit créé').' #'.$id.' via '.$result['fetch']['method'].' ; qualité '.$result['quality']['score'].' % ; images '.$result['images'].' ; description '.($result['description_mode']??'source_fidelity').' ; durée '.$result['duration'].' s.';
        $this->history(true,$url,$message,$id,$result['fetch']['method'],$result['quality']['score']); $this->redirect(['mace5311_spi_success'=>$id,'mace5311_spi_message'=>rawurlencode($message)]);
    }


    public function resume_bridge(): void {
        $this->guard('mace5311_spi_resume_bridge'); $pending=get_option('mace5311_spi_pending_bridge',[]);
        if(empty($pending['code'])||empty($pending['url']))$this->redirect(['mace5311_spi_error'=>rawurlencode('Aucune session Browser Bridge en attente.')]);
        $result=$this->importer->resume_bridge((string)$pending['url'],(string)$pending['code'],['air_long_description'=>!empty($pending['air_long_description'])?1:0,'merchant_long_description'=>!empty($pending['merchant_long_description'])?1:0]);
        if(is_wp_error($result))$this->redirect(['mace5311_spi_error'=>rawurlencode($result->get_error_message())]);
        delete_option('mace5311_spi_pending_bridge'); $id=(int)$result['product_id'];
        $message=($result['updated']?'Produit mis à jour':'Produit créé').' #'.$id.' via Browser Bridge ; qualité '.$result['quality']['score'].' % ; images '.$result['images'].' ; caractéristiques '.(int)($result['specifications']??0).' ; description '.($result['description_mode']??'source_fidelity').'.';
        $this->history(true,(string)$pending['url'],$message,$id,'browser-bridge',$result['quality']['score']);
        $this->redirect(['mace5311_spi_success'=>$id,'mace5311_spi_message'=>rawurlencode($message)]);
    }

    public function save(): void {
        $this->guard('mace5311_spi_save'); $old=get_option('mace5311_spi_settings',[]); $key=sanitize_text_field(wp_unslash($_POST['cloud_api_key'] ?? ''));
        $new_cloud_url = rtrim(esc_url_raw(wp_unslash($_POST['cloud_url'] ?? MACE5311_SPI_CLOUD_URL)), '/');
        if ($new_cloud_url === '') $new_cloud_url = MACE5311_SPI_CLOUD_URL;
        $old_cloud_url = rtrim((string)($old['cloud_url'] ?? ''), '/');
        $endpoint_changed = ($old_cloud_url !== '' && $old_cloud_url !== $new_cloud_url);
        $settings = [
            'cloud_url'=>$new_cloud_url,
            'cloud_api_key'=>$key!==''?$key:($endpoint_changed?'':($old['cloud_api_key']??'')),
            'cloud_token'=>$endpoint_changed?'':($old['cloud_token']??''),
            'cloud_token_expires'=>$endpoint_changed?'':($old['cloud_token_expires']??''),
            'installation_id'=>$old['installation_id']??wp_generate_uuid4(),
            'cloud_enabled'=>isset($_POST['cloud_enabled'])?1:0,
            'cloud_first'=>isset($_POST['cloud_first'])?1:0,
            'minimum_score'=>max(50,min(100,(int)($_POST['minimum_score']??70))),
            'status'=>in_array($_POST['status']??'draft',['draft','pending','publish'],true)?sanitize_key($_POST['status']):'draft',
            'short_description_mode'=>in_array($_POST['short_description_mode']??'automatic',['automatic','always_generate','preserve_source'],true)?sanitize_key($_POST['short_description_mode']):'automatic',
            'short_description_format'=>in_array($_POST['short_description_format']??'professional',['professional','standard','plain'],true)?sanitize_key($_POST['short_description_format']):'professional',
            'short_environmental_badges'=>isset($_POST['short_environmental_badges'])?1:0,
            'sku_strategy'=>in_array($_POST['sku_strategy']??'source_preferred',['source_preferred','mace_generated','company_custom'],true)?sanitize_key($_POST['sku_strategy']):'source_preferred',
            'sku_company_initials'=>substr(preg_replace('/[^A-Z0-9]/','',strtoupper(sanitize_text_field(wp_unslash($_POST['sku_company_initials']??'')))),0,8),
            'sku_company_position'=>in_array($_POST['sku_company_position']??'prefix',['prefix','middle','suffix'],true)?sanitize_key($_POST['sku_company_position']):'prefix',
            'sku_total_length'=>max(8,min(32,(int)($_POST['sku_total_length']??12))),
            'sku_use_separator'=>isset($_POST['sku_use_separator'])?1:0,
            'advanced_autonomous_filtering'=>isset($_POST['advanced_autonomous_filtering'])?1:0,
            'filter_blocked_terms'=>sanitize_textarea_field(wp_unslash($_POST['filter_blocked_terms']??'')),
            'filter_blocked_prefixes'=>sanitize_textarea_field(wp_unslash($_POST['filter_blocked_prefixes']??'MMID')),
            'filter_blocked_regex'=>sanitize_textarea_field(wp_unslash($_POST['filter_blocked_regex']??'')),
            'filter_urls'=>isset($_POST['filter_urls'])?1:0,
            'filter_personal_data'=>isset($_POST['filter_personal_data'])?1:0,
            'filter_concatenated_noise'=>isset($_POST['filter_concatenated_noise'])?1:0,
            'filter_case_insensitive'=>isset($_POST['filter_case_insensitive'])?1:0,
            'download_images'=>isset($_POST['download_images'])?1:0,
            'import_brand_logo'=>isset($_POST['import_brand_logo'])?1:0,
            'max_images'=>max(1,min(30,(int)($_POST['max_images']??15))),
            'rename_images'=>isset($_POST['rename_images'])?1:0,
            'generate_image_alt'=>isset($_POST['generate_image_alt'])?1:0,
            'reject_suspected_watermarks'=>isset($_POST['reject_suspected_watermarks'])?1:0,
            'update_existing'=>isset($_POST['update_existing'])?1:0,
            'timeout'=>max(10,min(90,(int)($_POST['timeout']??45))),
            'allowed_hosts'=>sanitize_textarea_field(wp_unslash($_POST['allowed_hosts']??'')),
        ];
        update_option('mace5311_spi_settings',$settings,false);

        // Cocher « Utiliser MACE Cloud » suffit : si aucun identifiant valide n'est encore
        // enregistré pour cet endpoint, le plugin tente immédiatement l'activation automatique.
        if (!empty($settings['cloud_enabled']) && empty($settings['cloud_token']) && empty($settings['cloud_api_key'])) {
            $activation = $this->client->register();
            if (is_wp_error($activation)) {
                $this->redirect(['mace5311_spi_error'=>rawurlencode('Réglages enregistrés, mais la liaison MACE Cloud doit être réactivée : '.$activation->get_error_message())]);
            }
            $this->redirect(['mace5311_spi_health'=>rawurlencode('Réglages enregistrés et MACE Cloud relié automatiquement au nouvel endpoint. Jeton valable jusqu’au '.($activation['expires_at']??'—').'.')]);
        }
        $this->redirect(['mace5311_spi_saved'=>1]);
    }

    public function activate_cloud(): void {
        $this->guard('mace5311_spi_activate_cloud');
        $result = $this->client->register();
        $this->redirect(is_wp_error($result) ? ['mace5311_spi_error'=>rawurlencode($result->get_error_message())] : ['mace5311_spi_health'=>rawurlencode('MACE Cloud activé automatiquement pour ce site. Jeton valable jusqu’au '.($result['expires_at']??'—').'.')]);
    }

    public function health(): void {
        $this->guard('mace5311_spi_health');
        $capabilities = $this->client->capabilities();
        if (is_wp_error($capabilities)) { $this->redirect(['mace5311_spi_error'=>rawurlencode($capabilities->get_error_message())]); }
        $verify = $this->client->verify();
        if (is_wp_error($verify)) { $this->redirect(['mace5311_spi_error'=>rawurlencode($verify->get_error_message())]); }
        $result=$this->client->health();
        $this->redirect(is_wp_error($result)?['mace5311_spi_error'=>rawurlencode($result->get_error_message())]:['mace5311_spi_health'=>rawurlencode('MACE Cloud connecté et authentifié : '.($result['version']??'OK').' ; navigateur '.($result['browser']??'—').' ; activation automatique '.(!empty($result['automatic_registration'])?'oui':'non').' ; extraction '.(!empty($capabilities['capabilities']['extraction'])?'prête':'indisponible'))]);
    }
    private function guard(string $nonce): void { if(!current_user_can('manage_woocommerce')) wp_die('Accès refusé'); check_admin_referer($nonce); }
    private function redirect(array $args): void { wp_safe_redirect(add_query_arg($args,admin_url('admin.php?page='.$this->admin_slug()))); exit; }
    private function history(bool $ok,string $url,string $message,int $product_id,string $method,$score): void { $history=get_option('mace5311_spi_history',[]); $history[]=['date'=>current_time('mysql'),'success'=>$ok,'url'=>$url,'message'=>$message,'product_id'=>$product_id,'method'=>$method,'score'=>$score]; if(count($history)>200)$history=array_slice($history,-200); update_option('mace5311_spi_history',$history,false); }
    public function notices(): void { $page=(string)($_GET['page']??''); if($page!==$this->admin_slug() && $page!=='mace-smart-importer-5311-h5q7')return; if(isset($_GET['mace5311_spi_success']))echo '<div class="notice notice-success"><p><strong>Import terminé.</strong> '.esc_html(rawurldecode(wp_unslash($_GET['mace5311_spi_message']??''))).' <a class="button button-primary" href="'.esc_url(get_edit_post_link((int)$_GET['mace5311_spi_success'])).'">Ouvrir le produit</a></p></div>'; if(isset($_GET['mace5311_spi_error']))echo '<div class="notice notice-error"><p><strong>Import bloqué :</strong> '.esc_html(rawurldecode(wp_unslash($_GET['mace5311_spi_error']))).'</p></div>'; if(isset($_GET['mace5311_spi_saved']))echo '<div class="notice notice-success"><p>Réglages enregistrés.</p></div>'; if(isset($_GET['mace5311_spi_health']))echo '<div class="notice notice-success"><p>'.esc_html(rawurldecode(wp_unslash($_GET['mace5311_spi_health']))).'</p></div>'; }
}
