<?php
define('ABSPATH', __DIR__ . '/');
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function wp_kses($html,$allowed){ return $html; }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$v) ?: (string)$v; }
function esc_html($v){ return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
require dirname(__DIR__) . '/includes/class-mace-spi-attribute-firewall.php';
$raw=[
 'Capacité de stockage'=>'256 Go','Taille de l’écran (pouces)'=>'6,9"','Couleur'=>'Argent','Système d’exploitation'=>'iOS 26',
 'Processeur'=>'A19 Pro','Type de carte SIM'=>'Double SIM (nano-SIM et eSIM)','EAN'=>'0195950638745',
 'Durée minimum d’engagement'=>'24 mois','Durée maximum d’engagement'=>'33 mois','Montant total dû dont intérêts'=>'1 651,32 € 272,32 €',
 'hasEnergyEfficiencyCategory'=>'http://schema.org/EUEnergyEfficiencyCategoryA','energyEfficiencyScaleMin'=>'http://schema.org/EUEnergyEfficiencyCategoryA','energyEfficiencyScaleMax'=>'http://schema.org/EUEnergyEfficiencyCategoryG',
 'environment'=>'production','deviceType'=>'desktop-web','siteID'=>'fnaccom','marketID'=>'fr','statusCode'=>'200','statusText'=>'OK','entityID'=>'1-21960743','entityName'=>'Apple iPhone 17 Pro Max',
 'catalog'=>'newref','nature'=>'physic','salesCategory'=>'1','userRating'=>'5','labRating'=>'5','offerID'=>'00000000-0000-0000-0000-000000000000',
 'Réf. ManoMano'=>'11432808','MMID'=>'123456','Vous êtes ici :'=>'Accueil / Jardin / Robot tondeuse','Accueil/Jardin piscine/Entretien du gazon/Tondeuse à gazon/Robot tondeuse/Tondeuse robot GARDENA Sileno life 750 Bluetooth 15101-26'=>'breadcrumb',
 'sellerType'=>'fnac','sellerName'=>'FNAC.COM','sellerID'=>'00000000-0000-0000-0000-000000000000','sellerLocation'=>'Other','condition'=>'new','availability'=>'En Stock','availabilityType'=>'in-stock','availabilityID'=>'199',
 'offerURL'=>'https://www.fnac.com/FNAC-COM/sref00000000-0000-0000-0000-000000000000','fulfillment'=>'FNAC.COM','basePrice'=>'1229.94','basePriceWithTax'=>'1479','currency'=>'EUR','taxRate'=>'0.16666545536473512','shippingMethod'=>'Standard','shippingMethodID'=>'1','priceWithTax'=>'1379','authState'=>'unauthenticated'
];
$clean=MACE5311_SPI_Attribute_Firewall::sanitize_map($raw);
foreach(['Capacité de stockage','Taille de l’écran (pouces)','Couleur','Système d’exploitation','Processeur','Type de carte SIM','EAN','Classe énergétique'] as $good){if(!array_key_exists($good,$clean)){fwrite(STDERR,"missing good: $good\n");exit(1);}}
foreach(['siteID','marketID','statusCode','sellerName','offerURL','basePrice','taxRate','authState','Durée minimum d’engagement','Montant total dû dont intérêts','Réf. ManoMano','MMID','Vous êtes ici :','Accueil/Jardin piscine/Entretien du gazon/Tondeuse à gazon/Robot tondeuse/Tondeuse robot GARDENA Sileno life 750 Bluetooth 15101-26'] as $bad){if(array_key_exists($bad,$clean)){fwrite(STDERR,"noise survived: $bad\n");exit(1);}}
foreach($clean as $k=>$v){if(preg_match('~https?://|www\\.|fnac\\.com~i',$k.' '.$v)){fwrite(STDERR,"URL/source survived: $k=$v\n");exit(1);}}
if(($clean['Classe énergétique']??'')!=='A'){fwrite(STDERR,"energy class not derived\n");exit(1);}
$html='<section class="mace-product-specifications"><h3>Caractéristiques</h3><table><tbody>';
foreach($raw as $k=>$v)$html.='<tr><th>'.htmlspecialchars($k).'</th><td>'.htmlspecialchars($v).'</td></tr>';
$html.='</tbody></table></section>';
$out=MACE5311_SPI_Attribute_Firewall::sanitize_html($html);
foreach(['siteID','offerURL','https://','FNAC.COM','basePrice','authState','Durée minimum'] as $bad){if(stripos($out,$bad)!==false){fwrite(STDERR,"html noise survived: $bad\n");exit(1);}}
foreach(['Capacité de stockage','256 Go','Système d’exploitation','iOS 26','Classe énergétique','A'] as $good){if(stripos($out,$good)===false){fwrite(STDERR,"html good lost: $good\n");exit(1);}}
echo "Attribute Intelligence Firewall checks passed.\n";
