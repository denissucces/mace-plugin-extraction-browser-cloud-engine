<?php
define('ABSPATH', __DIR__ . '/');
function sanitize_text_field($v){ return trim(strip_tags((string)$v)); }
require_once __DIR__ . '/../includes/class-mace-spi-content-firewall.php';
require_once __DIR__ . '/../includes/class-mace-spi-attribute-firewall.php';
require_once __DIR__ . '/../includes/class-mace-spi-materialization-firewall.php';

$contract = [
    'version'=>'h5q7-universal-materialization-contract-v1',
    'fields'=>[
        'price'=>['state'=>'ALLOW','reason'=>'winner'],
        'energy_class'=>['state'=>'ALLOW','reason'=>'canonical_display'],
        'energy_class_cooling'=>['state'=>'QUARANTINED','reason'=>'unresolved_from_unlabelled_composite'],
        'energy_class_heating'=>['state'=>'QUARANTINED','reason'=>'unresolved_from_unlabelled_composite'],
        'dimensions'=>['state'=>'QUARANTINED','reason'=>'component_scope_only'],
        'length'=>['state'=>'QUARANTINED'],
        'width'=>['state'=>'QUARANTINED'],
        'height'=>['state'=>'QUARANTINED'],
        'weight'=>['state'=>'QUARANTINED','reason'=>'component_weight_only'],
        'media'=>['state'=>'ALLOW'],
    ],
];
$product = [
    'materialization_contract'=>$contract,
    'regular_price'=>'499',
    'sale_price'=>'',
    'energy_class'=>'A++ / A',
    'attributes'=>[
        'Classe énergétique'=>'A++ / A',
        'Classe énergétique (refroidissement)'=>'A',
        'Classe énergétique (chauffage)'=>'A',
        'Dimensions unité extérieure'=>'80,5 x 28,5 x 65 cm',
        'Marque'=>'SAMSUNG',
    ],
    'specifications'=>[
        ['label'=>'Classe énergétique refroidissement','value'=>'A'],
        ['label'=>'Classe énergétique chauffage','value'=>'A'],
        ['label'=>'Dimensions unité extérieure','value'=>'80,5 x 28,5 x 65 cm'],
        ['label'=>'Puissance frigorifique','value'=>'3,5 kW'],
    ],
    'specifications_html'=>'<table><tr><th>Classe énergétique refroidissement</th><td>A</td></tr><tr><th>Dimensions unité extérieure</th><td>80,5 x 28,5 x 65 cm</td></tr></table>',
    'weight'=>'31.3','length'=>'80.5','width'=>'80.5','height'=>'28.5',
    'images'=>['https://example.test/a.jpg'],
];
$out=MACE5311_SPI_Materialization_Firewall::apply($product);
if(($out['regular_price']??'')!=='499') {fwrite(STDERR,"price regressed\n");exit(1);} 
if(($out['attributes']['Classe énergétique']??'')!=='A++ / A') {fwrite(STDERR,"generic energy lost\n");exit(2);} 
if(isset($out['attributes']['Classe énergétique (refroidissement)']) || isset($out['attributes']['Classe énergétique (chauffage)'])) {fwrite(STDERR,"mode attrs survived quarantine\n");exit(3);} 
if(($out['attributes']['Dimensions unité extérieure']??'')==='') {fwrite(STDERR,"component evidence lost\n");exit(4);} 
if(($out['weight']??'')!=='' || ($out['length']??'')!=='' || ($out['width']??'')!=='' || ($out['height']??'')!=='') {fwrite(STDERR,"global measurement quarantine failed\n");exit(5);} 
if(stripos((string)$out['specifications_html'],'refroidissement')!==false) {fwrite(STDERR,"quarantined html row survived\n");exit(6);} 
if(stripos((string)$out['specifications_html'],'Dimensions unité extérieure')===false) {fwrite(STDERR,"safe html row removed\n");exit(7);} 
if(count($out['specifications']??[])!==2) {fwrite(STDERR,"spec filtering mismatch\n");exit(8);} 

$allow = [
    'version'=>'h5q7-universal-materialization-contract-v1',
    'fields'=>[
        'energy_class_cooling'=>['state'=>'ALLOW','evidence'=>['value'=>'A++']],
        'energy_class_heating'=>['state'=>'ALLOW','evidence'=>['value'=>'A']],
        'dimensions'=>['state'=>'ALLOW'], 'weight'=>['state'=>'ALLOW'],
    ],
];
$out2=MACE5311_SPI_Materialization_Firewall::apply([
    'materialization_contract'=>$allow,
    'attributes'=>['Classe énergétique (refroidissement)'=>'A','Classe énergétique (chauffage)'=>'A++'],
    'specifications'=>[['label'=>'Classe énergétique refroidissement','value'=>'A'],['label'=>'Classe énergétique chauffage','value'=>'A++']],
    'weight'=>'31.3','length'=>'80.5','width'=>'28.5','height'=>'65',
]);
if(($out2['attributes']['Classe énergétique (refroidissement)']??'')!=='A++' || ($out2['attributes']['Classe énergétique (chauffage)']??'')!=='A') {fwrite(STDERR,"allowed role sync failed\n");exit(9);} 
if(($out2['weight']??'')!=='31.3' || ($out2['length']??'')!=='80.5') {fwrite(STDERR,"allowed measurements changed\n");exit(10);} 

$legacy=MACE5311_SPI_Materialization_Firewall::apply(['attributes'=>['Classe énergétique (refroidissement)'=>'A'],'length'=>'80.5']);
if(($legacy['attributes']['Classe énergétique (refroidissement)']??'')!=='A' || ($legacy['length']??'')!=='80.5' || ($legacy['materialization_firewall_report']['policy']??'')!=='legacy_non_regression_passthrough') {fwrite(STDERR,"legacy passthrough regression\n");exit(11);} 

echo "PASS universal materialization firewall 5.3.65\n";
