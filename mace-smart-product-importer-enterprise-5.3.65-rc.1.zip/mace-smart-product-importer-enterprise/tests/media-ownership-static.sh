#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
grep -q "fnac-product-media-ownership" "$ROOT/includes/class-mace-spi-importer.php"
grep -q "ownership_verified" "$ROOT/includes/class-mace-spi-importer.php"
grep -q "seuls les octets réellement identiques" "$ROOT/includes/class-mace-spi-importer.php"
echo "media ownership plugin guard: ok"
