#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NEW='https://mace-cloud-extraction-engine-h5q7.onrender.com'
OLD='https://mace-cloud-extraction-engine.onrender.com'
grep -q "$NEW" "$ROOT/mace-smart-product-importer-enterprise.php"
grep -q "$NEW" "$ROOT/includes/class-mace-spi-admin.php"
if grep -RFn "$OLD" "$ROOT" --exclude='cloud-endpoint-check.sh'; then
  echo 'Legacy full Cloud URL still present in runtime files.' >&2
  exit 1
fi
grep -q 'mace5311_spi_maybe_migrate_cloud_endpoint' "$ROOT/mace-smart-product-importer-enterprise.php"
grep -q "mace-cloud-auth" "$ROOT/includes/class-mace-spi-client.php"
echo 'Cloud endpoint migration checks: OK'
