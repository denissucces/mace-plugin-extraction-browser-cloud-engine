<?php
if(!defined('ABSPATH')) define('ABSPATH',__DIR__.'/');
function mb_strtolower($s){return strtolower((string)$s);} function mb_strlen($s){return strlen((string)$s);} function mb_strpos($h,$n){return strpos((string)$h,(string)$n);} function mb_substr($s,$a,$b=null){return $b===null?substr((string)$s,$a):substr((string)$s,$a,$b);} function wp_strip_all_tags($s){return strip_tags((string)$s);} function sanitize_text_field($s){return trim(strip_tags((string)$s));}
function wp_trim_words($text,$num_words=55,$more=null){$words=preg_split('/\s+/',trim((string)$text));return implode(' ',array_slice($words,0,$num_words));} function get_locale(){return 'fr_FR';} function wp_json_encode($v,$f=0){return json_encode($v,$f);} function wp_kses_allowed_html($context='post'){return ['p'=>[],'div'=>[],'table'=>[],'tr'=>[],'th'=>[],'td'=>[],'ul'=>[],'li'=>[],'strong'=>[]];} function wp_kses($s,$allowed=[]){return $s;} function wc_format_decimal($v){$v=str_replace([' ', ','],['','.'],(string)$v);return is_numeric($v)?rtrim(rtrim(number_format((float)$v,4,'.',''),'0'),'.'):'';} function wp_kses_post($s){return $s;} function esc_html($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');} function get_option($k,$d=[]){ if($k==='woocommerce_weight_unit')return 'kg'; if($k==='woocommerce_dimension_unit')return 'cm'; if($k==='mace5311_spi_settings')return ['short_description_mode'=>'automatic','short_description_format'=>'professional']; return $d;} function remove_accents($s){return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s)?:$s;} function __($s,$d=null){return $s;} function wpautop($s,$br=true){return $s;} function sanitize_key($s){return strtolower(preg_replace('/[^a-z0-9_\-]/i','',(string)$s));} function esc_url_raw($s){return $s;} function is_wp_error($v){return false;}
class WP_Error { public function __construct(...$x){} }
require_once dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-materialization-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor();
$raw=[
 'name'=>'Climatiseur Samsung AR35 3,5 kW 12000BTU A++/A R32',
 'regular_price'=>'499','price_source'=>'product-offer',
 'description'=>'Climatiseur Samsung AR35. Dimensions unité extérieure : 80,5 x 28,5 x 65 cm. Poids unité extérieure : 31,3 kg.',
 'attributes'=>[
   'Classe énergétique'=>'A++ / A',
   'Classe énergétique (refroidissement)'=>'A',
   'Classe énergétique (chauffage)'=>'A',
   'Dimensions unité extérieure'=>'80,5 x 28,5 x 65 cm',
   'Poids unité extérieure'=>'31,3 kg',
   'Marque'=>'SAMSUNG',
 ],
 'specifications'=>[
   ['label'=>'Classe énergétique refroidissement','value'=>'A'],
   ['label'=>'Classe énergétique chauffage','value'=>'A'],
   ['label'=>'Dimensions unité extérieure','value'=>'80,5 x 28,5 x 65 cm'],
 ],
 'length'=>'80.5','width'=>'28.5','height'=>'65','weight'=>'31.3',
 'materialization_contract'=>[
   'version'=>'h5q7-universal-materialization-contract-v1',
   'fields'=>[
    'price'=>['state'=>'ALLOW'],
    'energy_class'=>['state'=>'ALLOW','evidence'=>'A++ / A'],
    'energy_class_cooling'=>['state'=>'QUARANTINED','reason'=>'unresolved_from_unlabelled_composite'],
    'energy_class_heating'=>['state'=>'QUARANTINED','reason'=>'unresolved_from_unlabelled_composite'],
    'dimensions'=>['state'=>'QUARANTINED'], 'length'=>['state'=>'QUARANTINED'], 'width'=>['state'=>'QUARANTINED'], 'height'=>['state'=>'QUARANTINED'],
    'weight'=>['state'=>'QUARANTINED'], 'media'=>['state'=>'UNRESOLVED']
   ]
 ]
];
$out=$e->extract(['product'=>$raw],'https://www.manomano.fr/p/climatiseur-samsung-ar35-35-kw-12000btu-a-a-r32-40220365');
if(($out['regular_price']??'')!=='499'){fwrite(STDERR,"499 price regressed\n");exit(1);} 
if(($out['energy_class']??'')!=='A++ / A'){fwrite(STDERR,'canonical display class changed: '.($out['energy_class']??'')."\n");exit(2);} 
foreach((array)($out['attributes']??[]) as $label=>$value){$role=MACE5311_SPI_Attribute_Firewall::energy_semantic_role((string)$label);if(in_array($role,['cooling_class','heating_class'],true)){fwrite(STDERR,"mode attribute survived: $label=$value\n");exit(3);}}
if(($out['length']??'')!==''||($out['width']??'')!==''||($out['height']??'')!==''||($out['weight']??'')!==''){fwrite(STDERR,"quarantined global measurements survived\n");exit(4);} 
if(($out['attributes']['Dimensions unité extérieure']??'')===''){fwrite(STDERR,"component dimension evidence lost\n");exit(5);} 
if(($out['materialization_firewall_report']['downstream_quarantine_enforced']??false)!==true){fwrite(STDERR,"firewall report missing\n");exit(6);} 
echo "PASS AR35 Cloud contract integration 5.3.65\n";
