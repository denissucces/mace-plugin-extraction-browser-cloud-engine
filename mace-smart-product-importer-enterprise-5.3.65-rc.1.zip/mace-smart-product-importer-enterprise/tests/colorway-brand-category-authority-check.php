<?php
function sanitize_text_field($s){return trim(strip_tags((string)$s));}
function wp_strip_all_tags($s){return strip_tags((string)$s);}
function remove_accents($s){$r=iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$s);return $r===false?$s:$r;}
function esc_url_raw($s){return $s;}
function wp_kses_post($s){return $s;}
require_once __DIR__.'/../includes/class-mace-spi-extractor.php';
$e=(new ReflectionClass('MACE5311_SPI_Extractor'))->newInstanceWithoutConstructor();
$brand=new ReflectionMethod($e,'resolve_brand_authority'); $brand->setAccessible(true);
$desc='<ul><li><strong>Les Paramètres du Produit:</strong></li><li>Marque: COLORWAY</li><li>Modèle: BK29G</li><li>Type de vélo: Vélo électrique; VAE; VTT; E-Bike</li></ul>';
$b=$brand->invoke($e,'VAE','Vélo électrique VAE - COLORWAY - Noir - 20 x 4.0 Gros Pneus',$desc,[]);
if($b!=='COLORWAY'){fwrite(STDERR,"brand authority failed: $b\n");exit(1);}
$cat=new ReflectionMethod($e,'recover_categories_from_product_content'); $cat->setAccessible(true);
$c=$cat->invoke($e,'Vélo électrique VAE - COLORWAY - Noir - 20 x 4.0 Gros Pneus',$desc,[]);
$expected=['Sports et loisirs','Cyclisme','Vélos électriques'];
if($c!==$expected){fwrite(STDERR,'category path failed: '.json_encode($c,JSON_UNESCAPED_UNICODE)."\n");exit(1);}
echo "COLORWAY brand + category authority: OK\n";
