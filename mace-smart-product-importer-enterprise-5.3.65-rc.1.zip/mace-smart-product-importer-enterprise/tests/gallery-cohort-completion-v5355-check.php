<?php
define('ABSPATH', __DIR__.'/');
function esc_url_raw($v){ return trim((string)$v); }
function wp_parse_url($url,$component=-1){ return parse_url($url,$component); }
if (!function_exists('mb_strtolower')) { function mb_strtolower($v,$enc=null){ return strtolower((string)$v); } }
if (!function_exists('mb_strlen')) { function mb_strlen($v,$enc=null){ return strlen((string)$v); } }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$v) ?: $v; }
function sanitize_text_field($v){ return trim(strip_tags((string)$v)); }
function sanitize_key($v){ return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v)); }
class MACE5311_SPI_Content_Firewall {}
class MACE5311_SPI_Attribute_Firewall {}
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';

$desc='<div class="product-description"><p>';
for($i=1;$i<=6;$i++) $desc.='<img src="https://cdn.manomano.com/external-resources/comfee-view-'.$i.'" alt="Image">';
$desc.='</p></div>';
$initial=[
 'https://cdn.manomano.com/external-resources/comfee-view-1',
 'https://cdn.manomano.com/external-resources/comfee-view-2',
 'https://cdn.manomano.com/external-resources/comfee-view-3',
];
$report=['accepted'=>array_map(fn($u)=>['url'=>$u,'ownership_verified'=>true,'source'=>'official-gallery-dom'],$initial)];
$ref=new ReflectionClass('MACE5311_SPI_Extractor');
$obj=$ref->newInstanceWithoutConstructor();
$m=$ref->getMethod('recover_inline_product_media'); $m->setAccessible(true);
$out=$m->invoke($obj,$desc,'Comfee CDWTT602ESD',$initial,$report);
if(count($out['images'])!==6){fwrite(STDERR,'Expected 6, got '.count($out['images'])."\n");exit(1);} 
if(($out['report']['cohort_completion']['initial_count']??0)!==3) exit(2);
if(($out['report']['cohort_completion']['final_count']??0)!==6) exit(3);
if(($out['report']['cohort_completion']['recovered_count']??0)!==3) exit(4);
if(count($out['report']['accepted']??[])!==6) exit(5);

// Foreign host in description must not join an already validated cohort solely by presence.
$desc2=$desc.'<img src="https://ads.example.com/banner.jpg">';
$out2=$m->invoke($obj,$desc2,'Comfee CDWTT602ESD',$initial,$report);
if(count($out2['images'])!==6){fwrite(STDERR,'Foreign host leaked into cohort\n');exit(6);} 

echo "PASS gallery cohort 3+3 => 6, foreign host rejected\n";
