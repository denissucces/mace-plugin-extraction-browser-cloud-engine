#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
E="$ROOT/includes/class-mace-spi-extractor.php"
I="$ROOT/includes/class-mace-spi-importer.php"
M="$ROOT/mace-smart-product-importer-enterprise.php"
grep -q "cloud_materialization_quarantine" "$E"
grep -q "MACE5311_SPI_Materialization_Firewall::apply(\$this->normalize" "$E"
grep -q "Re-apply the universal contract AFTER local shipping/measurement recovery" "$I"
grep -q "set_' . \$dimension}('')" "$I"
grep -q "_mace5311_spi_specifications_json" "$I"
grep -q "class-mace-spi-materialization-firewall.php" "$M"
echo "PASS materialization firewall static wiring 5.3.65"
