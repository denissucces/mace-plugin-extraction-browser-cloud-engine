<?php
if(!defined('ABSPATH')) define('ABSPATH',__DIR__.'/');
function mb_strtolower($s){return strtolower((string)$s);} function mb_strlen($s){return strlen((string)$s);} function mb_strpos($h,$n){return strpos((string)$h,(string)$n);} function mb_substr($s,$a,$b=null){return $b===null?substr((string)$s,$a):substr((string)$s,$a,$b);} function wp_strip_all_tags($s){return strip_tags((string)$s);} function sanitize_text_field($s){return trim(strip_tags((string)$s));}
function wp_json_encode($v,$f=0){return json_encode($v,$f);} function wc_format_decimal($v){$v=str_replace([' ', ','],['','.'],(string)$v);return is_numeric($v)?rtrim(rtrim(number_format((float)$v,4,'.',''),'0'),'.'):'';} function wp_kses_post($s){return $s;} function esc_html($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');} function get_option($k,$d=[]){return $d;} function remove_accents($s){return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s)?:$s;} function __($s,$d=null){return $s;} function wpautop($s,$br=true){return $s;} function sanitize_key($s){return strtolower(preg_replace('/[^a-z0-9_\-]/i','',(string)$s));} function esc_url_raw($s){return $s;} function is_wp_error($v){return false;}
class WP_Error { public function __construct(...$x){} }
require_once dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor();
$jsonld='<script type="application/ld+json">'.json_encode(['@type'=>'Product','name'=>'Samsung AR35','offers'=>['@type'=>'Offer','price'=>'499','priceCurrency'=>'EUR']]).'</script>';
$out=$e->extract(['product'=>['name'=>'Samsung AR35','regular_price'=>'92.11','price_source'=>'primary-buybox-cta-text'],'fallback_html'=>$jsonld],'https://www.manomano.fr/p/climatiseur-samsung-ar35');
if(($out['regular_price']??'')!=='499'){fwrite(STDERR,'ledger failed to replace weak Cloud price: '.($out['regular_price']??'')."\n");exit(1);} 
if(($out['price_authority_report']['materialization']??'')!=='allowed'){fwrite(STDERR,"allowed report missing\n");exit(2);} 
$out2=$e->extract(['product'=>['name'=>'Samsung AR35','regular_price'=>'92.11','price_source'=>'primary-buybox-cta-text']],'https://www.manomano.fr/p/climatiseur-samsung-ar35');
if(($out2['regular_price']??'')!==''){fwrite(STDERR,'weak Cloud price survived without strong candidate: '.($out2['regular_price']??'')."\n");exit(3);} 
if(($out2['price_authority_report']['materialization']??'')!=='blocked_untrusted'){fwrite(STDERR,"blocked report missing\n");exit(4);} 
echo "PASS price candidate ledger 5.3.64\n";
