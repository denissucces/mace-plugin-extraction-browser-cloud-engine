<?php
$root=dirname(__DIR__);$main=file_get_contents($root.'/mace-smart-product-importer-enterprise.php');
foreach(['Plugin Name: MACE Smart Product Importer Enterprise 5.3.63 RC1','Version: 5.3.63-rc.1',"MACE5311_SPI_VERSION', '5.3.63-rc.1'"] as $needle){if(strpos($main,$needle)===false){fwrite(STDERR,"missing $needle\n");exit(1);}}
echo "PASS version identity 5.3.63 RC1\n";
