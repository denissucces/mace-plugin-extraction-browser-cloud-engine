#!/usr/bin/env bash
set -euo pipefail
FILE="$(dirname "$0")/../includes/class-mace-spi-importer.php"
grep -q "private function resolve_sku" "$FILE"
grep -q "private function build_short_sku" "$FILE"
grep -q "return 'MC'" "$FILE"
grep -q "_mace5311_spi_sku_origin" "$FILE"
echo "SKU engine static checks: OK"
