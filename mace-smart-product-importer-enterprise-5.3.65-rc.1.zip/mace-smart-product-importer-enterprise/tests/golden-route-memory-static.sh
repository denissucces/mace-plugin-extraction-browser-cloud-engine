#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
grep -q "mace-golden-route-memory-v1" "$ROOT/includes/class-mace-spi-importer.php"
grep -q "adaptive-complementary-recovery-v1" "$ROOT/includes/class-mace-spi-client.php"
grep -q "build_golden_route_registry" "$ROOT/includes/class-mace-spi-extractor.php"
grep -q "'weight','length','width','height'" "$ROOT/includes/class-mace-spi-client.php"
echo "Golden Route Memory static checks: OK"
