<?php
$root=dirname(__DIR__);$main=file_get_contents($root.'/mace-smart-product-importer-enterprise.php');$readme=file_get_contents($root.'/readme.txt');
$expected='5.3.62-rc.1';$public='MACE Smart Product Importer Enterprise 5.3.62 RC1';
if(strpos($main,'Plugin Name: '.$public)===false||strpos($main,'Version: '.$expected)===false||strpos($main,"MACE5311_SPI_VERSION', '".$expected."'")===false||strpos($readme,'Stable tag: '.$expected)===false){fwrite(STDERR,"version identity mismatch
");exit(1);}echo "Version Identity Gate 5.3.62 checks passed.
";
