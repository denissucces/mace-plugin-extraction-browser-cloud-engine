#!/bin/sh
set -eu
F="$(dirname "$0")/../includes/class-mace-spi-importer.php"
grep -q "recover_shipping_measurements_before_save" "$F"
grep -q "dimensions?(?:\\\\s+du" "$F" || grep -q "taille\\\\s+du" "$F"
grep -q "set_' . \$dimension" "$F"
echo "shipping-materialization-guard-static: OK"
