<?php
define('ABSPATH', __DIR__ . '/');
function get_option($k,$d=null){ return $k==='woocommerce_weight_unit'?'kg':($k==='woocommerce_dimension_unit'?'cm':$d); }
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function mb_strtolower($v){ return strtolower($v); }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$v) ?: (string)$v; }
function wc_format_decimal($v,$dp=false){ $n=(float)$v; return $dp===false ? rtrim(rtrim(number_format($n,6,'.',''),'0'),'.') : rtrim(rtrim(number_format($n,(int)$dp,'.',''),'0'),'.'); }
function wc_get_weight($v,$to,$from=''){
  $kg = $from==='g' ? $v/1000 : ($from==='lbs' ? $v*0.45359237 : $v);
  return $to==='g' ? $kg*1000 : ($to==='lbs' ? $kg/0.45359237 : $kg);
}
function wc_get_dimension($v,$to,$from=''){
  $cm = $from==='mm' ? $v/10 : ($from==='m' ? $v*100 : ($from==='in' ? $v*2.54 : $v));
  return $to==='mm' ? $cm*10 : ($to==='m' ? $cm/100 : ($to==='in' ? $cm/2.54 : $cm));
}
require dirname(__DIR__) . '/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor();
$r=new ReflectionMethod($e,'recover_structured_measurements'); $r->setAccessible(true);
$out=$r->invoke($e, [], [], '<p>poids: 18.5 kilogrammes</p><p>dimensions du produit (l x l x h): 28 x 52 x 68 cm; 18.5 kilogrammes</p>');
$expected=['weight'=>'18.5','length'=>'28','width'=>'52','height'=>'68'];
foreach($expected as $k=>$v){ if((string)$out[$k]!==$v){fwrite(STDERR,"$k attendu $v obtenu {$out[$k]}\n"); exit(1);} }
$out2=$r->invoke($e, ['specifications_html'=>'<table><tr><th>Dimensions du produit (L x l x H)</th><td>28 x 52 x 68 cm</td></tr></table>'], [], '<p>Description sans mesures.</p>');
foreach(['length'=>'28','width'=>'52','height'=>'68'] as $k=>$v){ if((string)$out2[$k]!==$v){fwrite(STDERR,"specifications_html $k attendu $v obtenu {$out2[$k]}\n"); exit(1);} }
$out3=$r->invoke($e, [], ['Longueur'=>'28 cm','Largeur'=>'52 cm','Hauteur'=>'68 cm'], '<p>Description sans mesures.</p>');
foreach(['length'=>'28','width'=>'52','height'=>'68'] as $k=>$v){ if((string)$out3[$k]!==$v){fwrite(STDERR,"dimension individuelle $k attendu $v obtenu {$out3[$k]}\n"); exit(1);} }
echo "Structured measurements + Shipping Dimensions Authority: OK\n";
