<?php
$src=file_get_contents(__DIR__.'/../includes/class-mace-spi-extractor.php');
$need=[
 'Visual Product Evidence Authority v1',
 'visual_product_evidence_authority',
 'visual_ocr_price_candidates',
 'visual_ocr_taxonomy_hints',
 'ocr-corroboration-only',
 'return $bridge;',
];
foreach($need as $n){if(strpos($src,$n)===false){fwrite(STDERR,"missing: $n\n");exit(1);}}
echo "visual product evidence authority static check: OK\n";
