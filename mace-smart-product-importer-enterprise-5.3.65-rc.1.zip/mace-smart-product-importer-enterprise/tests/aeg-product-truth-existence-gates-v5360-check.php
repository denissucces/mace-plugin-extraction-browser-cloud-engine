<?php
if (!defined('ABSPATH')) define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($s){return strip_tags($s);} function sanitize_text_field($s){return trim(strip_tags($s));}
function wp_json_encode($v,$f=0){return json_encode($v,$f);} function sanitize_key($s){return strtolower(preg_replace('/[^a-z0-9_\-]/','',str_replace(' ','_',trim($s))));}
function get_option($k,$d=[]){return $d;} function esc_url_raw($s){return $s;} function wp_kses_post($s){return $s;} function wc_format_decimal($v){return (string)(float)str_replace(',','.',$v);}
require_once dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$rc=new ReflectionClass('MACE5311_SPI_Extractor'); $o=$rc->newInstanceWithoutConstructor();
// Price: 2.3 from weak CTA without currency/offer proof must fail closed.
$m=$rc->getMethod('resolve_regular_price_authority');$m->setAccessible(true);
$p=$m->invoke($o,['regular_price'=>'2.3','source_url'=>'https://www.manomano.fr/p/aeg-hkb64420nb-noir-encastrable-56-cm-gaz-4-bruleurs','price_report'=>['source'=>'primary-buybox-cta-text']]);
if($p!==''){fwrite(STDERR,"tiny weak price not rejected: $p\n");exit(1);}
// Energy: A cannot be inferred when A/D are merely scale bounds and no direct class proof exists.
$m=$rc->getMethod('resolve_energy_truth_authority');$m->setAccessible(true);
$raw=['specifications'=>[['label'=>'Classe efficacité énergétique max','value'=>'A'],['label'=>'Classe efficacité énergétique min','value'=>'D'],['label'=>'Classe énergétique','value'=>'A']]];
$r=$m->invoke($o,$raw,['Borne maximale de l’échelle énergétique'=>'A','Borne minimale de l’échelle énergétique'=>'D','Classe énergétique'=>'A'],'AEG HKB64420NB');
if(($r[0]??'')!==''){fwrite(STDERR,"scale-bound alias synthesized class: ".($r[0]??'')."\n");exit(1);}
// Source title H1/certificate outranks foreign structured name.
$m=$rc->getMethod('resolve_source_title_authority');$m->setAccessible(true);
$title=$m->invoke($o,['source_title_certificate'=>['visible_h1'=>'Plaque de cuisson gaz AEG HKB64420NB encastrable 56 cm 4 brûleurs','locked'=>true]],'https://www.manomano.fr/p/aeg-hkb64420nb-noir-encastrable-56-cm-gaz-4-bruleurs','HKB64420NB varná doska plyn. AEG');
if(strpos($title,'Plaque de cuisson gaz AEG HKB64420NB')!==0){fwrite(STDERR,"source title authority failed: $title\n");exit(1);}
echo "PASS AEG product truth existence gates 5.3.60\n";
