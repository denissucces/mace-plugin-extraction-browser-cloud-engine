<?php
define('ABSPATH', __DIR__ . '/');

if (!function_exists('mb_strlen')) { function mb_strlen($s,$enc=null){ return strlen((string)$s); } }
if (!function_exists('mb_strtolower')) { function mb_strtolower($s,$enc=null){ return strtolower((string)$s); } }
if (!function_exists('mb_strtoupper')) { function mb_strtoupper($s,$enc=null){ return strtoupper((string)$s); } }
if (!function_exists('mb_substr')) { function mb_substr($s,$start,$len=null,$enc=null){ return $len===null ? substr((string)$s,$start) : substr((string)$s,$start,$len); } }

function wp_strip_all_tags($text, $remove_breaks = false) {
    $text = strip_tags((string)$text);
    return $remove_breaks ? preg_replace('/[\r\n\t ]+/', ' ', $text) : $text;
}
function get_option($key, $default = []) { return $default; }
function esc_html($text) { return htmlspecialchars((string)$text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function wp_kses_allowed_html($context='post') { return []; }
function wp_kses($html, $allowed=[]) { return (string)$html; }
function wp_kses_post($html) { return (string)$html; }
function wpautop($text, $br=true) {
    if (preg_match('/<(?:p|h[1-6]|ul|ol|table|div)\b/i', (string)$text)) return (string)$text;
    $parts = array_values(array_filter(array_map('trim', preg_split('/\n{2,}/', (string)$text))));
    return implode("\n", array_map(static fn($x) => '<p>'.$x.'</p>', $parts));
}
function wp_trim_words($text, $num_words=55, $more=null) {
    $words = preg_split('/\s+/u', trim((string)$text), -1, PREG_SPLIT_NO_EMPTY);
    if (count($words) <= $num_words) return implode(' ', $words);
    return implode(' ', array_slice($words, 0, $num_words)) . (string)$more;
}
function remove_accents($text) {
    $map=['é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','à'=>'a','â'=>'a','ä'=>'a','î'=>'i','ï'=>'i','ô'=>'o','ö'=>'o','ù'=>'u','û'=>'u','ü'=>'u','ç'=>'c',
         'É'=>'E','È'=>'E','Ê'=>'E','À'=>'A','Â'=>'A','Î'=>'I','Ô'=>'O','Ù'=>'U','Ç'=>'C'];
    return strtr((string)$text,$map);
}

require_once dirname(__DIR__) . '/includes/class-mace-spi-extractor.php';
$extractor = new MACE5311_SPI_Extractor();

$formatDescription = new ReflectionMethod($extractor, 'format_description');
$formatDescription->setAccessible(true);
$formatShort = new ReflectionMethod($extractor, 'format_short_description_for_woocommerce');
$formatShort->setAccessible(true);

$flat = "worx landroid m700 plus wr167e jusqu'à 700m². autonomes, intelligentes, configurables selon vos besoins. nouveau: plus silencieuse avec seulement 67 db. caractéristiques techniques : type de batterie : lithium-ion. tension de la batterie : 20 v. capacité de la batterie : 4000mah. fonctionnalité : intelligente. auto-programmateur cognitif noesis précise. spécifications : poids : 18.5 kilogrammes. dimensions du produit : 28 x 52 x 68 cm.";
$long = $formatDescription->invoke($extractor, $flat, false);

$checks = [
    'description has paragraphs' => substr_count($long, '<p>') >= 5,
    'technical heading restored' => stripos($long, '<h3>Caractéristiques techniques</h3>') !== false,
    'function heading restored' => stripos($long, '<h3>Fonctionnalité</h3>') !== false,
    'spec heading restored' => stripos($long, '<h3>Spécifications</h3>') !== false,
    'dimensions preserved' => strpos($long, '28 x 52 x 68 cm') !== false,
];

$structured = '<h2>Description</h2><p>Premier paragraphe.</p><table><tr><th>Surface</th><td>700 m²</td></tr></table>';
$structuredOut = $formatDescription->invoke($extractor, $structured, false);
$checks['source table preserved'] = strpos($structuredOut, '<table>') !== false && strpos($structuredOut, '<th>Surface</th>') !== false;


$fnacDom = '<section class="description"><div>worx - tondeuse robot connectée sans fil.</div><div><strong>fonctionnalité:</strong></div><div><strong>intelligente:</strong> auto-programmateur cognitif noesis™</div><div><strong>précise:</strong> la fonction cut-to-edge réduit le besoin de taille manuelle</div><div><h3>spécifications:</h3></div><div><strong>poids:</strong> 18.5 kilogrammes</div><div><strong>marque:</strong> worx</div><div><strong>dimensions du produit (l x l x h):</strong> 28 x 52 x 68 cm; 18.5 kilogrammes</div></section>';
$fnacDomOut = $formatDescription->invoke($extractor, $fnacDom, false);
$checks['fnac div blocks preserved'] = strpos($fnacDomOut, '<section') !== false && substr_count($fnacDomOut, '<div>') >= 6;
$checks['fnac source ordering preserved'] = strpos($fnacDomOut, 'fonctionnalité') < strpos($fnacDomOut, 'spécifications') && strpos($fnacDomOut, 'spécifications') < strpos($fnacDomOut, 'dimensions du produit');
$checks['fnac source labels preserved'] = strpos($fnacDomOut, '<strong>poids:</strong>') !== false && strpos($fnacDomOut, '<strong>marque:</strong>') !== false;

$fnacExact = "<p>worx - tondeuse robot connectée sans fil landroid - wr167e - jusqu'à 700m².</p><p>nouveau: plus silencieuse avec seulement 67 db.</p><h2>fonctionnalité:</h2><ul><li><strong>intelligente:</strong> auto-programmateur cognitif noesis™</li><li><strong>précise:</strong> cut-to-edge</li></ul><h2>spécifications:</h2><ul><li><strong>poids:</strong> 18.5 kilogrammes</li><li><strong>dimensions du produit (l x l x h):</strong> 28 x 52 x 68 cm</li></ul>";
$fnacExactOut = $formatDescription->invoke($extractor, $fnacExact, false, 'source-rendered-semantic-html-v2');
$checks['source rendered fidelity keeps paragraphs'] = substr_count($fnacExactOut, '<p>') === 2;
$checks['source rendered fidelity keeps headings'] = substr_count($fnacExactOut, '<h2>') === 2;
$checks['source rendered fidelity keeps list items'] = substr_count($fnacExactOut, '<li>') === 4;
$checks['source rendered fidelity keeps source order'] = strpos($fnacExactOut, 'fonctionnalité') < strpos($fnacExactOut, 'spécifications') && strpos($fnacExactOut, 'spécifications') < strpos($fnacExactOut, 'dimensions du produit');

$short = $formatShort->invoke(
    $extractor,
    "Landroid M700 Plus WR167E se distingue par Surface de tonte 700 m².",
    "Landroid M700 Plus WR167E",
    [
        'Surface de tonte'=>'700 m²',
        'Tension'=>'20 V',
        'Niveau sonore'=>'67 dB',
        'Largeur de coupe'=>'180 mm',
        'Pente max.'=>'35 %',
        'EAN'=>'6943475869809'
    ],
    'professional'
);
$plainShort = trim(wp_strip_all_tags($short));
$shortWords = preg_split('/\s+/u', $plainShort, -1, PREG_SPLIT_NO_EMPTY);
$checks['short description is substantial'] = count($shortWords) >= 35;
$checks['short description has intro'] = strpos($short, 'mace-short-description__intro') !== false;
$checks['short description has highlights'] = substr_count($short, '<li>') >= 4;
$checks['short description excludes EAN bullet'] = strpos($short, '6943475869809') === false;
$checks['short description no ellipsis'] = strpos($short, '…') === false && strpos($short, '...') === false;

$failed = [];
foreach ($checks as $label=>$ok) {
    echo ($ok ? "PASS" : "FAIL") . " - $label\n";
    if (!$ok) $failed[]=$label;
}
if ($failed) {
    fwrite(STDERR, "Presentation regression checks failed: ".implode(', ', $failed)."\n");
    exit(1);
}
echo "presentation-regression-check: OK\n";
