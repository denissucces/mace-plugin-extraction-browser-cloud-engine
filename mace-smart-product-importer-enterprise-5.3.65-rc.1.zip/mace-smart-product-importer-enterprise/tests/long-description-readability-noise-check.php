<?php
define('ABSPATH', __DIR__ . '/');
class MACE5311_SPI_Client {}
class MACE5311_SPI_Extractor {}
class MACE5311_SPI_Quality {}
class MACE5311_SPI_Logger {}
if (!function_exists('mb_strlen')) { function mb_strlen($s,$enc=null){ return strlen((string)$s); } }
function wp_strip_all_tags($text, $remove_breaks = false) {
    $text = strip_tags((string)$text);
    return $remove_breaks ? preg_replace('/[\r\n\t ]+/', ' ', $text) : $text;
}
function esc_html($text) { return htmlspecialchars((string)$text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

require_once dirname(__DIR__) . '/includes/class-mace-spi-importer.php';
$ref = new ReflectionClass('MACE5311_SPI_Importer');
$importer = $ref->newInstanceWithoutConstructor();
$prepare = $ref->getMethod('prepare_long_description'); $prepare->setAccessible(true);
$strip = $ref->getMethod('strip_marketplace_noise_tail'); $strip->setAccessible(true);
$stripEditorial = $ref->getMethod('strip_source_editorial_disclosures'); $stripEditorial->setAccessible(true);
$guard = $ref->getMethod('long_description_fidelity_guard'); $guard->setAccessible(true);

$dense = '<p>Première phrase de présentation factuelle du produit qui explique son usage principal et ses capacités sans ajouter de données nouvelles. Deuxième phrase factuelle qui précise le fonctionnement et les caractéristiques déjà présentes dans la fiche externe. Troisième phrase factuelle qui complète la description avec les informations techniques disponibles sur la source. Quatrième phrase factuelle conservée intégralement afin de tester une séparation de paragraphe sans réécriture.</p>';
$source = $dense
    . '<h2>fonctionnalité:</h2><ul><li>intelligente: auto-programmateur cognitif noesis™</li></ul>'
    . '<h2>spécifications:</h2><ul><li>poids: 18.5 kilogrammes</li><li>dimensions du produit: 28 x 52 x 68 cm</li></ul>'
    . '<p>Réponses générées par IA à partir des informations vendeur</p>'
    . '<h2>Les internautes ont aussi acheté</h2><p>Trier par</p><p>Voir les critères de classement</p><ul><li></li><li></li></ul>';

$editorialClean = $stripEditorial->invoke($importer, $source);
$clean = $strip->invoke($importer, $editorialClean['html']);
$readable = $prepare->invoke($importer, $source, ['description_format'=>'source-rendered-semantic-html-v2'], ['air_long_description'=>1,'merchant_long_description'=>0]);
$strict = $prepare->invoke($importer, $source, ['description_format'=>'source-rendered-semantic-html-v2'], ['air_long_description'=>0,'merchant_long_description'=>0]);

$checks = [
    'source AI disclosure removed' => stripos($readable['html'], 'Réponses générées par IA') === false,
    'noise heading removed' => stripos($readable['html'], 'Les internautes ont aussi acheté') === false,
    'noise sort text removed' => stripos($readable['html'], 'Trier par') === false,
    'functionality preserved' => stripos($readable['html'], 'fonctionnalité') !== false,
    'specifications preserved' => stripos($readable['html'], 'spécifications') !== false,
    'dimensions preserved' => strpos($readable['html'], '28 x 52 x 68 cm') !== false,
    'readability wrapper present' => strpos($readable['html'], 'mace-long-description--readable') !== false,
    'dense paragraph split' => substr_count($readable['html'], '<p') >= 2,
    'readability mode selected' => $readable['mode'] === 'source_readability',
    'noise report confirms removal' => !empty($readable['report']['noise_removed']),
    'strict mode still removes only marketplace tail' => stripos($strict['html'], 'Les internautes ont aussi acheté') === false && strpos($strict['html'], '28 x 52 x 68 cm') !== false,
    'strict clean mode reported' => $strict['mode'] === 'source_fidelity_clean',
    'fidelity guard passes after readability transform' => $guard->invoke($importer, $clean['html'], $readable['html']) === true,
];

$failed=[];
foreach($checks as $label=>$ok){echo ($ok?'PASS':'FAIL')." - $label\n"; if(!$ok)$failed[]=$label;}
if($failed){fwrite(STDERR,'Readability/noise checks failed: '.implode(', ',$failed)."\n"); exit(1);}
echo "long-description-readability-noise-check: OK\n";
