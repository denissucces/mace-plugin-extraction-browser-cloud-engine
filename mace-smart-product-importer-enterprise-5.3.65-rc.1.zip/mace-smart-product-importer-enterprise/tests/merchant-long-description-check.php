<?php
define('ABSPATH', __DIR__ . '/');
class MACE5311_SPI_Client {}
class MACE5311_SPI_Extractor {}
class MACE5311_SPI_Quality {}
class MACE5311_SPI_Logger {}
if (!function_exists('mb_strlen')) { function mb_strlen($s,$enc=null){ return strlen((string)$s); } }
function wp_strip_all_tags($text, $remove_breaks = false) {
    $text = strip_tags((string)$text);
    return $remove_breaks ? preg_replace('/[\r\n\t ]+/', ' ', $text) : $text;
}
function esc_html($text) { return htmlspecialchars((string)$text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

require_once dirname(__DIR__) . '/includes/class-mace-spi-importer.php';
$ref = new ReflectionClass('MACE5311_SPI_Importer');
$importer = $ref->newInstanceWithoutConstructor();
$prepare = $ref->getMethod('prepare_long_description');
$prepare->setAccessible(true);
$guard = $ref->getMethod('long_description_fidelity_guard');
$guard->setAccessible(true);

$source = '<p>Première phrase factuelle suffisamment détaillée sur le produit et son usage, sans aucune donnée inventée. Deuxième phrase factuelle décrivant son fonctionnement et ses caractéristiques principales de manière précise. Troisième phrase factuelle qui conserve exactement les informations de la fiche source sans réécriture. Quatrième phrase factuelle qui complète la présentation avec les mêmes données produit, dans le même ordre et sans suppression.</p><h2>Spécifications</h2><ul><li>Poids : 18,5 kg</li><li>Dimensions : 28 x 52 x 68 cm</li></ul>';

$off = $prepare->invoke($importer, $source, ['description_format'=>'source-rendered-semantic-html-v2'], ['air_long_description'=>0,'merchant_long_description'=>0]);
$on = $prepare->invoke($importer, $source, ['description_format'=>'source-rendered-semantic-html-v2'], ['air_long_description'=>0,'merchant_long_description'=>1]);

$checks = [
    'opt-out returns exact source HTML' => $off['html'] === $source,
    'opt-out mode remains source fidelity' => $off['mode'] === 'source_fidelity',
    'opt-in activates merchant wrapper' => strpos($on['html'], 'mace-long-description--merchant') !== false,
    'opt-in splits dense source paragraph' => substr_count($on['html'], '<p') >= 2,
    'opt-in preserves source heading' => strpos($on['html'], '<h2>Spécifications</h2>') !== false,
    'opt-in preserves source list items' => substr_count($on['html'], '<li>') === 2,
    'content fidelity guard passes' => $guard->invoke($importer, $source, $on['html']) === true,
    'presentation report confirms guard' => !empty($on['report']['guard_passed']),
    'presentation mode is merchant professional' => $on['mode'] === 'merchant_professional',
];

$tampered = str_replace('18,5 kg', '19 kg', $on['html']);
$checks['content fidelity guard rejects changed fact'] = $guard->invoke($importer, $source, $tampered) === false;

$failed = [];
foreach ($checks as $label=>$ok) {
    echo ($ok ? 'PASS' : 'FAIL') . " - $label\n";
    if (!$ok) $failed[] = $label;
}
if ($failed) {
    fwrite(STDERR, 'Merchant long description checks failed: ' . implode(', ', $failed) . "\n");
    exit(1);
}
echo "merchant-long-description-check: OK\n";
