#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
find "$ROOT" -name '*.php' -print0 | xargs -0 -n1 php -l
printf 'Static PHP syntax checks passed.\n'
