<?php
if(!defined('ABSPATH')) define('ABSPATH',__DIR__.'/');
function wp_strip_all_tags($s){return strip_tags((string)$s);} function sanitize_text_field($s){return trim(strip_tags((string)$s));}
function wp_json_encode($v,$f=0){return json_encode($v,$f);} function wc_format_decimal($v){$v=str_replace([' ', ','],['','.'],(string)$v);return is_numeric($v)?rtrim(rtrim(number_format((float)$v,4,'.',''),'0'),'.'):'';} function wp_kses_post($s){return $s;} function esc_html($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');} function get_option($k,$d=[]){return $d;} function remove_accents($s){return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s)?:$s;} function __($s,$d=null){return $s;} function wpautop($s,$br=true){return $s;} function sanitize_key($s){return strtolower(preg_replace('/[^a-z0-9_\-]/i','',(string)$s));} function esc_url_raw($s){return $s;}
require_once dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor(); $m=new ReflectionMethod($e,'resolve_regular_price_authority'); $m->setAccessible(true);
// Exact production payload shape observed through Secure MCP: weak role is top-level.
$v=$m->invoke($e,['source_url'=>'https://www.manomano.fr/p/climatiseur-samsung-ar35','regular_price'=>'92.11','price_source'=>'primary-buybox-cta-text']);
if($v!==''){fwrite(STDERR,"top-level weak role survived: $v\n");exit(1);} 
// Certified product-price contract must override contaminated Cloud regular_price.
$v=$m->invoke($e,['source_url'=>'https://www.manomano.fr/p/climatiseur-samsung-ar35','regular_price'=>'92.11','price_source'=>'primary-buybox-cta-text','product_price_contract'=>['version'=>'product-price-evidence-contract-v3','status'=>'certified','semantic_role'=>'product_price','authoritative_price'=>'499','corroboration'=>['json-ld-product-offer','visible-buybox-price']]]);
if($v!=='499'){fwrite(STDERR,"certified contract did not win: $v\n");exit(2);} 
// Existing exact product-zone route remains valid.
$v=$m->invoke($e,['source_url'=>'https://www.fnac.com/x','regular_price'=>'1299','price_source'=>'exact-product-zone']);
if($v!=='1299'){fwrite(STDERR,"exact legacy price regressed: $v\n");exit(3);} 
echo "PASS product price evidence contract 5.3.63\n";
