#!/usr/bin/env bash
set -euo pipefail
CLOUD="$(cd "$(dirname "$0")/../../cloud" 2>/dev/null && pwd || true)"
# Le test est lancé depuis le dossier de travail complet ; fallback explicite.
[ -n "$CLOUD" ] || CLOUD="/mnt/data/mace_primary_price_5319_work/cloud"
grep -q "primary-buybox-cta" "$CLOUD/src/bridge.js"
grep -q "autres?.*offres" "$CLOUD/src/bridge.js"
grep -q "primaryPriceAuthority.value||structuredPrice" "$CLOUD/src/bridge.js"
grep -q "primaryPriceAuthority.value ? regularPrice" "$CLOUD/src/extract.js"
grep -q "price_report" "$CLOUD/src/bridge.js"
echo "Primary Price Authority static checks: OK"
