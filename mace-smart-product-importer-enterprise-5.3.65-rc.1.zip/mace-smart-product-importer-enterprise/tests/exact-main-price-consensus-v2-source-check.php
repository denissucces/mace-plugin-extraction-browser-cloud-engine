<?php
$src=file_get_contents(dirname(__DIR__).'/includes/class-mace-spi-extractor.php');
$need=[
 'primary-buybox-cta-text',
 '$a < 20.0 && $b >= 50.0',
 'exact-product-zone',
 'product-offer',
 'if ($is_fnac && $exact_bridge) return $bridge;',
 'if ($is_manomano && $exact_bridge && $ratio >= 1.35) return $bridge;'
];
foreach($need as $n){ if(strpos($src,$n)===false){fwrite(STDERR,"missing: $n\n");exit(10);} }
echo "OK exact main price consensus v2\n";
