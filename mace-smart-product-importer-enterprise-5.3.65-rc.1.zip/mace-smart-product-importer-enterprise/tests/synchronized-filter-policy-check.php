<?php
function get_option($k,$d=[]){ return [
 'advanced_autonomous_filtering'=>1,
 'filter_blocked_terms'=>"Top ventes\nSeconde vie",
 'filter_blocked_prefixes'=>"MMID\nsellerRef",
 'filter_blocked_regex'=>"\\bprivate-token\\b",
 'filter_urls'=>1,'filter_personal_data'=>1,'filter_concatenated_noise'=>1,'filter_case_insensitive'=>1
];}
function wp_strip_all_tags($v){return strip_tags($v);}
function wp_json_encode($v){return json_encode($v, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
if(!defined('ABSPATH'))define('ABSPATH',__DIR__);
require dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';
$p=MACE5311_SPI_Content_Firewall::export_filtering_policy();
if(($p['version']??'')!=='h5q7-admin-filter-policy-v1')exit(10);
if(!in_array('MMID',$p['blocked_prefixes']??[],true))exit(11);
if(!in_array('EAN',$p['protected_identifiers']??[],true))exit(12);
if(empty($p['policy_hash'])||strlen($p['policy_hash'])!==64)exit(13);
echo "OK synchronized filtering policy\n";
