<?php
define('ABSPATH', __DIR__ . '/');
function get_option($k,$d=null){ return $k==='woocommerce_weight_unit'?'kg':($k==='woocommerce_dimension_unit'?'cm':$d); }
function wp_strip_all_tags($s){ return strip_tags($s); }
function mb_strtolower($s,$enc=null){ return strtolower($s); }
function mb_substr($s,$start,$len=null,$enc=null){ return $len===null?substr($s,$start):substr($s,$start,$len); }
function remove_accents($s){ return $s; }
function wc_format_decimal($v,$dp=4){ return rtrim(rtrim(number_format((float)$v,$dp,'.',''),'0'),'.'); }
function wc_get_dimension($v,$to,$from=''){ return (float)$v; }
function wc_get_weight($v,$to,$from=''){
    $v=(float)$v; $from=strtolower($from); $to=strtolower($to);
    $kg=$from==='g'?$v/1000:($from==='lbs'?$v*0.45359237:($from==='oz'?$v*0.028349523125:$v));
    return $to==='kg'?$kg:$kg;
}
require_once __DIR__.'/../includes/class-mace-spi-importer.php';
$r=new ReflectionClass('MACE5311_SPI_Importer');
$e=$r->newInstanceWithoutConstructor();
$m=$r->getMethod('recover_shipping_measurements_before_save'); $m->setAccessible(true);
$cases=[
 ['Net Poids: 33.1±0.5kg','33.1'],
 ['Poids net : 33,1 ± 0,5 kg','33.1'],
 ['Net weight: 33100 g','33.1'],
 ['Packing weight: 39 kg. Net weight: 33.1 kg','33.1'],
 ['Poids du produit: 72.973 lbs','33.0999'],
];
foreach($cases as [$text,$expected]){
  $out=$m->invoke($e, [], $text);
  if (!isset($out['weight']) || abs((float)$out['weight']-(float)$expected)>0.001) {
    fwrite(STDERR,"FAIL {$text}: got ".($out['weight']??'NULL')." expected {$expected}\n"); exit(1);
  }
}
$out=$m->invoke($e, [], 'Poids colis: 39 kg. Aucun poids produit prouvé.');
if (($out['weight']??'')!=='') { fwrite(STDERR,"FAIL package-only must not materialize product weight\n"); exit(1); }
echo "Weight Evidence Authority: OK\n";
