#!/usr/bin/env bash
set -euo pipefail
F="$(dirname "$0")/../includes/class-mace-spi-importer.php"
grep -q "Terminal WooCommerce Price Materialization Gate v1" "$F"
grep -q "price_materialization === 'blocked_untrusted'" "$F"
grep -q "set_regular_price('')" "$F"
grep -q "price_authority" "$F"
echo "PASS terminal price materialization 5.3.64"
