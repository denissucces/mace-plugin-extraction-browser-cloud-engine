<?php
$root = dirname(__DIR__);
$extractor = file_get_contents($root . '/includes/class-mace-spi-extractor.php');
$importer = file_get_contents($root . '/includes/class-mace-spi-importer.php');
$core = file_get_contents($root . '/includes/class-mace-spi-core.php');
$checks = [
  'extractor keeps specifications rows' => strpos($extractor, "'specifications' =>") !== false,
  'extractor keeps specification report' => strpos($extractor, "'specifications_report' =>") !== false,
  'extractor keeps path registry' => strpos($extractor, "'acquisition_path_registry' =>") !== false,
  'importer stores specifications json' => strpos($importer, '_mace5311_spi_specifications_json') !== false,
  'importer stores specifications report' => strpos($importer, '_mace5311_spi_specifications_report') !== false,
  'importer stores acquisition path registry' => strpos($importer, '_mace5311_spi_acquisition_path_registry') !== false,
  'core renders dedicated characteristics tab' => strpos($core, 'woocommerce_product_tabs') !== false && strpos($core, 'mace_specifications') !== false,
];
foreach ($checks as $label => $ok) { if (!$ok) { fwrite(STDERR,"FAIL: $label\n"); exit(1); } }
echo "Specifications evidence contract checks passed.\n";
