<?php
if (!defined('ABSPATH')) define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($s){return strip_tags($s);} function sanitize_text_field($s){return trim(strip_tags($s));}
require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$rc=new ReflectionClass('MACE5311_SPI_Extractor'); $o=$rc->newInstanceWithoutConstructor();
$m=$rc->getMethod('collect_exact_energy_pairs_from_payload'); $m->setAccessible(true);
$raw=['html'=>'<table><tr><th>Classe énergétique</th><td>D</td></tr><tr><th>Classe énergétique (mode HDR)</th><td>G</td></tr><tr><th>Borne maximale de l’échelle énergétique</th><td>G</td></tr></table>','energy_class'=>'G'];
$r=$m->invoke($o,$raw);
if(($r['default'][0]['value']??'')!=='D') {fwrite(STDERR,"default not D\n");exit(1);} if(($r['hdr'][0]['value']??'')!=='G'){fwrite(STDERR,"hdr not G\n");exit(1);} if(count($r['default'])!==1){fwrite(STDERR,"bound leaked\n");exit(1);} echo "PASS fnac regulatory labeled-pair authority 5.3.59\n";
