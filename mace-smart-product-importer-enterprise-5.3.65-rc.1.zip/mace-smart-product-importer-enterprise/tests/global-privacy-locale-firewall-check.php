<?php
if (!function_exists('wp_strip_all_tags')) { function wp_strip_all_tags($s){ return strip_tags($s); } }
if (!function_exists('get_locale')) { function get_locale(){ return 'fr_FR'; } }
if (!function_exists('apply_filters')) { function apply_filters($tag,$value){ return $value; } }
if (!defined('ABSPATH')) define('ABSPATH', __DIR__);
require_once dirname(__DIR__) . '/includes/class-mace-spi-content-firewall.php';

$dirty = 'Battery: 52V 20.8Ah Max speed: 60km/h Net weight: 33.1±0.5kg Dimensions unfolded: 1260*595*1315mm Packing size: 1295*272*605mm Office hours: 9:00 am - 6:00 pm GMT+8 Email:business@officialkukirin.com WhatsApp:+8615889723154 Address:Lubna Poland.';
$clean = MACE5311_SPI_Content_Firewall::sanitize_plain($dirty);
foreach (['Office hours','business@','WhatsApp','+8615889723154','Lubna Poland'] as $forbidden) {
    if (stripos($clean,$forbidden)!==false) { fwrite(STDERR,"FAIL privacy: $forbidden\n"); exit(1); }
}
if (stripos($clean,'Net weight')===false || stripos($clean,'33.1')===false) { fwrite(STDERR,"FAIL facts lost\n"); exit(1); }
$translated = MACE5311_SPI_Content_Firewall::translate_to_store_locale('Electric Scooter Battery 52V Max speed 60km/h Net weight 33.1kg Dimensions unfolded 1260*595*1315mm', 'short_description');
foreach (['Trottinette électrique','Batterie','Vitesse maximale','Poids net','Dimensions dépliées'] as $required) {
    if (stripos($translated,$required)===false) { fwrite(STDERR,"FAIL translation: $required => $translated\n"); exit(1); }
}
$html = '<p>Produit performant.</p><p>Office hours: 9:00 am. Email: test@example.com</p><img src="https://cdn.example.com/product.jpg" alt="Produit"><p>Autonomie 70 km.</p>';
$cleanHtml = MACE5311_SPI_Content_Firewall::sanitize_html($html);
if (stripos($cleanHtml,'test@example.com')!==false || stripos($cleanHtml,'Office hours')!==false) { fwrite(STDERR,"FAIL html privacy\n"); exit(1); }
if (stripos($cleanHtml,'<img')===false || stripos($cleanHtml,'Autonomie 70 km')===false) { fwrite(STDERR,"FAIL html product content lost\n"); exit(1); }
echo "OK global privacy locale firewall\n";
