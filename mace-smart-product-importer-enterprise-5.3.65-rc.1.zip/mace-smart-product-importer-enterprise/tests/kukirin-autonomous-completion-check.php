<?php
define('ABSPATH', __DIR__ . '/');
if (!function_exists('mb_strlen')) { function mb_strlen($s,$enc=null){ return strlen((string)$s); } }
if (!function_exists('mb_strtolower')) { function mb_strtolower($s,$enc=null){ return strtolower((string)$s); } }
function get_locale(){ return 'fr_FR'; }
function get_option($k,$d=null){ return $k==='woocommerce_weight_unit'?'kg':($k==='woocommerce_dimension_unit'?'cm':($k==='mace5311_spi_settings'?[]:$d)); }
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function sanitize_text_field($v){ return trim(strip_tags((string)$v)); }
function esc_url_raw($v){ return (string)$v; }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$v) ?: (string)$v; }
function wp_parse_url($u,$component=-1){ return parse_url($u,$component); }
function wc_format_decimal($v,$dp=false){ $n=(float)$v; return rtrim(rtrim(number_format($n,$dp===false?6:(int)$dp,'.',''),'0'),'.'); }
function wc_get_weight($v,$to,$from=''){ $kg=$from==='g'?$v/1000:($from==='lbs'?$v*0.45359237:$v); return $to==='g'?$kg*1000:($to==='lbs'?$kg/0.45359237:$kg); }
function wc_get_dimension($v,$to,$from=''){ $cm=$from==='mm'?$v/10:($from==='m'?$v*100:($from==='in'?$v*2.54:$v)); return $to==='mm'?$cm*10:($to==='m'?$cm/100:($to==='in'?$cm/2.54:$cm)); }
require dirname(__DIR__) . '/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor();
$facts=new ReflectionMethod($e,'recover_direct_product_facts_from_text'); $facts->setAccessible(true);
$src='Kukirin G2 Master Battery 52V 20.8AhMax speed: 60km/hDual Motor: 1000W*2Speed level: 20km/h、40km/h、60km/hMax range: 70kmMax load: 120kgCharging time: 7-8hWaterproof level: IP54Brake system: Front and rear disc brake & e-brakeNet weight: 33.1±0.5kgExpend size: 1260*595*1315mmFold size: 1260*595*595mmPacking size: 1295*272*605mmOffice hours 9:00 am - 6:00 pm GMT+8Email:business@officialkukirin.comWhatsApp:+8615889723154Address:Łubna Poland.';
$r=$facts->invoke($e,$src,'');
$expected=['Batterie','Vitesse maximale','Motorisation','Autonomie maximale','Poids net','Dimensions dépliées'];
foreach($expected as $k){ if(empty($r[$k])){ fwrite(STDERR,"missing fact $k\n".json_encode($r,JSON_UNESCAPED_UNICODE)."\n"); exit(1);} }
foreach($r as $v){ if (stripos($v,'office hours')!==false || strpos($v,'@')!==false || stripos($v,'whatsapp')!==false || stripos($v,'poland')!==false) { fwrite(STDERR,"contact leakage\n"); exit(1);} }
$media=new ReflectionMethod($e,'recover_inline_product_media'); $media->setAccessible(true);
$html='<p><img src="https://cdn.shopify.com/s/files/1/x/files/KuKirin-G2-Master_2_01.jpg"><img src="https://cdn.shopify.com/s/files/1/x/files/KuKirin-G2-Master_2_02.jpg"><img src="https://cdn.shopify.com/s/files/1/x/files/banner_generic.jpg"></p>';
$m=$media->invoke($e,$html,'Kukirin G2 Master Electric Scooter',[],[]);
if(count($m['images'])!==2){ fwrite(STDERR,'media recovery expected 2 got '.count($m['images'])."\n"); exit(1); }
if(empty($m['report']['accepted'][0]['ownership_verified'])){ fwrite(STDERR,"media ownership missing\n"); exit(1); }
$measure=new ReflectionMethod($e,'recover_structured_measurements'); $measure->setAccessible(true);
$mm=$measure->invoke($e,[],['Poids net'=>'33.1±0.5kg','Dimensions dépliées'=>'1260*595*1315mm'],'');
if((string)$mm['weight']!=='33.1' || (string)$mm['length']!=='126' || (string)$mm['width']!=='59.5' || (string)$mm['height']!=='131.5'){
 fwrite(STDERR,'measure fail '.json_encode($mm)."\n"); exit(1);
}
$rej=new ReflectionMethod($e,'short_description_hard_rejection_reason'); $rej->setAccessible(true);
$reason=$rej->invoke($e,$src,'Kukirin G2 Master Electric Scooter');
if($reason===''){ fwrite(STDERR,"contact/foreign short description not rejected\n"); exit(1); }
echo "KuKirin autonomous completion authority: OK\n";
