<?php
define('ABSPATH',__DIR__);function sanitize_text_field($s){return trim(strip_tags((string)$s));}function wp_strip_all_tags($s){return strip_tags((string)$s);}function wp_json_encode($v,$f=0){return json_encode($v,$f);}function remove_accents($s){return strtr($s,['é'=>'e','É'=>'E','è'=>'e','ê'=>'e','à'=>'a','ù'=>'u','ç'=>'c','’'=>"'"]);}function plugin_dir_path($f){return dirname($f).'/';}function plugin_dir_url($f){return '';}function wp_parse_url($u,$c=-1){return parse_url($u,$c);}function wp_kses_post($s){return $s;}function esc_url_raw($s){return $s;}function sanitize_title($s){return strtolower(preg_replace('/[^a-z0-9]+/i','-',trim($s)));}function is_wp_error($x){return false;}function get_option($k,$d=[]){return $d;}function apply_filters($t,$v){return $v;}
require_once dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$fw=MACE5311_SPI_Attribute_Firewall::sanitize_map(['Classe énergétique'=>'D','Classe énergétique (mode HDR)'=>'G','Classe énergétique D'=>'G']);
if(($fw['Classe énergétique']??'')!=='D'){fwrite(STDERR,"SDR/default D lost
");exit(1);}if(($fw['Classe énergétique (mode HDR)']??'')!=='G'){fwrite(STDERR,"HDR G lost
");exit(1);}if(isset($fw['Classe énergétique D'])){fwrite(STDERR,"corrupt label survived
");exit(1);}
$ref=new ReflectionClass(MACE5311_SPI_Extractor::class);$x=$ref->newInstanceWithoutConstructor();$m=$ref->getMethod('resolve_energy_truth_authority');$m->setAccessible(true);
$raw=['energy_class'=>'G','rendered_sustainability_evidence'=>['energy_class'=>'D','energy_class_hdr'=>'G'],'specifications'=>[['label'=>'Classe énergétique','value'=>'D'],['label'=>'Classe énergétique (mode HDR)','value'=>'G']]];
[$winner,$report]=$m->invoke($x,$raw,$fw,'TV LED Samsung Mini LED Neo QLED TQ75QN74H 190 cm 2026');
if($winner!=='D'){fwrite(STDERR,"Fnac SDR D did not win over HDR/legacy G: $winner
");exit(1);}if(($report['hdr']??'')!=='G'){fwrite(STDERR,"HDR G not preserved in report
");exit(1);}echo "Fnac Mode-Aware Energy Authority 5.3.57 checks passed.
";
