<?php
define('ABSPATH', __DIR__ . '/');
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function wp_kses($html,$allowed){ return $html; }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$v) ?: (string)$v; }
function esc_html($v){ return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
require dirname(__DIR__) . '/includes/class-mace-spi-extractor.php';
$extractor=new MACE5311_SPI_Extractor();
$rm=new ReflectionMethod(MACE5311_SPI_Extractor::class,'resolve_energy_truth_authority');
$rm->setAccessible(true);
$title='Klarstein – Lave-vaisselle compact 45cm – Classe B – AquaStop';
[$winner,$report]=$rm->invoke($extractor,['energy_class'=>'D'],['Classe énergétique'=>'D'],$title);
if($winner!=='B' || empty($report['locked'])){fwrite(STDERR,"title B did not outrank stale D\n");exit(1);}
[$winner,$report]=$rm->invoke($extractor,['energy_truth_authority_v2'=>['locked'=>true,'winner'=>'B'],'energy_class'=>'D'],['Classe énergétique'=>'D'],$title);
if($winner!=='B' || ($report['source']??'')!=='cloud_locked_energy_truth'){fwrite(STDERR,"locked cloud B not honored\n");exit(1);}
[$winner,$report]=$rm->invoke($extractor,['energy_truth_authority_v2'=>['locked'=>true,'winner'=>'C']],['Classe énergétique'=>'D'],$title);
if($winner!=='' || empty($report['fail_closed'])){fwrite(STDERR,"strong direct B/C conflict did not fail closed\n");exit(1);}
echo "Energy Truth Authority resolver 5.3.54 checks passed.\n";
