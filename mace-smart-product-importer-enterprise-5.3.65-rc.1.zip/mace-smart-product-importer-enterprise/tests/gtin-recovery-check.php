<?php
define('ABSPATH', __DIR__ . '/');
function remove_accents($value) { return $value; }
function wp_strip_all_tags($value) { return strip_tags((string)$value); }
if (!function_exists('mb_strtolower')) { function mb_strtolower($value) { return strtolower((string)$value); } }
require dirname(__DIR__) . '/includes/class-mace-spi-extractor.php';

$extractor = new MACE5311_SPI_Extractor();
$resolve = new ReflectionMethod(MACE5311_SPI_Extractor::class, 'resolve_gtin');
$resolve->setAccessible(true);
$merge = new ReflectionMethod(MACE5311_SPI_Extractor::class, 'merge_raw_products');
$merge->setAccessible(true);
$fromHtml = new ReflectionMethod(MACE5311_SPI_Extractor::class, 'gtin_from_html');
$fromHtml->setAccessible(true);

$cases = [
    [['gtin13' => '3017620422003'], [], '3017620422003'],
    [['gtin' => ''], ['EAN' => '3017620422003'], '3017620422003'],
    [['gtin' => '', 'specifications' => [['label' => 'Code EAN', 'value' => '3017 6204 2200 3']]], [], '3017620422003'],
    [['gtin' => '', 'variants' => [['barcode' => '3017620422003']]], [], '3017620422003'],
];
foreach ($cases as [$raw, $attributes, $expected]) {
    $actual = $resolve->invoke($extractor, $raw, $attributes);
    if ($actual !== $expected) {
        fwrite(STDERR, "GTIN recovery failed: expected $expected, got $actual\n");
        exit(1);
    }
}

$merged = $merge->invoke($extractor, ['name'=>'Cloud','gtin'=>''], ['name'=>'Local','gtin'=>'3017620422003']);
if (($merged['name'] ?? '') !== 'Cloud' || ($merged['gtin'] ?? '') !== '3017620422003') {
    fwrite(STDERR, "Conservative field fusion failed.\n");
    exit(1);
}


$html = '<html><body><table><tr><th>EAN</th><td>3017620422003</td></tr></table></body></html>';
if ($fromHtml->invoke($extractor, $html) !== '3017620422003') {
    fwrite(STDERR, "Visible HTML EAN recovery failed.
");
    exit(1);
}

echo "GTIN/EAN recovery checks: OK\n";
