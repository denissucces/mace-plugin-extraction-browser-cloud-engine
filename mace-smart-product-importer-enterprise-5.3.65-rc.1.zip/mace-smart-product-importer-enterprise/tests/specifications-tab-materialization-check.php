<?php
error_reporting(E_ALL);
define('ABSPATH', __DIR__ . '/');
$MACE_TEST_META = [];
$MACE_TEST_CONTENT = '';
function get_queried_object_id(){ return 4242; }
function get_post_meta($id,$key,$single=true){ global $MACE_TEST_META; return $MACE_TEST_META[$key] ?? ''; }
function get_post_field($field,$id){ global $MACE_TEST_CONTENT; return $MACE_TEST_CONTENT; }
function wp_strip_all_tags($value){ return strip_tags((string)$value); }
function wp_kses_post($value){ return (string)$value; }
function __($value,$domain=null){ return $value; }
require_once dirname(__DIR__) . '/includes/class-mace-spi-core.php';
$ref = new ReflectionClass('MACE5311_SPI_Core');
$core = $ref->newInstanceWithoutConstructor();
$MACE_TEST_META['_mace5311_spi_specifications_html'] = '<section class="mace-product-specifications"><h3>Caractéristiques</h3><table><tbody><tr><th scope="row">Capacité de stockage</th><td>256 Go</td></tr><tr><th scope="row">Couleur</th><td>Argent</td></tr></tbody></table></section>';
$tabs = $core->add_specifications_product_tab([]);
if (!isset($tabs['mace_specifications'])) { fwrite(STDERR,"onglet Caractéristiques absent\n"); exit(1); }
if (($tabs['mace_specifications']['title'] ?? '') !== 'Caractéristiques') { fwrite(STDERR,"titre onglet incorrect\n"); exit(1); }
if (($tabs['mace_specifications']['priority'] ?? 0) !== 25) { fwrite(STDERR,"priorité onglet incorrecte\n"); exit(1); }
ob_start(); $core->render_specifications_product_tab(); $html = ob_get_clean();
if (strpos($html,'Capacité de stockage') === false || strpos($html,'256 Go') === false || strpos($html,'Argent') === false) { fwrite(STDERR,"contenu caractéristiques non matérialisé\n"); exit(1); }
$MACE_TEST_CONTENT = '<p>Description fidèle.</p><section class="mace-product-specifications">Legacy</section>';
$tabs = $core->add_specifications_product_tab([]);
if (isset($tabs['mace_specifications'])) { fwrite(STDERR,"doublon caractéristiques détecté\n"); exit(1); }
echo "Specifications WooCommerce tab materialization checks passed.\n";
