<?php
define('ABSPATH', __DIR__ . '/');
class MACE5311_SPI_Client {}
class MACE5311_SPI_Extractor {}
class MACE5311_SPI_Quality {}
class MACE5311_SPI_Logger {}
require_once dirname(__DIR__) . '/includes/class-mace-spi-importer.php';
$ref = new ReflectionClass('MACE5311_SPI_Importer');
$importer = $ref->newInstanceWithoutConstructor();
$m = $ref->getMethod('compose_long_description');
$m->setAccessible(true);
$description='<p>Description source.</p><h2>fonctionnalité:</h2><ul><li>Intelligente</li></ul>';
$spec='<section class="mace-product-specifications"><table><tr><th>Surface</th><td>700 m²</td></tr></table></section>';
$faithful=$m->invoke($importer,['description'=>$description,'description_format'=>'source-rendered-semantic-html-v2','specifications_html'=>$spec]);
$legacy=$m->invoke($importer,['description'=>$description,'description_format'=>'generated-html','specifications_html'=>$spec]);
$checks=[
  'faithful description unchanged' => $faithful === $description,
  'faithful description excludes appended characteristics' => strpos($faithful,'mace-product-specifications') === false,
  'legacy path retains additive characteristics' => strpos($legacy,'mace-product-specifications') !== false,
];
$failed=[]; foreach($checks as $label=>$ok){ echo ($ok?'PASS':'FAIL')." - $label\n"; if(!$ok)$failed[]=$label; }
if($failed){fwrite(STDERR,"Source layout importer checks failed: ".implode(', ',$failed)."\n");exit(1);} echo "source-layout-importer-check: OK\n";
