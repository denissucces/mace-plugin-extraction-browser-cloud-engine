<?php
define('ABSPATH', __DIR__ . '/');
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function wp_kses($html,$allowed){ return $html; }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$v) ?: (string)$v; }
function esc_html($v){ return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
require dirname(__DIR__) . '/includes/class-mace-spi-attribute-firewall.php';

$clean=MACE5311_SPI_Attribute_Firewall::sanitize_map([
  'hasEnergyEfficiencyCategory'=>'http://schema.org/EUEnergyEfficiencyCategoryB',
  'energyEfficiencyScaleMin'=>'http://schema.org/EUEnergyEfficiencyCategoryD',
  'energyEfficiencyScaleMax'=>'http://schema.org/EUEnergyEfficiencyCategoryA',
]);
if (($clean['Classe énergétique']??'') !== 'B') { fwrite(STDERR,"product class B lost\n"); exit(1); }
if (($clean['Borne minimale de l’échelle énergétique']??'') !== 'D') { fwrite(STDERR,"scale min D not preserved as bound\n"); exit(1); }
if (($clean['Borne maximale de l’échelle énergétique']??'') !== 'A') { fwrite(STDERR,"scale max A not preserved as bound\n"); exit(1); }

$boundsOnly=MACE5311_SPI_Attribute_Firewall::sanitize_map([
  'energyEfficiencyScaleMin'=>'http://schema.org/EUEnergyEfficiencyCategoryD',
  'energyEfficiencyScaleMax'=>'http://schema.org/EUEnergyEfficiencyCategoryA',
]);
if (isset($boundsOnly['Classe énergétique'])) { fwrite(STDERR,"scale bound illegally promoted to product class\n"); exit(1); }

$human=MACE5311_SPI_Attribute_Firewall::sanitize_map([
  'Classe énergétique'=>'B',
  'Classe efficacité énergétique max'=>'A',
  'Classe efficacité énergétique min'=>'G',
]);
if (($human['Classe énergétique']??'') !== 'B') { fwrite(STDERR,"human product class B changed\n"); exit(1); }
foreach ($human as $label=>$value) {
  if (MACE5311_SPI_Attribute_Firewall::is_energy_scale_bound_label($label) && $label === 'Classe énergétique') { fwrite(STDERR,"product class mislabeled as bound\n"); exit(1); }
}

echo "Energy Truth Consistency 5.3.54 checks passed.\n";
