#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
F="$ROOT/includes/class-mace-spi-extractor.php"
grep -q 'recover_brand_from_product_content' "$F"
grep -q 'recover_categories_from_product_content' "$F"
grep -q 'categories_need_recovery' "$F"
grep -q "\['Tondeuses'\]" "$F"
echo 'recover-before-fail plugin static checks: OK'
