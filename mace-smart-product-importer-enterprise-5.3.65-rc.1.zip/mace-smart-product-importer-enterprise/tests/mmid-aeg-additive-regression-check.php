<?php
$root = dirname(__DIR__);
require_once $root . '/includes/class-mace-spi-content-firewall.php';
require_once $root . '/includes/class-mace-spi-attribute-firewall.php';
$cases = [
  ['MMID','651840876022'],
  ['MMID651840876022','x'],
  ['MMID-651840876022','x'],
  ['mmid:600616535885','x'],
];
foreach ($cases as [$k,$v]) {
  [$label,$value,$reason] = MACE5311_SPI_Attribute_Firewall::sanitize_pair($k,$v);
  if ($label !== '' || $value !== '') { fwrite(STDERR, "MMID leak: $k => $v ($reason)\n"); exit(1); }
}
[$label,$value] = MACE5311_SPI_Attribute_Firewall::sanitize_pair('Réf. fabricant','FSE62417P');
if ($label === '' || $value !== 'FSE62417P') { fwrite(STDERR, "manufacturer reference regression\n"); exit(1); }
[$label,$value] = MACE5311_SPI_Attribute_Firewall::sanitize_pair('EAN','7332543672349');
if ($label !== 'EAN' || $value !== '7332543672349') { fwrite(STDERR, "EAN regression\n"); exit(1); }
echo "MMID additive firewall regression OK\n";
