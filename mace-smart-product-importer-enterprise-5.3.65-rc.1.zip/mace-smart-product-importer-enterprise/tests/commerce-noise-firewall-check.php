<?php
define('ABSPATH', __DIR__ . '/');
function get_option($k,$d=null){ return $d; }
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function mb_strtolower($v){ return strtolower($v); }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$v) ?: (string)$v; }
function wp_kses($html,$allowed){ return $html; }
require dirname(__DIR__) . '/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor();
$noise=new ReflectionMethod($e,'is_commerce_noise_attribute'); $noise->setAccessible(true);
$cases=[
 ['3X','4X',true],
 ['Apport Dont financement','179,42 € 8,27 €',true],
 ['J+28','171,15 € 128,36 €',true],
 ['J+60','171,14 € 128,36 €',true],
 ['J+90','128,36 €',true],
 ['TAEG','21,63% 21,61%',true],
 ['Surface de tonte','700,00 m²',false],
 ['EAN','6943475869809',false],
 ['Poids','18.5 kilogrammes',false],
 ['Dimensions du produit','28 x 52 x 68 cm',false],
];
foreach($cases as [$label,$value,$expected]){
  $got=$noise->invoke($e,$label,$value);
  if($got!==$expected){fwrite(STDERR,"Filtre incorrect: $label => ".var_export($got,true)."\n"); exit(1);}
}
$sanitize=new ReflectionMethod($e,'sanitize_specifications_html'); $sanitize->setAccessible(true);
$html='<section><table><tbody><tr><th>3X</th><td>4X</td></tr><tr><th>TAEG</th><td>21,63%</td></tr><tr><th>Surface de tonte</th><td>700,00 m²</td></tr><tr><th>EAN</th><td>6943475869809</td></tr></tbody></table></section>';
$out=$sanitize->invoke($e,$html);
foreach(['3X','TAEG','21,63%'] as $bad){ if(strpos($out,$bad)!==false){fwrite(STDERR,"Bruit survivant: $bad\n"); exit(1);} }
foreach(['Surface de tonte','700,00 m²','EAN','6943475869809'] as $good){ if(strpos($out,$good)===false){fwrite(STDERR,"Donnée produit perdue: $good\n"); exit(1);} }
echo "Commerce noise firewall: OK\n";
