#!/usr/bin/env php
<?php
$e=file_get_contents(__DIR__.'/../includes/class-mace-spi-extractor.php');
$a=file_get_contents(__DIR__.'/../includes/class-mace-spi-attribute-firewall.php');
$c=file_get_contents(__DIR__.'/../includes/class-mace-spi-content-firewall.php');
$checks=[
 [$e,"strpos(\$source, 'manomano.')","source-aware ManoMano price guard"],
 [$e,"visual_ocr_brand_consensus","OCR brand consensus"],
 [$e,"mb_strlen(\$clean) < 2","two-letter brand support"],
 [$a,"manomano\\s*infos","ManoMano attribute chrome firewall"],
 [$a,"color\\s*hex","colorHex firewall"],
 [$a,"peinture\\s+et\\s+droguerie","navigation attribute firewall"],
 [$c,"Product Boundary Firewall v1","description product boundary firewall"],
 [$c,"vos\\s+produits\\s+vus\\s+r[eé]cemment","recently-viewed boundary"],
];
foreach($checks as [$src,$needle,$label]){if(strpos($src,$needle)===false){fwrite(STDERR,"Missing $label\n");exit(1);}}
echo "ManoMano LG Product Integrity static contract: OK\n";
