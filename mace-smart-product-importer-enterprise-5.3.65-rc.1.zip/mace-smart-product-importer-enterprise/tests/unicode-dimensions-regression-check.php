<?php
$sample="dimensions du produit (l x l x h): \u{200E}28 x 52 x 68 cm; 18.5 kilogrammes";
$plain=preg_replace('/[\p{Cf}\x{00AD}]+/u',' ',$sample);
if(!preg_match('/\b(?:dimensions?(?:\s+du\s+produit)?|taille\s+du\s+produit|product\s+dimensions?)\s*(?:\([^)]*\))?\s*[:\-]?\s*(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)\s*(mm|cm|m|in|inch|inches)?/iu',$plain,$m)){fwrite(STDERR,"unicode dimensions not matched\n"); exit(1);} 
if($m[1]!=='28'||$m[2]!=='52'||$m[3]!=='68'){fwrite(STDERR,"bad dimensions\n"); exit(1);} echo "unicode-dimensions-regression: OK\n";
