<?php
define('ABSPATH', __DIR__ . '/');
if (!function_exists('mb_strlen')) { function mb_strlen($s,$enc=null){ return strlen((string)$s); } }
if (!function_exists('mb_strtolower')) { function mb_strtolower($s,$enc=null){ return strtolower((string)$s); } }
if (!function_exists('mb_strtoupper')) { function mb_strtoupper($s,$enc=null){ return strtoupper((string)$s); } }
function get_locale(){ return 'fr_FR'; }
function get_option($k,$d=null){ return $k==='woocommerce_weight_unit'?'kg':($k==='woocommerce_dimension_unit'?'cm':($k==='mace5311_spi_settings'?[]:$d)); }
function wp_strip_all_tags($v){ return strip_tags((string)$v); }
function wp_kses_post($v){ return (string)$v; }
function esc_html($v){ return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function sanitize_text_field($v){ return trim(strip_tags((string)$v)); }
function sanitize_key($v){ return strtolower(preg_replace('/[^a-z0-9_\-]/i','',(string)$v)); }
function esc_url_raw($v){ return (string)$v; }
function wpautop($v,$br=true){ return preg_match('/<p\b/i',(string)$v)?(string)$v:'<p>'.(string)$v.'</p>'; }
function wp_trim_words($text,$n=55,$more=''){ $w=preg_split('/\s+/u',trim((string)$text),-1,PREG_SPLIT_NO_EMPTY); return implode(' ',array_slice($w,0,$n)).(count($w)>$n?$more:''); }
function remove_accents($v){ return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$v) ?: (string)$v; }
function wc_format_decimal($v,$dp=false){ $n=(float)$v; return rtrim(rtrim(number_format($n,$dp===false?6:(int)$dp,'.',''),'0'),'.'); }
function wc_get_weight($v,$to,$from=''){ $kg=$from==='g'?$v/1000:($from==='lbs'?$v*0.45359237:$v); return $to==='g'?$kg*1000:($to==='lbs'?$kg/0.45359237:$kg); }
function wc_get_dimension($v,$to,$from=''){ $cm=$from==='mm'?$v/10:($from==='m'?$v*100:($from==='in'?$v*2.54:$v)); return $to==='mm'?$cm*10:($to==='m'?$cm/100:($to==='in'?$cm/2.54:$cm)); }
require dirname(__DIR__) . '/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor();
$fmt=new ReflectionMethod($e,'format_short_description_for_woocommerce'); $fmt->setAccessible(true);
$out=$fmt->invoke($e,'Résumé correct du produit.','Landroid M700 Plus WR167E',[
 'Surface de tonte'=>'700',
 'Surface de tonte700EAN6943475869809'=>'Voir le détail de sécurité du produit',
 'Largeur de coupe'=>'180 mm',
 'Niveau sonore'=>'67 dB'
],'professional');
if (strpos($out,'6943475869809')!==false || stripos($out,'détail de sécurité')!==false) { fwrite(STDERR,"short noise leaked\n"); exit(1); }
$measure=new ReflectionMethod($e,'recover_structured_measurements'); $measure->setAccessible(true);
$desc='<ul><li>Taille du vélo: 164*68*115(cm)</li><li>Taille de l\'emballage: 143,5*88*28(cm)</li><li>Poids: Poids Brut:41,5kg/Poids net:33,3kg</li></ul>';
$m=$measure->invoke($e,['weight'=>0,'length'=>0,'width'=>0,'height'=>0],[],$desc);
$exp=['weight'=>'33.3','length'=>'164','width'=>'68','height'=>'115'];
foreach($exp as $k=>$v){ if((string)$m[$k]!==$v){ fwrite(STDERR,"$k expected $v got {$m[$k]}\n"); exit(1); } }
$cat=new ReflectionMethod($e,'recover_categories_from_product_content'); $cat->setAccessible(true);
$c=$cat->invoke($e,'Vélo électrique VAE COLORWAY VTT E-Bike','',[]);
if ($c!==['Sports et loisirs','Cyclisme','Vélos électriques']) { fwrite(STDERR,"bike category recovery failed\n"); exit(1); }
$rej=new ReflectionMethod($e,'short_description_hard_rejection_reason'); $rej->setAccessible(true);
$r=$rej->invoke($e,'Kukirin G2 Master Off-Road E-Scooter dual 1000W motor 52V battery 60km/h top speed 80km range and hydraulic shock absorber make it more stable.','Kukirin G2 Master');
if ($r!=='foreign_language_source:en') { fwrite(STDERR,"english locale gate failed: $r\n"); exit(1); }
echo "Fnac COLORWAY + short noise + locale regression: OK\n";
