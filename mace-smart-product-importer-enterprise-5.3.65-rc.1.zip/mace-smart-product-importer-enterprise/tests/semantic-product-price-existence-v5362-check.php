<?php
if(!defined('ABSPATH')) define('ABSPATH',__DIR__.'/');
function wp_strip_all_tags($s){return strip_tags((string)$s);} function sanitize_text_field($s){return trim(strip_tags((string)$s));}
function wp_json_encode($v,$f=0){return json_encode($v,$f);} function wc_format_decimal($v){$v=str_replace([' ', ','],['','.'],(string)$v);return is_numeric($v)?rtrim(rtrim(number_format((float)$v,4,'.',''),'0'),'.'):'';} function wp_kses_post($s){return $s;} function esc_html($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');} function get_option($k,$d=[]){return $d;} function remove_accents($s){return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s)?:$s;} function __($s,$d=null){return $s;} function wpautop($s,$br=true){return $s;} function sanitize_key($s){return strtolower(preg_replace('/[^a-z0-9_\-]/i','',(string)$s));} function esc_url_raw($s){return $s;}
require_once dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$e=new MACE5311_SPI_Extractor();
$m=new ReflectionMethod($e,'resolve_regular_price_authority');$m->setAccessible(true);
$weak92=$m->invoke($e,['source_url'=>'https://www.manomano.fr/p/climatiseur-samsung-ar35','regular_price'=>'92.11','price_evidence'=>['source'=>'primary-buybox-cta-text']]);
if($weak92!==''){fwrite(STDERR,"weak 92.11 CTA survived: $weak92\n");exit(1);} 
$weak174=$m->invoke($e,['source_url'=>'https://www.manomano.fr/p/climatiseur-samsung-ar35','regular_price'=>'174.87','price_evidence'=>['source'=>'alma-financement-par-mois']]);
if($weak174!==''){fwrite(STDERR,"weak financing amount survived: $weak174\n");exit(2);} 
$strong499=$m->invoke($e,['source_url'=>'https://www.manomano.fr/p/climatiseur-samsung-ar35','regular_price'=>'499','price_evidence'=>['source'=>'commerce-price-evidence-v6:json-ld-product-offer','priceCurrency'=>'EUR']]);
if($strong499!=='499'){fwrite(STDERR,"structured 499 rejected: $strong499\n");exit(3);} 
$bridge499=$m->invoke($e,['source_url'=>'https://www.manomano.fr/p/climatiseur-samsung-ar35','regular_price'=>'92.11','price_evidence'=>['source'=>'primary-buybox-cta-text'],'bridge-primary-product-zone-v1'=>['amount'=>'499','source'=>'exact-product-zone']]);
if($bridge499!=='499'){fwrite(STDERR,"exact bridge 499 did not defeat weak CTA: $bridge499\n");exit(4);} 
echo "PASS semantic product-price existence gate 5.3.62\n";
