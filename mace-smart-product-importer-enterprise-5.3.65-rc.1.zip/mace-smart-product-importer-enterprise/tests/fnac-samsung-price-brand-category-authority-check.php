#!/usr/bin/env php
<?php
$src = file_get_contents(__DIR__ . '/../includes/class-mace-spi-extractor.php');
$need = [
  "bridge-primary-product-zone-v1",
  "price_terminal_lock",
  "'oled','qled','neo qled','led','lcd'",
  "['High-tech', 'TV et vidéo', 'Téléviseurs']",
  "Structured/schema brand becomes authoritative",
];
foreach ($need as $needle) {
  if (strpos($src, $needle) === false) {
    fwrite(STDERR, "Missing authority contract: {$needle}\n");
    exit(1);
  }
}
echo "Fnac Samsung price/brand/category authority static contract: OK\n";
