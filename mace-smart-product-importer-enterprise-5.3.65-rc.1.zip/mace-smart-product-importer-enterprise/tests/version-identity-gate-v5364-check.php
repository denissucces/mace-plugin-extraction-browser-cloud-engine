<?php
$main=file_get_contents(dirname(__DIR__).'/mace-smart-product-importer-enterprise.php');
foreach(['Plugin Name: MACE Smart Product Importer Enterprise 5.3.64 RC1','Version: 5.3.64-rc.1',"MACE5311_SPI_VERSION', '5.3.64-rc.1'"] as $needle){if(strpos($main,$needle)===false){fwrite(STDERR,"missing $needle\n");exit(1);}}
echo "PASS version identity 5.3.64 RC1\n";
