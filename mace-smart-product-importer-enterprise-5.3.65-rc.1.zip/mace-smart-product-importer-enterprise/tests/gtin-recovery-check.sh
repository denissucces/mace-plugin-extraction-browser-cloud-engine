#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
php "$ROOT/tests/gtin-recovery-check.php"
grep -q "enrich_cloud_result" "$ROOT/includes/class-mace-spi-client.php"
grep -q "fallback_html" "$ROOT/includes/class-mace-spi-extractor.php"
grep -q "resolve_gtin" "$ROOT/includes/class-mace-spi-extractor.php"
echo "Cloud/autonomous GTIN non-regression checks: OK"
