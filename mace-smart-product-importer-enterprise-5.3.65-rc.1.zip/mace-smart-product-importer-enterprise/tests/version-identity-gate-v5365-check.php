<?php
$root=dirname(__DIR__);
$main=file_get_contents($root.'/mace-smart-product-importer-enterprise.php');
$readme=file_get_contents($root.'/readme.txt');
foreach(['Plugin Name: MACE Smart Product Importer Enterprise 5.3.65 RC1','Version: 5.3.65-rc.1',"MACE5311_SPI_VERSION', '5.3.65-rc.1'"] as $needle){if(strpos($main,$needle)===false){fwrite(STDERR,"missing $needle\n");exit(1);}}
if(strpos($readme,'Stable tag: 5.3.65-rc.1')===false){fwrite(STDERR,"readme version mismatch\n");exit(2);} 
echo "PASS version identity 5.3.65 RC1\n";
