<?php
if(!defined('ABSPATH')) define('ABSPATH',__DIR__.'/');
function wp_strip_all_tags($s){return strip_tags((string)$s);} function sanitize_text_field($s){return trim(strip_tags((string)$s));} function html_entity_decode_compat($s){return html_entity_decode($s,ENT_QUOTES|ENT_HTML5,'UTF-8');}
function wp_json_encode($v,$f=0){return json_encode($v,$f);} function wc_format_decimal($v){$v=str_replace([' ', ','],['','.'],(string)$v);return is_numeric($v)?rtrim(rtrim(number_format((float)$v,4,'.',''),'0'),'.'):'';} function wp_kses_post($s){return $s;} function esc_html($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');} function get_option($k,$d=[]){return $d;} function remove_accents($s){return iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s)?:$s;} function __($s,$d=null){return $s;} function wpautop($s,$br=true){return $s;} function sanitize_key($s){return strtolower(preg_replace('/[^a-z0-9_\-]/i','',(string)$s));} function esc_url_raw($s){return $s;}
require_once dirname(__DIR__).'/includes/class-mace-spi-content-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-attribute-firewall.php';
require_once dirname(__DIR__).'/includes/class-mace-spi-extractor.php';
$fw=MACE5311_SPI_Attribute_Firewall::sanitize_map(['Classe énergétique (refroidissement)'=>'A++','Classe énergétique (chauffage)'=>'A','Classe énergétique'=>'A++ / A']);
if(($fw['Classe énergétique (refroidissement)']??'')!=='A++') die("cooling grade lost\n");
if(($fw['Classe énergétique (chauffage)']??'')!=='A') die("heating grade lost\n");
if(($fw['Classe énergétique']??'')!=='A++ / A') die("composite grade lost\n");
$e=new MACE5311_SPI_Extractor();
$rm=new ReflectionMethod($e,'collect_multimode_energy_evidence');$rm->setAccessible(true);
$r=$rm->invoke($e,['description'=>'<li>Classe énergétique : A++ en refroidissement, A en chauffage</li>'],'Climatiseur SAMSUNG AR35 A++/A R32');
if(($r['cooling']??'')!=='A++'||($r['heating']??'')!=='A'||empty($r['locked'])) die("multimode pair not locked\n");
$rp=new ReflectionMethod($e,'resolve_regular_price_authority');$rp->setAccessible(true);
$p=$rp->invoke($e,['source_url'=>'https://www.manomano.fr/p/aeg','regular_price'=>'2.3','price_evidence'=>['source'=>'primary-buybox-cta-text']]);
if($p!=='') die("weak 2.3 CTA survived\n");
$p2=$rp->invoke($e,['source_url'=>'https://www.manomano.fr/p/cheap','regular_price'=>'9.99','price_evidence'=>['source'=>'json-ld-product-offer','priceCurrency'=>'EUR']]);
if($p2!=='9.99') die("strong genuine low price rejected\n");
echo "PASS multi-mode energy + strict price gate 5.3.61\n";
