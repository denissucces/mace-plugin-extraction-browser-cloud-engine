<?php
/**
 * Plugin Name: MACE Smart Product Importer Enterprise 5.3.65 RC1
 * Description: Importateur autonome WooCommerce relié à MACE Cloud H5Q7, avec récupération complète des données produit, cohérence énergétique et galerie cumulative.
 * Version: 5.3.65-rc.1
 * Author: MACE
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * Text Domain: mace-smart-product-importer-5311-h5q7
 */
defined('ABSPATH') || exit;

if (!defined('MACE5311_SPI_VERSION')) define('MACE5311_SPI_VERSION', '5.3.65-rc.1');
if (!defined('MACE5311_SPI_FILE')) define('MACE5311_SPI_FILE', __FILE__);
if (!defined('MACE5311_SPI_DIR')) define('MACE5311_SPI_DIR', plugin_dir_path(__FILE__));
if (!defined('MACE5311_SPI_URL')) define('MACE5311_SPI_URL', plugin_dir_url(__FILE__));
if (!defined('MACE5311_SPI_CLOUD_URL')) define('MACE5311_SPI_CLOUD_URL', 'https://mace-cloud-extraction-engine-h5q7.onrender.com');
if (!defined('MACE5311_SPI_LEGACY_CLOUD_HOST')) define('MACE5311_SPI_LEGACY_CLOUD_HOST', 'mace-cloud-extraction-engine.onrender.com');

if (class_exists('MACE5311_SPI_Core', false)) {
    add_action('admin_notices', static function (): void { echo '<div class="notice notice-warning"><p>Une autre version de MACE Smart Product Importer est déjà chargée. Désactivez l’ancienne version.</p></div>'; });
    return;
}
if (!function_exists('mace5311_spi_maybe_migrate_cloud_endpoint')) {
    function mace5311_spi_maybe_migrate_cloud_endpoint(): void {
        $settings = get_option('mace5311_spi_settings', []);
        if (!is_array($settings)) $settings = [];

        $current = rtrim(trim((string)($settings['cloud_url'] ?? '')), '/');
        $current_host = strtolower((string) wp_parse_url($current, PHP_URL_HOST));
        $changed = false;

        if ($current === '' || $current_host === MACE5311_SPI_LEGACY_CLOUD_HOST) {
            $was_legacy = ($current_host === MACE5311_SPI_LEGACY_CLOUD_HOST);
            $settings['cloud_url'] = MACE5311_SPI_CLOUD_URL;
            if ($was_legacy) {
                // Les identifiants d'installation sont liés au déploiement Cloud qui les a signés.
                // Un changement d'endpoint doit donc forcer une nouvelle authentification propre.
                $settings['cloud_token'] = '';
                $settings['cloud_token_expires'] = '';
                $settings['cloud_api_key'] = '';
            }
            $changed = true;
        }

        if (empty($settings['installation_id'])) {
            $settings['installation_id'] = wp_generate_uuid4();
            $changed = true;
        }

        if ($changed) update_option('mace5311_spi_settings', $settings, false);
    }
}

require_once MACE5311_SPI_DIR . 'includes/class-mace-spi-content-firewall.php';
require_once MACE5311_SPI_DIR . 'includes/class-mace-spi-attribute-firewall.php';
require_once MACE5311_SPI_DIR . 'includes/class-mace-spi-materialization-firewall.php';
require_once MACE5311_SPI_DIR . 'includes/class-mace-spi-core.php';
add_action('plugins_loaded', static function (): void {
    mace5311_spi_maybe_migrate_cloud_endpoint();
    MACE5311_SPI_Core::instance();
}, 5);

register_activation_hook(__FILE__, static function (): void {
    $defaults = [
        'cloud_url'      => MACE5311_SPI_CLOUD_URL,
        'cloud_api_key'  => '',
        'cloud_token'    => '',
        'cloud_token_expires' => '',
        'installation_id' => wp_generate_uuid4(),
        'cloud_enabled'  => 1,
        'cloud_first'    => 1,
        'minimum_score'  => 70,
        'status'         => 'draft',
        'short_description_format' => 'professional',
        'auto_translate_product_content' => 1,
        'global_privacy_firewall' => 1,
        'advanced_autonomous_filtering' => 1,
        'filter_blocked_terms' => '',
        'filter_blocked_prefixes' => 'MMID',
        'filter_blocked_regex' => '',
        'filter_urls' => 1,
        'filter_personal_data' => 1,
        'filter_concatenated_noise' => 1,
        'filter_case_insensitive' => 1,
        'download_images'=> 1,
        'max_images'     => 12,
        'rename_images'  => 1,
        'generate_image_alt' => 1,
        'reject_suspected_watermarks' => 1,
        'update_existing'=> 0,
        'timeout'        => 45,
        'allowed_hosts'  => '',
    ];
    update_option('mace5311_spi_settings', wp_parse_args(get_option('mace5311_spi_settings', []), $defaults), false);
    mace5311_spi_maybe_migrate_cloud_endpoint();
});
