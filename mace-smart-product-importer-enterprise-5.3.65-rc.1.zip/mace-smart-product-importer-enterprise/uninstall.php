<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
delete_option('mace5311_spi_settings');
delete_option('mace5311_spi_history');
