const EXPECTED_BRIDGE_VERSION='2.0.41';
const BRIDGE_BUILD_ID='h5q7-browser-bridge-2.0.41-product-price-evidence-contract-v3';
const BRIDGE_ENGINE_CONTRACT={energy_truth:'energy-truth-certificate-v2-labeled-pair',gallery:'browser-gallery-completeness-v2.0.32',price:'product-price-evidence-contract-v3',identity:'source-title-identity-authority-v1'};
const bridgeManifest=chrome.runtime.getManifest();
const bridgeRuntimeIdentityCertificate={
  version:'browser-runtime-identity-certificate-v1',
  extension_name:bridgeManifest.name||'MACE Browser Bridge Intelligence',
  extension_version:bridgeManifest.version||'',
  extension_id:chrome.runtime.id||'',
  build_id:BRIDGE_BUILD_ID,
  expected_version:EXPECTED_BRIDGE_VERSION,
  manifest_matches_bundle:(bridgeManifest.version||'')===EXPECTED_BRIDGE_VERSION,
  engine_contract:BRIDGE_ENGINE_CONTRACT
};
const versionNode=document.getElementById('runtimeVersion');
const identityNode=document.getElementById('runtimeIdentity');
if(versionNode)versionNode.textContent=`Version ${bridgeRuntimeIdentityCertificate.extension_version} · H5Q7 Energy Truth + Runtime Identity`;
if(identityNode)identityNode.textContent=`ID actif : ${bridgeRuntimeIdentityCertificate.extension_id} · Build : ${bridgeRuntimeIdentityCertificate.build_id}`;
const cloud='https://mace-cloud-extraction-engine-h5q7.onrender.com';
const msg=t=>{const n=document.getElementById('msg');n.className='';n.textContent=t;};
const maceSummaryValue=v=>String(v??'').trim()||'non détecté';
const maceSummaryClass=(value,kind='')=>{
  const v=String(value??'').trim().toLowerCase();
  if(kind==='price')return v&&v!=='non confirmé'?'ok':'bad';
  if(kind==='energy')return v&&v!=='non détectée'&&v!=='non détecté'?'ok':'warn';
  if(kind==='media')return Number(value)>0?'ok':'warn';
  return '';
};
const maceRenderCaptureSummary=({j,result,detected,validated,rejected,collapsed,primaryPrice,priceSource,dimensions,descriptionSource,descriptionBlocks,specificationsStrategy,specificationsRows,specificationsExpanded,energyClass,energyCooling,energyHeating,durabilityIndex,repairabilityIndex})=>{
  const host=document.getElementById('msg');host.textContent='';host.className='capture-summary';
  const identity=result?.rendered_identity_evidence||{};
  const sustainability=result?.rendered_sustainability_evidence||{};
  const sections=[
    ['Identité du produit',[
      ['Titre produit capturé',identity.title||result?.title||document.title||'non détecté'],
      ['URL source',result?.url||'non détectée'],
      ['Version du Bridge',bridgeRuntimeIdentityCertificate.extension_version],
      ['ID extension actif',bridgeRuntimeIdentityCertificate.extension_id],
      ['Build actif',bridgeRuntimeIdentityCertificate.build_id],
      ['Qualité de capture',`${j.quality?.score??0}%`]
    ]],
    ['Prix',[
      ['Prix Cloud reçu',primaryPrice?`${primaryPrice} €`:'non confirmé','price'],
      ['Source Cloud du prix',priceSource||'non confirmée'],
      ['Prix produit certifié local',result?.product_price_contract?.status==='certified'?`${result.product_price_contract.authoritative_price} €`:'non confirmé','price'],
      ['Rôle sémantique local',result?.product_price_contract?.semantic_role||'non confirmé'],
      ['Prix détecté dans la zone produit',result?.rendered_primary_price?`${result.rendered_primary_price} €`:'non confirmé','price'],
      ['Preuve de zone produit',result?.rendered_primary_price_meta?.strategy||'non confirmée']
    ]],
    ['Description et caractéristiques',[
      ['Dimensions du produit',dimensions],
      ['Source de la description',descriptionSource],
      ['Blocs de description préservés',descriptionBlocks],
      ['Caractéristiques capturées',specificationsStrategy==='none'?'non confirmées':`${specificationsRows} lignes candidates`],
      ['Méthode caractéristiques',specificationsStrategy==='none'?'non confirmée':specificationsStrategy],
      ['Section caractéristiques développée',specificationsExpanded?'oui':'non']
    ]],
    ['Données réglementaires',[
      ['Classe énergétique principale',energyClass||'non détectée','energy'],
      ['Classe énergétique refroidissement',energyCooling||'non détectée','energy'],
      ['Classe énergétique chauffage',energyHeating||'non détectée','energy'],
      ['Classe énergétique SDR',sustainability.energy_class_sdr||'non détectée','energy'],
      ['Classe énergétique HDR',sustainability.energy_class_hdr||'non détectée','energy'],
      ['Indice de durabilité',durabilityIndex||'non détecté'],
      ['Indice de réparabilité',repairabilityIndex||'non détecté']
    ]],
    ['OCR et médias',[
      ['État OCR pixels',identity.ocr_status||'non exécuté'],
      ['Images analysées par OCR',identity.ocr_images_attempted??0],
      ['Marque corroborée par OCR',(identity.visual_ocr_brand_consensus||[]).join(', ')||'aucune'],
      ['Médias détectés',detected,'media'],
      ['Vues produit validées',validated,'media'],
      ['Bruits / intrus rejetés',rejected],
      ['Représentations fusionnées / écartées',collapsed]
    ]]
  ];
  for(const [title,rows] of sections){
    const box=document.createElement('section');box.className='capture-section';
    const h=document.createElement('div');h.className='capture-section-title';h.textContent=title;box.appendChild(h);
    for(const [label,value,kind] of rows){
      const row=document.createElement('div');row.className='capture-row';
      const l=document.createElement('div');l.className='capture-label';l.textContent=label+' :';
      const v=document.createElement('div');v.className='capture-value '+maceSummaryClass(value,kind);v.textContent=maceSummaryValue(value);
      row.append(l,v);box.appendChild(row);
    }
    host.appendChild(box);
  }
  const note=document.createElement('div');note.className='capture-note';note.textContent='Capture transmise. Retournez dans WordPress puis cliquez sur « Vérifier et reprendre ».';host.appendChild(note);
};


// H5Q7 True Pixel OCR Authority v1
// Runs in the extension context, after DOM capture and before Cloud upload.
// It uses browser-native TextDetector when available and an offline pixel-template OCR
// fallback when it is not. Product images are rasterized through Canvas with several
// preprocessing passes; OCR never trusts a single visual token without corroboration.
const maceNormalize=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9&+'’.-]+/g,' ').trim();
const maceTechTokens=new Set(['tv','television','televiseur','oled','qled','neo','mini','micro','led','lcd','uhd','fhd','hd','4k','8k','hdr','hdr10','smart','wifi','bluetooth','quantum','dot','ai','ia','display','screen','ecran','robot','tondeuse','vae','vtt','ebike','bike','batterie','gaming','premium','pro','plus','max','ultra']);
const macePlausibleOcrBrand=v=>{
  const raw=String(v||'').replace(/[®™©]/g,'').replace(/[_]+/g,' ').trim();
  if(raw.length<2||raw.length>32)return '';
  const n=maceNormalize(raw);
  if(!n||/^\d/.test(n))return '';
  const parts=n.split(/\s+/).filter(Boolean);
  if(!parts.length)return '';
  const generic=parts.filter(x=>maceTechTokens.has(x)).length;
  if(generic===parts.length)return '';
  if(parts.length>=2&&generic>=parts.length-1&&/(oled|qled|led|lcd|quantum|mini|neo|smart|uhd|hdr)/.test(n))return '';
  if(/^(?:image|photo|product|produit|view|vue|front|back|main|large|small|gallery|galerie)$/.test(n))return '';
  return raw;
};

const maceLoadBitmap=async url=>{
  const response=await fetch(url,{credentials:'omit',cache:'force-cache'});
  if(!response.ok)throw new Error(`image ${response.status}`);
  const blob=await response.blob();
  if(!/^image\//i.test(blob.type||''))throw new Error('not-image');
  return createImageBitmap(blob);
};
const maceCanvasFromBitmap=(bitmap,maxSide=1600)=>{
  const scale=Math.min(2, maxSide/Math.max(bitmap.width,bitmap.height), 1.75);
  const w=Math.max(1,Math.round(bitmap.width*scale)),h=Math.max(1,Math.round(bitmap.height*scale));
  const c=document.createElement('canvas');c.width=w;c.height=h;
  const x=c.getContext('2d',{willReadFrequently:true});
  x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';x.drawImage(bitmap,0,0,w,h);
  return c;
};
const macePreprocess=(source,mode)=>{
  const c=document.createElement('canvas');c.width=source.width;c.height=source.height;
  const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(source,0,0);
  if(mode==='original')return c;
  const img=x.getImageData(0,0,c.width,c.height),d=img.data;
  const gray=new Uint8Array(c.width*c.height);let sum=0;
  for(let i=0,p=0;i<d.length;i+=4,p++){
    const g=Math.max(0,Math.min(255,Math.round(0.2126*d[i]+0.7152*d[i+1]+0.0722*d[i+2])));gray[p]=g;sum+=g;
  }
  let threshold=sum/Math.max(1,gray.length);
  if(mode==='binary')threshold=Math.max(90,Math.min(205,threshold*0.92));
  for(let i=0,p=0;i<d.length;i+=4,p++){
    let g=gray[p];
    if(mode==='contrast')g=Math.max(0,Math.min(255,(g-128)*1.8+128));
    if(mode==='binary')g=g<threshold?0:255;
    d[i]=d[i+1]=d[i+2]=g;d[i+3]=255;
  }
  x.putImageData(img,0,0);return c;
};

const maceTemplateCache={};
const maceGlyphTemplate=(char,w=24,h=32)=>{
  const key=char+':'+w+'x'+h;if(maceTemplateCache[key])return maceTemplateCache[key];
  const fonts=['Arial Black','Arial','Verdana','sans-serif'];const variants=[];
  for(const font of fonts){
    const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d',{willReadFrequently:true});
    x.fillStyle='#fff';x.fillRect(0,0,w,h);x.fillStyle='#000';x.textAlign='center';x.textBaseline='middle';x.font=`bold ${Math.floor(h*.78)}px ${font}`;x.fillText(char,w/2,h*.53);
    const d=x.getImageData(0,0,w,h).data,mask=new Uint8Array(w*h);for(let i=0,p=0;i<d.length;i+=4,p++)mask[p]=(d[i]<150)?1:0;
    variants.push(mask);
  }
  maceTemplateCache[key]=variants;return variants;
};
const maceMaskSimilarity=(a,b)=>{
  let inter=0,union=0,diff=0;for(let i=0;i<a.length;i++){if(a[i]||b[i])union++;if(a[i]&&b[i])inter++;if(a[i]!==b[i])diff++;}
  return union?0.7*(inter/union)+0.3*(1-diff/a.length):0;
};
const maceResizeMask=(mask,sw,sh,tw=24,th=32)=>{
  const out=new Uint8Array(tw*th);for(let y=0;y<th;y++){for(let x=0;x<tw;x++){const sx=Math.min(sw-1,Math.floor(x*sw/tw)),sy=Math.min(sh-1,Math.floor(y*sh/th));out[y*tw+x]=mask[sy*sw+sx];}}return out;
};
const macePixelTemplateOcr=canvas=>{
  if(canvas.width<20||canvas.height<12)return {text:'',confidence:0};
  const x=canvas.getContext('2d',{willReadFrequently:true}),img=x.getImageData(0,0,canvas.width,canvas.height),d=img.data;
  const W=canvas.width,H=canvas.height,gray=new Uint8Array(W*H);let avg=0;
  for(let i=0,p=0;i<d.length;i+=4,p++){gray[p]=Math.round(.2126*d[i]+.7152*d[i+1]+.0722*d[i+2]);avg+=gray[p];}avg/=gray.length;
  const thr=Math.max(70,Math.min(205,avg*.88));
  const ink=new Uint8Array(W*H);let inkCount=0;for(let p=0;p<gray.length;p++){ink[p]=gray[p]<thr?1:0;inkCount+=ink[p];}
  if(inkCount<30||inkCount>gray.length*.65)return {text:'',confidence:0};
  const cols=new Uint32Array(W);for(let y=0;y<H;y++)for(let xx=0;xx<W;xx++)if(ink[y*W+xx])cols[xx]++;
  const runs=[];let s=-1;for(let xx=0;xx<=W;xx++){const on=xx<W&&cols[xx]>Math.max(1,H*.015);if(on&&s<0)s=xx;if((!on||xx===W)&&s>=0){if(xx-s>=2)runs.push([s,xx-1]);s=-1;}}
  if(runs.length<2||runs.length>24)return {text:'',confidence:0};
  let text='',scores=[];const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  for(const [x0,x1] of runs){let y0=H,y1=-1;for(let yy=0;yy<H;yy++){for(let xx=x0;xx<=x1;xx++){if(ink[yy*W+xx]){y0=Math.min(y0,yy);y1=Math.max(y1,yy);}}}if(y1<y0)continue;
    const sw=x1-x0+1,sh=y1-y0+1;if(sh<6||sw>sh*1.8)continue;const raw=new Uint8Array(sw*sh);for(let yy=0;yy<sh;yy++)for(let xx=0;xx<sw;xx++)raw[yy*sw+xx]=ink[(y0+yy)*W+(x0+xx)];
    const norm=maceResizeMask(raw,sw,sh);let best='',bestScore=0;
    for(const ch of chars){for(const templ of maceGlyphTemplate(ch)){const sc=maceMaskSimilarity(norm,templ);if(sc>bestScore){bestScore=sc;best=ch;}}}
    if(bestScore<.42)continue;text+=best;scores.push(bestScore);
  }
  const confidence=scores.length?scores.reduce((a,b)=>a+b,0)/scores.length:0;
  return {text:text.length>=2?text:'',confidence};
};

const maceExtractOcrBrandCandidates=(text,title,description)=>{
  const out=[];const clean=String(text||'').replace(/[^\p{L}0-9&+'’ ._-]+/gu,' ').replace(/\s+/g,' ').trim();
  for(const segment of clean.split(/[|;,/]+/)){
    const words=segment.trim().split(/\s+/).filter(Boolean);
    for(let size=Math.min(3,words.length);size>=1;size--){for(let i=0;i+size<=words.length;i++){
      const raw=words.slice(i,i+size).join(' ');const c=macePlausibleOcrBrand(raw);if(!c)continue;
      const shape=/^[A-Z0-9&+'’.-]{2,}$/.test(raw)||/^[A-Z][a-z0-9&+'’.-]{1,}$/.test(raw)||raw.length>=4;
      if(shape)out.push(c);
    }}
  }
  const titleN=' '+maceNormalize(title)+' ',descN=' '+maceNormalize(description)+' ';
  return [...new Set(out)].map(c=>{
    const n=maceNormalize(c),titleHit=titleN.includes(' '+n+' '),descHit=descN.includes(' '+n+' ');
    return {candidate:c,titleHit,descriptionHit:descHit,score:(titleHit?5:0)+(descHit?3:0)+Math.min(3,c.length/4)};
  }).sort((a,b)=>b.score-a.score).slice(0,20);
};

const maceRunPixelOcr=async result=>{
  const identity=result?.rendered_identity_evidence;if(!identity)return result;
  const candidates=(identity.ocr_image_candidates||[]).filter(x=>/^https?:/i.test(x.src||'')).slice(0,8);
  if(!candidates.length){identity.ocr_status='no_product_images';return result;}
  const title=identity.title||result.title||'';
  const desc=((result.rendered_description_html||'').replace(/<[^>]+>/g,' ')).slice(0,30000);
  const texts=[],brands=[],failures=[];let detector=null,nativeAvailable=false;
  try{if(typeof TextDetector!=='undefined'){detector=new TextDetector();nativeAvailable=true;}}catch{}
  for(let idx=0;idx<candidates.length;idx++){
    const item=candidates[idx];
    try{
      msg(`OCR pixel par pixel… image ${idx+1}/${candidates.length}`);
      const bitmap=await maceLoadBitmap(item.src);const base=maceCanvasFromBitmap(bitmap);bitmap.close?.();
      const variants=['original','contrast','binary'];const localTexts=[];
      for(const mode of variants){
        const canvas=macePreprocess(base,mode);
        if(detector){
          try{const found=await detector.detect(canvas);const t=found.map(x=>x.rawValue||'').filter(Boolean).join(' ');if(t)localTexts.push(t);}catch(e){failures.push('native:'+e.message);}
        }
        // Offline pixel-template fallback on the binarized image. This is deliberately
        // conservative and only contributes when later corroborated by product text.
        if(mode==='binary'){
          const fallback=macePixelTemplateOcr(canvas);if(fallback.text&&fallback.confidence>=.45)localTexts.push(fallback.text);
        }
      }
      const unique=[...new Set(localTexts.map(x=>String(x).replace(/\s+/g,' ').trim()).filter(Boolean))];
      for(const text of unique){texts.push({src:item.src,text:text.slice(0,500),engine:nativeAvailable?'native-textdetector+pixel-template':'pixel-template',image_index:idx});brands.push(...maceExtractOcrBrandCandidates(text,title,desc));}
    }catch(e){failures.push(`image${idx+1}:${e.message}`);}
  }
  const ranked={};for(const b of brands){const k=maceNormalize(b.candidate);if(!k)continue;const r=ranked[k]||(ranked[k]={candidate:b.candidate,score:0,hits:0,titleHit:false,descriptionHit:false});r.score=Math.max(r.score,b.score);r.hits++;r.titleHit||=b.titleHit;r.descriptionHit||=b.descriptionHit;}
  const rankedList=Object.values(ranked).map(r=>({...r,score:r.score+Math.min(4,r.hits)})).sort((a,b)=>b.score-a.score);
  const consensus=rankedList.filter(r=>r.titleHit||r.descriptionHit||r.hits>=2).slice(0,10).map(r=>r.candidate);

  // H5Q7 Visual Product Evidence Authority v1.
  // OCR can corroborate price/category/brand evidence, but is never allowed to invent a
  // WooCommerce fact on its own. Visual money values are retained as candidates only;
  // the terminal price authority must match them against DOM/JSON-LD/product-zone lanes.
  const joinedOcr=texts.map(x=>x.text).join(' ');
  const visualMoney=[];
  const moneyRe=/(?:€\s*)?(\d{1,4}(?:[ .]\d{3})*(?:[,.]\d{2})?)(?:\s*€|\s*EUR)\b/gi;
  let mm; while((mm=moneyRe.exec(joinedOcr))){
    const amount=Number(String(mm[1]).replace(/\s/g,'').replace(',','.'));
    if(Number.isFinite(amount)&&amount>0&&amount<100000)visualMoney.push(Number(amount.toFixed(2)));
  }
  const visualPriceCandidates=[...new Set(visualMoney)].slice(0,20);

  const visualTax=[];
  const taxText=maceNormalize([title,desc,joinedOcr].join(' '));
  const addTax=(...xs)=>xs.forEach(x=>visualTax.push(x));
  if(/lave\s*vaisselle|dishwasher/.test(taxText))addTax('Électroménager','Gros électroménager','Lave-vaisselle');
  if(/lave\s*linge|machine\s+a\s+laver|washing machine/.test(taxText))addTax('Électroménager','Gros électroménager','Lave-linge');
  if(/seche\s*linge|tumble dryer/.test(taxText))addTax('Électroménager','Gros électroménager','Sèche-linge');
  if(/refrigerateur|frigo|refrigerator/.test(taxText))addTax('Électroménager','Gros électroménager','Réfrigérateurs');
  if(/congelateur|freezer/.test(taxText))addTax('Électroménager','Gros électroménager','Congélateurs');
  if(/(?:tv|television|televiseur).*(?:oled|qled|led|lcd|uhd|4k|8k|smart)|(?:oled|qled).*(?:tv|television|televiseur)/.test(taxText))addTax('High-tech','TV et vidéo','Téléviseurs');
  if(/trottinette|e[- ]?scooter|electric scooter/.test(taxText))addTax('Sports et loisirs','Mobilité urbaine','Trottinettes électriques');
  if(/velo|vae|vtt|e[- ]?bike|fat\s*bike/.test(taxText))addTax('Sports et loisirs','Cyclisme','Vélos électriques');
  if(/robot\s+tondeuse|tondeuse\s+robot/.test(taxText))addTax('Jardin','Outillage de jardin','Tondeuses');

  identity.image_ocr_text=texts.slice(0,24);
  identity.visual_ocr_price_candidates=visualPriceCandidates;
  identity.visual_ocr_taxonomy_hints=[...new Set(visualTax)].slice(0,12);
  identity.visual_product_evidence_authority={
    version:'h5q7-visual-product-evidence-authority-v1',
    brand_consensus:consensus,
    price_candidates:visualPriceCandidates,
    taxonomy_hints:[...new Set(visualTax)].slice(0,12),
    policy:'ocr-corroboration-only',
    no_ocr_only_materialization:true,
    additive_only:true
  };
  identity.ocr_brand_candidates=rankedList.slice(0,20).map(r=>r.candidate);
  identity.visual_ocr_brand_consensus=consensus;
  identity.visual_text_brand_consensus=[...new Set([...(identity.visual_text_brand_consensus||[]),...consensus])].slice(0,15);
  identity.ocr_status=texts.length?'completed':'completed_no_text';
  identity.ocr_engine=nativeAvailable?'browser-native-TextDetector+canvas-multipass+offline-pixel-template-v1':'canvas-multipass+offline-pixel-template-v1';
  identity.ocr_images_attempted=candidates.length;identity.ocr_images_with_text=texts.length;identity.ocr_failures=failures.slice(0,12);
  identity.visual_evidence_strategy='product-gallery+true-pixel-ocr+visual-product-evidence-authority-v1+cross-lane-consensus-v5';
  return result;
};

document.getElementById('send').onclick=async()=>{
  try{
    const code=document.getElementById('code').value.trim().toUpperCase();
    if(!code) throw new Error('Saisissez le code Browser Bridge.');
    msg('Synchronisation de la politique de filtrage…');
    let filterPolicy={
      version:'h5q7-admin-filter-policy-v1',enabled:true,case_insensitive:true,
      remove_urls:true,remove_personal_data:true,remove_concatenated_noise:true,
      blocked_terms:[],blocked_prefixes:['MMID'],blocked_regex:[],
      protected_identifiers:['EAN','GTIN','UPC','ISBN','MPN','Réf. fabricant','Référence fabricant'],
      additive_only:true
    };
    try{
      const pr=await fetch(cloud+'/v1/bridge/policy/'+encodeURIComponent(code),{credentials:'omit',cache:'no-store'});
      if(pr.ok){
        const pj=await pr.json();
        if(pj?.ok&&pj?.filtering_policy)filterPolicy={...filterPolicy,...pj.filtering_policy};
      }
    }catch{}
    msg('Capture en cours…');
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!/^https?:/i.test(tab.url||'')) throw new Error('Ouvrez une page produit http/https.');

    const [{result:primaryResult}]=await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:async(filterPolicy)=>{
        const clean=v=>String(v??'').replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\u00AD]/g,' ').replace(/\s+/g,' ').trim();
        const normalize=v=>clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
        const policy=filterPolicy&&typeof filterPolicy==='object'?filterPolicy:{enabled:true,blocked_prefixes:['MMID']};
        const policyProtected=v=>/^(?:ean|gtin(?:8|12|13|14)?|upc|isbn(?:10|13)?|mpn|r[eé]f\.?\s*fabricant|r[eé]f[eé]rence\s*fabricant)$/iu.test(clean(v));
        const policyForbidden=v=>{
          const raw=clean(v); if(!raw||policy.enabled===false||policyProtected(raw))return false;
          const hay=policy.case_insensitive===false?raw:normalize(raw);
          for(const term of (policy.blocked_terms||[]).slice(0,250)){
            const needle=policy.case_insensitive===false?clean(term):normalize(term);
            if(needle&&hay.includes(needle))return true;
          }
          if(policy.remove_concatenated_noise!==false){
            for(const prefix of (policy.blocked_prefixes||['MMID']).slice(0,100)){
              const p=clean(prefix).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); if(!p)continue;
              if(new RegExp('^'+p+'[\\\\s:_#.-]*[a-z0-9]{3,}$','i').test(raw.replace(/\\s+/g,'')))return true;
              if(new RegExp('(?:^|[^a-z0-9])'+p+'[\\\\s:_#.-]*[a-z0-9]{4,}\\\\b','i').test(raw))return true;
            }
          }
          for(const rx of (policy.blocked_regex||[]).slice(0,50)){
            if(String(rx).length>300)continue;try{if(new RegExp(rx,'iu').test(raw))return true}catch{}
          }
          return false;
        };
        const policySanitizeText=v=>{
          let out=String(v??''); if(policy.enabled===false)return out;
          if(policy.remove_urls!==false){
            out=out.replace(/\b(?:https?:\/\/|www\.)\S+/giu,' ');
            out=out.replace(/\b(?:mailto|tel|sms|whatsapp)\s*:\s*\S+/giu,' ');
          }
          if(policy.remove_personal_data!==false){
            out=out.replace(/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/giu,' ');
            out=out.replace(/(?:^|\s)\+\d(?:[\s().\-]*\d){7,}(?=\s|$)/gu,' ');
          }
          for(const term of (policy.blocked_terms||[]).slice(0,250)){
            const t=clean(term);if(!t)continue;
            try{out=out.replace(new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'giu'),' ')}catch{}
          }
          if(policy.remove_concatenated_noise!==false){
            for(const prefix of (policy.blocked_prefixes||['MMID']).slice(0,100)){
              const p=clean(prefix).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');if(!p)continue;
              try{out=out.replace(new RegExp('\\b'+p+'[\\\\s:_#.-]*[A-Z0-9]{4,}\\b','giu'),' ')}catch{}
            }
          }
          for(const rx of (policy.blocked_regex||[]).slice(0,50)){
            if(String(rx).length>300)continue;try{out=out.replace(new RegExp(rx,'giu'),' ')}catch{}
          }
          return out.replace(/\s{2,}/g,' ').trim();
        };
        const applyPolicyToBox=box=>{
          if(policy.enabled===false)return box;
          box.querySelectorAll('tr,[role="row"],li,dt,dd,p,div,span,small,h1,h2,h3,h4,h5,h6').forEach(el=>{
            const txt=clean(el.textContent);
            if(txt&&policyForbidden(txt)&&txt.length<1600)el.remove();
          });
          [...box.childNodes].forEach(()=>{});
          return box;
        };
        const visible=el=>{
          if(!(el instanceof Element)) return false;
          const s=getComputedStyle(el);
          if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0) return false;
          const r=el.getBoundingClientRect();
          return r.width>0&&r.height>0;
        };
        const structuralCount=html=>({
          headings:(html.match(/<h[1-6]\b/gi)||[]).length,
          paragraphs:(html.match(/<p\b/gi)||[]).length,
          lists:(html.match(/<(?:ul|ol)\b/gi)||[]).length,
          list_items:(html.match(/<li\b/gi)||[]).length,
          tables:(html.match(/<table\b/gi)||[]).length,
          blocks:(html.match(/<(?:div|section|article|blockquote|pre|dl|dt|dd)\b/gi)||[]).length,
          breaks:(html.match(/<br\b/gi)||[]).length,
        });
        const serializeFragment=fragment=>{
          const box=document.createElement('div');
          box.append(fragment.cloneNode(true));
          return box.innerHTML;
        };
        const merchantSafeHtml=(html,kind='description')=>{
          const box=document.createElement('div');box.innerHTML=String(html||'');
          box.querySelectorAll('script,style,noscript,iframe,form,footer,nav,aside,[role="navigation"],[role="contentinfo"],[role="dialog"]').forEach(el=>el.remove());
          const chromeRx=/(?:vos produits vus récemment|vous êtes ici|newsletter|paiement sécurisé|suivi de commande|retour \/ rétractation|besoin d.?aide|nous contacter|notifier un contenu illicite|devenir marchand|programme d.?affiliation|conditions générales|nos inspirations|top ventes?|découvrir manoexpress|plan du site|mentions légales|protection des données|trust center|accessibilité|catalogue|seconde vie|les conseils de nos experts|aide et paramètres|aide et contact|pro\.? créez votre compte|découvrir notre app|manomano infos?|©\s*\d{4}\s*manomano|google play|app store|facebook|instagram|linkedin|tiktok|pinterest)/i;
          [...box.querySelectorAll('section,div,p,li,ul,ol,h2,h3,h4,h5,h6')].reverse().forEach(el=>{
            const txt=clean(el.textContent); if(txt && txt.length<1800 && chromeRx.test(normalize(txt))) el.remove();
          });
          const sourceLabel=t=>{
            const n=normalize(t);
            if(/^(?:mmid|vous etes ici|breadcrumb|breadcrumbs)$/.test(n)||/^mmid[a-z0-9]{3,}$/.test(n))return true;
            if(/^(?:ref(?:erence)? )?(?:manomano|fnac|rakuten|amazon|cdiscount|boulanger)(?: (?:id|ref|reference))?$/.test(n))return true;
            if(/(?:manomano|fnac|rakuten|amazon|cdiscount|boulanger)/.test(n)&&/(?:ref|reference|id|source|marketplace)/.test(n))return true;
            if(n.startsWith('accueil/')||n.startsWith('accueil >'))return true;
            return false;
          };
          const disclosure=t=>{
            const n=normalize(t).replace(/[.]+$/,'').trim();
            return n==='reponses generees par ia a partir des informations vendeur'||n==="reponses generees par l'ia a partir des informations vendeur"||n==='contenu genere par ia'||n==="contenu genere par l'ia"||n==='informations fournies par le vendeur'||n==='donnees fournies par le vendeur';
          };
          box.querySelectorAll('p,div,span,small').forEach(el=>{if(disclosure(el.textContent)&&clean(el.textContent).length<180)el.remove();});
          if(kind==='specifications'){
            box.querySelectorAll('tr,[role="row"],li,dt,div').forEach(el=>{
              let label='';
              const cells=el.matches('tr,[role="row"]')?[...el.children]:[];
              if(cells.length>=2)label=clean(cells[0].textContent);
              else if(el.matches('dt'))label=clean(el.textContent);
              else if(el.children.length===2)label=clean(el.children[0].textContent);
              if(label&&sourceLabel(label))el.remove();
            });
          }
          applyPolicyToBox(box);
          return box.innerHTML.trim();
        };
        const isSpecificationsHeading=t=>/^(?:caracteristiques?(?: techniques?)?|specifications?(?: techniques?)?|fiche technique|details techniques?|informations? techniques?|technical specifications?|technical details?|product specifications?|product details?)$/i.test(normalize(t));
        const isSpecificationsBoundary=t=>/^(?:description(?: du produit)?|resume|avis clients?|avis|reviews?|questions?(?: et)? reponses?|offres?(?: sur ce produit)?|autres offres?|livraison|financement|garanties?|accessoires?|produits? similaires?|vous aimerez aussi|recommandations?|securite du produit|details de securite du produit)$/i.test(normalize(t));
        const expandSpecifications=async()=>{
          const expansionText=t=>/^(?:voir tout|tout afficher|afficher plus|voir plus|plus de caracteristiques|voir les caracteristiques|show all|show more)$/i.test(normalize(t));
          const roots=[...document.querySelectorAll('section,article,div')]
            .filter(el=>{
              const text=clean(el.textContent);
              return text.length>=8&&text.length<=1800&&/(?:caracteristiques?|specifications?|fiche technique|technical specifications?)/i.test(normalize(text));
            })
            .sort((a,b)=>clean(a.textContent).length-clean(b.textContent).length);
          for(const root of roots.slice(0,20)){
            const controls=[...root.querySelectorAll('button,a,[role="button"]')].filter(el=>visible(el)&&expansionText(el.textContent));
            const control=controls[0];
            if(!control)continue;
            try{control.click();await new Promise(resolve=>setTimeout(resolve,450));return {expanded:true,control:clean(control.textContent)};}catch{}
          }
          return {expanded:false,control:''};
        };
        const captureSpecifications=()=>{
          const headingLike=[...document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]')];
          const anchors=headingLike.filter(h=>isSpecificationsHeading(h.textContent));
          const anchor=anchors.find(visible)||anchors[0];
          if(anchor){
            const anchorIndex=headingLike.indexOf(anchor);
            const boundary=headingLike.slice(anchorIndex+1).find(h=>isSpecificationsBoundary(h.textContent));
            try{
              const range=document.createRange();
              range.setStartAfter(anchor);
              if(boundary)range.setEndBefore(boundary);else{const owner=start.closest('main,[role=\"main\"],article');const terminal=owner?.querySelector('footer,[role=\"contentinfo\"],nav');if(terminal)range.setEndBefore(terminal);else if(owner&&owner.lastChild)range.setEndAfter(owner.lastChild);else return null;}
              const frag=range.cloneContents();
              const html=merchantSafeHtml(serializeFragment(frag).trim(),'specifications');
              const text=clean((()=>{const x=document.createElement('div');x.innerHTML=html;return x.textContent||''})());
              if(text.length>=4&&text.length<=120000&&html.length<=900000){
                const probe=document.createElement('div');probe.innerHTML=html;
                const tables=probe.querySelectorAll('tr,[role="row"],dt').length;
                const likelyPairs=[...probe.querySelectorAll('div,li')].filter(el=>el.children.length===2&&clean(el.textContent).length<3500).length;
                return {html,meta:{strategy:'specifications-heading-range',anchor:clean(anchor.textContent),boundary:boundary?clean(boundary.textContent):'',text_length:text.length,row_candidates:tables+likelyPairs,...structuralCount(html)}};
              }
            }catch{}
          }
          const selectors=['[class*="characteristic" i]','[id*="characteristic" i]','[data-testid*="characteristic" i]','[class*="specification" i]','[id*="specification" i]','[data-testid*="specification" i]','[class*="technical" i]','[data-testid*="technical" i]','[aria-label*="caractéristique" i]','[aria-label*="specification" i]'];
          const seen=new Set(),candidates=[];
          selectors.forEach(selector=>document.querySelectorAll(selector).forEach(el=>{
            if(seen.has(el))return;seen.add(el);
            const text=clean(el.textContent);if(text.length<4||text.length>120000)return;
            let score=Math.min(text.length,20000);
            if(/caracteristique|specification|technical/i.test(normalize([el.className,el.id,el.getAttribute?.('data-testid'),el.getAttribute?.('aria-label')].join(' '))))score+=5000;
            if(visible(el))score+=1500;
            candidates.push({el,text,score});
          }));
          candidates.sort((a,b)=>b.score-a.score);
          const best=candidates[0];if(!best)return {html:'',meta:{strategy:'none',text_length:0,row_candidates:0}};
          const html=merchantSafeHtml(best.el.innerHTML.trim(),'specifications');if(!html||html.length>900000)return {html:'',meta:{strategy:'none',text_length:0,row_candidates:0}};
          const probe=document.createElement('div');probe.innerHTML=html;
          const rows=probe.querySelectorAll('tr,[role="row"],dt').length+[...probe.querySelectorAll('div,li')].filter(el=>el.children.length===2&&clean(el.textContent).length<3500).length;
          return {html,meta:{strategy:'specifications-selector',text_length:best.text.length,row_candidates:rows,...structuralCount(html)}};
        };
        const captureByHeadingRange=()=>{
          const headingLike=[...document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]')].filter(visible);
          const isDescription=t=>/^(?:description|description du produit|product description|description produit)$/i.test(normalize(t));
          const isBoundary=t=>/^(?:avis clients?|avis|reviews?|conseils(?: fnac)?|informations? financement|financement|questions? reponses?|questions? et reponses?|produits? similaires?|articles? similaires?|vous aimerez aussi|recommandations?|suggestions?(?: pour vous)?|offres? sur ce produit|les internautes ont (?:aussi|egalement) (?:achete|consulte)|les clients? ont (?:aussi|egalement) achete|frequently bought(?: together)?|customers? also bought|completez (?:votre )?(?:achat|commande))$/i.test(normalize(t));
          const anchor=headingLike.find(h=>isDescription(h.textContent));
          if(!anchor) return null;
          const anchorIndex=headingLike.indexOf(anchor);
          const boundary=headingLike.slice(anchorIndex+1).find(h=>isBoundary(h.textContent));
          try{
            const range=document.createRange();
            range.setStartAfter(anchor);
            if(boundary) range.setEndBefore(boundary); else {const owner=start.closest('main,[role=\"main\"],article');const terminal=owner?.querySelector('footer,[role=\"contentinfo\"],nav');if(terminal) range.setEndBefore(terminal); else if(owner&&owner.lastChild) range.setEndAfter(owner.lastChild); else return null;}
            const frag=range.cloneContents();
            const html=merchantSafeHtml(serializeFragment(frag).trim(),'description');
            const text=clean((()=>{const x=document.createElement('div');x.innerHTML=html;return x.textContent||''})());
            if(text.length<80||text.length>50000||html.length>700000) return null;
            return {html,meta:{strategy:'heading-range',anchor:clean(anchor.textContent),boundary:boundary?clean(boundary.textContent):'',text_length:text.length,...structuralCount(html)}};
          }catch{return null;}
        };
        const pruneCommerceTail=html=>{
          const box=document.createElement('div'); box.innerHTML=String(html||'');
          const boundaryText=t=>/^(?:produits? similaires?|articles? similaires?|vous aimerez aussi|recommandations?|suggestions?(?: pour vous)?|les internautes ont (?:aussi|egalement) (?:achete|consulte)|les clients? ont (?:aussi|egalement) achete|frequently bought(?: together)?|customers? also bought|completez (?:votre )?(?:achat|commande))$/i.test(normalize(t));
          const candidates=[...box.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"],p')];
          const stop=candidates.find(el=>boundaryText(el.textContent)&&clean(el.textContent).length<=140);
          if(stop){
            let current=stop;
            while(current&&current!==box){
              const parent=current.parentNode;
              let sibling=current.nextSibling;
              while(sibling){const next=sibling.nextSibling;sibling.remove();sibling=next;}
              if(current===stop)current.remove();
              current=parent;
            }
          }
          box.querySelectorAll('li').forEach(li=>{if(!clean(li.textContent))li.remove()});
          box.querySelectorAll('ul,ol').forEach(list=>{if(!clean(list.textContent))list.remove()});
          return box.innerHTML.trim();
        };
        const captureBySelector=()=>{
          const selectors=['[itemprop="description"]','[data-testid*="description" i]','[class*="product-description" i]','[id*="product-description" i]','section[class*="description" i]','div[class*="description" i]'];
          const seen=new Set();
          const candidates=[];
          selectors.forEach(selector=>document.querySelectorAll(selector).forEach(el=>{
            if(seen.has(el)||!visible(el))return; seen.add(el);
            const text=clean(el.textContent);
            if(text.length<80||text.length>50000)return;
            let score=Math.min(text.length,12000);
            if(/fonctionnalit|specification|caracteristique|technical|feature/i.test(normalize(text)))score+=2500;
            if(el.matches('[itemprop="description"]'))score+=3000;
            candidates.push({el,text,score});
          }));
          candidates.sort((a,b)=>b.score-a.score);
          const best=candidates[0]; if(!best)return null;
          const html=merchantSafeHtml(pruneCommerceTail(best.el.innerHTML.trim()),'description');
          if(!html||html.length>700000)return null;
          return {html,meta:{strategy:'selector',selector_hint:best.el.getAttribute('itemprop')?'itemprop=description':best.el.tagName.toLowerCase(),text_length:best.text.length,...structuralCount(html)}};
        };
        const isPriceBoundaryHeading=t=>/^(?:produit(?:s)? similaire(?:s)?(?: livre(?:s)? par)?|articles? similaires?|vous aimerez aussi|recommandations?|suggestions?(?: pour vous)?|sponsorise|sponsored|autres offres?|offres d'occasion|occasion|reconditionne|frequently bought(?: together)?|customers? also bought)$/i.test(normalize(t));
        const priceBoundaryOwner=el=>{
          let cur=el;
          for(let depth=0;cur&&cur!==document.body&&depth<7;depth++,cur=cur.parentElement){
            const headings=[...cur.querySelectorAll(':scope > h1,:scope > h2,:scope > h3,:scope > h4,:scope > h5,:scope > h6,:scope > [role="heading"]')];
            if(headings.some(h=>isPriceBoundaryHeading(h.textContent)))return cur;
            const own=clean(cur.childNodes?.length===1?cur.textContent:'');
            if(own.length>0&&own.length<180&&isPriceBoundaryHeading(own))return cur;
          }
          return null;
        };
        const parseMoneyText=text=>{
          const raw=clean(text).replace(/\u00a0/g,' ');
          const out=[];
          const re=/(?:^|[^\d])(\d{1,4}(?:[ .]\d{3})*)(?:\s*[,\.]\s*(\d{2}))?\s*€/g;
          let m;
          while((m=re.exec(raw))){
            const whole=(m[1]||'').replace(/[ .]/g,'');
            const cents=m[2]||'00';
            const value=Number(`${whole}.${cents}`);
            if(Number.isFinite(value)&&value>0&&value<100000)out.push({value,text:clean(m[0])});
          }
          return out;
        };
        const splitMoneyFromElement=el=>{
          if(!(el instanceof Element)||!visible(el))return [];
          const children=[...el.children].filter(visible);
          const vals=[];
          for(let i=0;i<children.length-1;i++){
            const a=clean(children[i].textContent),b=clean(children[i+1].textContent);
            let ma=a.match(/^(\d{2,5})$/), mb=b.match(/^(?:0\s*)?[,\.]\s*(\d{2})\s*€?$/);
            if(ma&&mb){vals.push({value:Number(`${ma[1]}.${mb[1]}`),text:`${ma[1]},${mb[1]} €`,strategy:'split-child-cents'});continue;}
            ma=a.match(/^(\d{2,5})$/); mb=b.match(/^(\d{2})\s*€$/);
            if(ma&&mb){vals.push({value:Number(`${ma[1]}.${mb[1]}`),text:`${ma[1]},${mb[1]} €`,strategy:'split-child-digits'});}
          }
          const txt=clean(el.textContent);
          let m=txt.match(/(?:^|\s)(\d{2,5})\s+(?:0\s*)?[,\.]\s*(\d{2})\s*€/);
          if(m)vals.push({value:Number(`${m[1]}.${m[2]}`),text:`${m[1]},${m[2]} €`,strategy:'split-text-cents'});
          return vals.filter(v=>Number.isFinite(v.value)&&v.value>0&&v.value<100000);
        };
        const structuredProductOfferPrice=()=>{
          const vals=[];
          const visit=node=>{
            if(!node)return;
            if(Array.isArray(node)){node.forEach(visit);return;}
            if(typeof node!=='object')return;
            const type=String(node['@type']||'').toLowerCase();
            if(type==='product'){
              const offers=Array.isArray(node.offers)?node.offers:[node.offers].filter(Boolean);
              offers.forEach(off=>{
                if(!off||typeof off!=='object')return;
                const raw=off.price ?? off.lowPrice ?? off.priceSpecification?.price;
                const v=Number(String(raw??'').replace(/\s/g,'').replace(',','.'));
                if(Number.isFinite(v)&&v>0&&v<100000)vals.push(v);
              });
            }
            Object.values(node).forEach(visit);
          };
          document.querySelectorAll('script[type="application/ld+json"]').forEach(sc=>{try{visit(JSON.parse(sc.textContent||''));}catch{}});
          return vals.length?vals[0]:null;
        };
        const ancillaryMoneyPattern=/(?:par mois|\/mois|mensualit|alma|financement|paiement en|x\s*\d+|\d+\s*x|puis|livraison|eco[- ]?participation|occasion|abonnement|subscription|premier mois|1er mois|3 mois|canal\+|deezer|service partenaire|offre partenaire|acompte|deposit|frais|shipping|taeg|cr[eé]dit)/i;
        const capturePrimaryPrice=()=>{
          const h1=[...document.querySelectorAll('h1')].find(visible)||null;
          const buyControls=[...document.querySelectorAll('button,a,[role="button"]')].filter(el=>visible(el)&&/(ajouter au panier|add to cart|acheter|buy now)/i.test(normalize(el.textContent))).slice(0,8);
          const zones=[];
          const addZone=(el,weight)=>{if(!el||zones.some(z=>z.el===el))return;zones.push({el,weight});};
          buyControls.forEach(btn=>{let cur=btn;for(let d=0;cur&&cur!==document.body&&d<6;d++,cur=cur.parentElement){const t=clean(cur.textContent);if(t.length<25000)addZone(cur,120-d*8);}});
          if(h1){let cur=h1;for(let d=0;cur&&cur!==document.body&&d<5;d++,cur=cur.parentElement){const t=clean(cur.textContent);if(t.length<30000)addZone(cur,70-d*6);}}
          addZone(document.body,5);
          const seen=new Set(),candidates=[];
          for(const zone of zones){
            const nodes=[zone.el,...zone.el.querySelectorAll('[itemprop="price"],[content][itemprop*="price" i],[data-price],[data-testid*="price" i],[class*="price" i],span,div,p,strong')];
            for(const el of nodes){
              if(!(el instanceof Element)||seen.has(el)||!visible(el))continue;seen.add(el);
              if(priceBoundaryOwner(el))continue;
              const text=clean(el.textContent);
              if(!text||text.length>800)continue;
              const style=getComputedStyle(el);
              const struck=/line-through/.test(style.textDecorationLine||style.textDecoration||'');
              const rect=el.getBoundingClientRect();
              let proximity=0;
              if(buyControls[0]){const b=buyControls[0].getBoundingClientRect();proximity=Math.max(0,1600-Math.hypot(rect.left-b.left,rect.top-b.top));}
              const font=Math.min(80,parseFloat(style.fontSize)||0);
              const explicit=el.matches('[itemprop="price"],[data-price],[data-testid*="price" i],[class*="price" i]')?35:0;
              const amounts=parseMoneyText(text).map(x=>({...x,strategy:'money-text'}));
              const split=splitMoneyFromElement(el);
              const context=clean([text,el.parentElement?.textContent||'',el.parentElement?.parentElement?.textContent||''].join(' ')).slice(0,1800);
              const ancillary=ancillaryMoneyPattern.test(normalize(context));
              for(const a of [...split,...amounts]){
                const currencyAtomic=/€/.test(a.text||text);
                const nearBuybox=proximity>250;
                let score=zone.weight+proximity/20+font*2+explicit+(a.strategy.startsWith('split-')?55:0)-(struck?220:0);
                if(ancillary)score-=1200;
                if(a.value<20)score-=260;
                const eligible=Boolean(explicit>0&&currencyAtomic&&nearBuybox&&!ancillary&&!struck);
                candidates.push({amount:a.value,score,strategy:a.strategy,text:a.text,context,tag:el.tagName.toLowerCase(),explicit_price_role:explicit>0,currency_atomic:currencyAtomic,near_buybox:nearBuybox,semantic_role:ancillary?'ancillary_money':'product_price_candidate',eligible});
              }
            }
          }
          candidates.sort((a,b)=>b.score-a.score);
          const structured=structuredProductOfferPrice();
          const host=location.hostname.toLowerCase();
          const eligibleCandidates=candidates.filter(c=>c.eligible);
          let best=eligibleCandidates[0]||null;
          if(Number.isFinite(structured)&&structured>0){
            const structuredCandidate={amount:structured,score:1200,strategy:'json-ld-product-offer',text:String(structured),context:'structured Product Offer',tag:'json-ld',explicit_price_role:true,currency_atomic:true,near_buybox:true,semantic_role:'product_price',eligible:true};
            if(!best) best=structuredCandidate;
            else {
              const delta=Math.abs(best.amount-structured)/Math.max(0.01,structured);
              if(delta>0.03) best=structuredCandidate;
            }
          }
          // Atomic Money Authority v3: a tiny number may be a rating, eco-fee,
          // instalment or CTA fragment. It may represent a product price only when
          // an explicit price role or an independent structured Product Offer corroborates it.
          if(best && best.amount < 20){
            const structuredNear=Number.isFinite(structured) && Math.abs(structured-best.amount)/Math.max(0.01,structured) <= 0.03;
            const independent=candidates.filter(c=>c!==best&&Math.abs(c.amount-best.amount)/Math.max(0.01,best.amount)<=0.03&&c.currency_atomic&&c.explicit_price_role&&c.near_buybox);
            const crossStrategy=independent.some(c=>c.strategy!==best.strategy);
            // Tiny prices are legitimate, but they need independent product-money proof.
            // A lone CTA fragment (field regression: 2.30 EUR on AEG ManoMano) is fail-closed.
            if(!structuredNear && !crossStrategy){
              best=null;
            }
          }
          // Product Price Evidence Contract v3 is marketplace-agnostic: structured Product Offer
          // and eligible visible buy-box price are the only terminal lanes. Ancillary money never enters the final set.
          if(!best||best.score<80)return {amount:null,strategy:'none',candidates:candidates.slice(0,8),price_truth_certificate:{version:'product-price-evidence-contract-v3',locked:false,reason:'no_eligible_product_price_evidence'},product_price_contract:{version:'product-price-evidence-contract-v3',status:'rejected',semantic_role:'unknown',authoritative_price:null,reason:'no_eligible_product_price_evidence'}};
          const authoritativePrice=Number(best.amount.toFixed(2));
          const contract={version:'product-price-evidence-contract-v3',status:'certified',semantic_role:'product_price',authoritative_price:authoritativePrice,source:best.strategy,corroboration:[best.strategy,Number.isFinite(structured)&&Math.abs(structured-authoritativePrice)/Math.max(0.01,authoritativePrice)<=0.03?'json-ld-product-offer':null].filter(Boolean)};
          return {amount:authoritativePrice,strategy:`bridge-primary-product-zone-v1:${best.strategy}`,candidates:candidates.slice(0,8),price_truth_certificate:{version:'product-price-evidence-contract-v3',locked:true,amount:authoritativePrice,source:best.strategy,atomic_currency:Boolean(best.currency_atomic),explicit_price_role:Boolean(best.explicit_price_role),near_buybox:Boolean(best.near_buybox)},product_price_contract:contract};
        };
        const buildExactMainPriceConsensus=(zone)=>{
          const structured=structuredProductOfferPrice();
          const z=Number(zone?.amount);
          const candidates=[];
          if(Number.isFinite(z)&&z>0)candidates.push({amount:z,role:'exact-product-zone',authority:100,source:zone.strategy});
          if(Number.isFinite(structured)&&structured>0)candidates.push({amount:structured,role:'structured-product-offer',authority:96,source:'json-ld-product-offer'});
          let winner=candidates[0]||null;
          if(candidates.length===2){
            const ratio=Math.max(candidates[0].amount,candidates[1].amount)/Math.max(0.01,Math.min(candidates[0].amount,candidates[1].amount));
            if(ratio<1.08)winner={...candidates[0],authority:100,consensus:true};
            else if(candidates[0].amount<20&&candidates[1].amount>=50)winner=candidates[1];
          }
          return {version:'exact-main-price-consensus-v2',winner,candidates,ancillary_price_rejection:true};
        };
        const captureIdentityEvidence=()=>{
          const h1=[...document.querySelectorAll('h1')].find(visible);
          const breadcrumbs=[...document.querySelectorAll('nav[aria-label*="breadcrumb" i] a,[class*="breadcrumb" i] a,[data-testid*="breadcrumb" i] a')]
            .filter(visible).map(el=>clean(el.textContent)).filter(Boolean).slice(0,12);
          const slugTitle=(()=>{try{let s=decodeURIComponent(new URL(location.href).pathname.split('/').filter(Boolean).pop()||'');s=s.replace(/-\d{6,}$/,'').replace(/[-_]+/g,' ').trim();return s.split(/\s+/).map(w=>/[a-z]/i.test(w)&&/\d/.test(w)?w.toUpperCase():w).join(' ');}catch{return'';}})();
          const titleCandidates=[clean(h1?.textContent||''),clean(breadcrumbs[breadcrumbs.length-1]||''),clean(document.title||''),clean(slugTitle)].filter(Boolean);
          const urlNorm=normalize(decodeURIComponent(location.pathname).replace(/[-_/]+/g,' '));
          const semanticTokens=s=>normalize(s).split(/\s+/).filter(x=>x.length>=3&&!/^\d+$/.test(x));
          const scoreTitle=s=>{const toks=semanticTokens(s);if(!toks.length)return-999;const hits=toks.filter(x=>urlNorm.includes(x)).length;let score=(hits/toks.length)*100; if(/[a-z].*\d|\d.*[a-z]/i.test(s))score+=15; if(s.length>180)score-=20; return score;};
          titleCandidates.sort((a,b)=>scoreTitle(b)-scoreTitle(a));
          const titleText=titleCandidates[0]||clean(document.title||'');
          const explicitBrand=[];
          document.querySelectorAll('[itemprop="brand"],meta[itemprop="brand"],[data-brand],[class*="brand" i]').forEach(el=>{
            const v=clean(el.getAttribute?.('content')||el.getAttribute?.('data-brand')||el.textContent||'');
            if(v&&v.length<=80)explicitBrand.push(v);
          });

          // Multi-evidence visual identity lane. We only inspect imagery that is close to the
          // product title / main product gallery and collect text genuinely attached to those
          // images: alt/title/aria labels, filenames, figure captions and visible overlays.
          const technologyTerms=new Set([
            'tv','television','televiseur','oled','qled','neo','mini','micro','led','lcd','uhd','fhd','hd','4k','8k','hdr','hdr10','smart',
            'wifi','bluetooth','robot','tondeuse','vae','vtt','ebike','bike','batterie','gaming','premium','pro','plus','max','ultra',
            'quantum','dot','ai','ia','nq4','smarttv','display','screen','ecran','écran','mini-led','neo-qled',
            'lave','vaisselle','lave-vaisselle','dishwasher','encastrable','pose','libre','lave-linge','seche-linge','réfrigérateur','refrigerateur','congélateur','congelateur','four','micro-ondes','aspirateur','hotte'
          ]);
          const technology=/^(?:oled|qled|neo qled|mini led|micro led|led|lcd|uhd|fhd|hd|4k|8k|hdr\d*|smart tv|wifi|wi-?fi|bluetooth|robot|tondeuse|vae|vtt|ebike|e-bike|batterie|gaming|premium|pro|plus|max|ultra)$/i;
          const cleanVisualToken=v=>clean(v).replace(/[®™©]/g,'').replace(/[_+]+/g,' ').trim();
          const isTechnologyPhrase=v=>{
            const n=normalize(cleanVisualToken(v)).replace(/[^a-z0-9à-ÿ]+/gi,' ').trim();
            if(!n)return true;
            if(technology.test(n)||/^(?:lave|vaisselle|dishwasher|encastrable|lave linge|lave-vaisselle|seche linge|seche-linge|refrigerateur|congelateur|four|micro ondes|aspirateur|hotte)$/i.test(n))return true;
            const parts=n.split(/\s+/).filter(Boolean);
            if(!parts.length)return true;
            const genericCount=parts.filter(p=>technologyTerms.has(p)).length;
            // Reject composite phrases made entirely (or almost entirely) of display/product technology words:
            // "Neo QLED Mini LED", "Quantum Mini LED", "Smart TV OLED", etc.
            if(genericCount===parts.length)return true;
            if(parts.length>=2 && genericCount>=parts.length-1 && /(?:oled|qled|led|lcd|uhd|hdr|smart|quantum|mini|neo)/i.test(n))return true;
            return false;
          };
          const plausibleBrand=v=>{
            const x=cleanVisualToken(v);
            if(!x||x.length<2||x.length>48||isTechnologyPhrase(x))return '';
            if(/^(?:img|image|photo|product|produit|main|front|back|side|view|vue|zoom|large|small|thumb|thumbnail|gallery|galerie|media|webp|jpeg|jpg|png|avif)$/i.test(normalize(x)))return '';
            if(/^\d+(?:cm|mm|kg|g|w|v|ah|mah|hz|gb|tb)?$/i.test(x))return '';
            return x;
          };
          const tokeniseBrandText=text=>{
            const out=[];
            for(const raw of clean(text).split(/[\s\-–—|:;,/()\[\]{}<>]+/)){
              const t=plausibleBrand(raw.replace(/^[^\p{L}0-9&+'’]+|[^\p{L}0-9&+'’.-]+$/gu,''));
              if(!t)continue;
              const shape=t===t.toUpperCase()||/^[A-ZÀ-ÖØ-Þ][\p{Ll}0-9&+'’.-]*$/u.test(t)||/[A-Z].*[A-Z]/.test(t);
              if(shape)out.push(t);
            }
            return [...new Set(out)].slice(0,12);
          };
          const mainImageCandidates=[...document.querySelectorAll('img')].filter(img=>{
            if(!visible(img))return false;
            const r=img.getBoundingClientRect();
            if(r.width<90||r.height<90)return false;
            if(h1){
              const hr=h1.getBoundingClientRect();
              const distance=Math.hypot(r.left-hr.left,r.top-hr.top);
              if(distance<1800)return true;
            }
            const parent=img.closest('[class*="gallery" i],[class*="carousel" i],[class*="product" i],[data-testid*="gallery" i],[data-testid*="product" i],figure');
            return !!parent;
          }).slice(0,40);
          const imageAltHints=[],imageTextHints=[],imageBrandCandidates=[],ocrImageCandidates=[];
          for(const img of mainImageCandidates){
            const alt=clean(img.getAttribute('alt')||'');
            const title=clean(img.getAttribute('title')||'');
            const aria=clean(img.getAttribute('aria-label')||'');
            const src=clean(img.currentSrc||img.src||'');
            const rect=img.getBoundingClientRect();
            if(src && /^https?:/i.test(src)){
              const area=Math.max(0,rect.width)*Math.max(0,rect.height);
              const ownerHint=img.closest('[class*="gallery" i],[class*="carousel" i],[class*="product" i],[data-testid*="gallery" i],[data-testid*="product" i],figure')?250000:0;
              ocrImageCandidates.push({src:src.slice(0,1200),width:Math.round(rect.width),height:Math.round(rect.height),score:Math.round(area+ownerHint),alt:clean(img.getAttribute('alt')||'').slice(0,180)});
            }
            let filename='';
            try{filename=decodeURIComponent(new URL(src,location.href).pathname.split('/').pop()||'').replace(/\.[a-z0-9]{2,5}$/i,'').replace(/[-_]+/g,' ');}catch{}
            const fig=img.closest('figure');
            const caption=clean(fig?.querySelector('figcaption')?.textContent||'');
            const owner=img.closest('[class*="gallery" i],[class*="carousel" i],[class*="product" i],figure,li,div');
            const overlay=[...((owner||img.parentElement)?.querySelectorAll?.('span,strong,b,small,[aria-label]')||[])]
              .filter(el=>visible(el)).map(el=>clean(el.getAttribute('aria-label')||el.textContent)).filter(t=>t&&t.length<=120).slice(0,8).join(' ');
            for(const text of [alt,title,aria,filename,caption,overlay]){
              if(!text||text.length>220)continue;
              imageTextHints.push(text);
              imageBrandCandidates.push(...tokeniseBrandText(text));
            }
            if(alt&&alt.length<=180)imageAltHints.push(alt);
          }

          // Explicit brand labels in the page body are captured separately from ordinary nouns.
          const textProbe=clean(document.body?.innerText||'').slice(0,60000);
          const labelled=/\b(?:marque|brand|fabricant|manufacturer)\s*[:\-]\s*([\p{L}][\p{L}0-9&+'’ .-]{1,48})/giu;
          let match;
          while((match=labelled.exec(textProbe))&&explicitBrand.length<20){
            const candidate=plausibleBrand((match[1]||'').split(/[|;,]/)[0]);
            if(candidate)explicitBrand.push(candidate);
          }

          const safeExplicit=[...new Set(explicitBrand.map(plausibleBrand).filter(Boolean))].slice(0,20);
          const safeImageBrands=[...new Set(imageBrandCandidates.map(plausibleBrand).filter(Boolean))].slice(0,30);

          // Cross-lane consensus: a candidate occurring in the title and in image metadata/text
          // receives a dedicated high-authority visual/text corroboration lane.
          const titleBrands=tokeniseBrandText(titleText).map(plausibleBrand).filter(Boolean);
          const titleNorm=normalize(titleText);
          const imageNorm=normalize(imageTextHints.join(' '));
          const consensus=[];
          for(const candidate of [...titleBrands,...safeImageBrands]){
            const c=plausibleBrand(candidate);
            if(!c)continue;
            const cn=normalize(c);
            if(cn && titleNorm.includes(cn) && imageNorm.includes(cn)) consensus.push(c);
          }

          const taxonomyHints=[];
          const taxProbe=normalize([titleText,...breadcrumbs].join(' '));
          if(/lave\s*vaisselle|dishwasher/i.test(taxProbe))taxonomyHints.push('Électroménager','Gros électroménager','Lave-vaisselle');
          if(/lave\s*linge|machine\s+a\s+laver|washing machine/i.test(taxProbe))taxonomyHints.push('Électroménager','Gros électroménager','Lave-linge');
          if(/seche\s*linge|tumble dryer/i.test(taxProbe))taxonomyHints.push('Électroménager','Gros électroménager','Sèche-linge');
          if(/refrigerateur|frigo|refrigerator/i.test(taxProbe))taxonomyHints.push('Électroménager','Gros électroménager','Réfrigérateurs');
          if(/congelateur|freezer/i.test(taxProbe))taxonomyHints.push('Électroménager','Gros électroménager','Congélateurs');

          return {
            version:'h5q7-bridge-identity-evidence-v4',
            title:titleText,
            breadcrumbs:[...new Set(breadcrumbs)],
            taxonomy_hints:[...new Set(taxonomyHints)],
            explicit_brand_candidates:safeExplicit,
            image_alt_hints:[...new Set(imageAltHints)].slice(0,30),
            image_text_hints:[...new Set(imageTextHints)].slice(0,30),
            image_brand_candidates:safeImageBrands,
            visual_text_brand_consensus:[...new Set(consensus)].slice(0,12),
            ocr_image_candidates:[...ocrImageCandidates].sort((a,b)=>b.score-a.score).filter((v,i,a)=>a.findIndex(x=>x.src===v.src)===i).slice(0,12),
            image_ocr_text:[],
            ocr_brand_candidates:[],
            visual_ocr_brand_consensus:[],
            rejected_technology_brand_phrases:true,
            visual_evidence_strategy:'product-gallery-metadata-caption-overlay-cross-lane-consensus-v3+pixel-ocr-v1',
            visual_evidence_non_ocr:false,
            ocr_status:'pending_pixel_ocr',
          };
        };

        const captureSustainabilityEvidence=()=>{
          const cleanLocal=v=>String(v||'').replace(/\s+/g,' ').trim();
          const text=cleanLocal(document.body?.innerText||'').slice(0,120000);
          const normalize=v=>cleanLocal(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();

          const evidence=[];
          const add=(type,value,source,context='')=>{
            const v=cleanLocal(value);
            if(!v)return;
            evidence.push({type,value:v,source,context:cleanLocal(context).slice(0,240)});
          };

          const findEnergyClass=(sourceText,source)=>{
            const patterns=[
              /(?:classe\s+(?:énergétique|energetique|énergie|energie)|energy\s+(?:efficiency\s+)?class)\s*[:\-]?\s*([A-G](?:\+{1,3})?)(?![A-Za-z])/iu,
              /(?:étiquette\s+(?:énergie|energie)|energy\s+label)[^\n\r]{0,80}?\b([A-G](?:\+{1,3})?)\b/iu
            ];
            for(const p of patterns){
              const m=sourceText.match(p);
              if(m){add('energy_class',m[1].toUpperCase(),source,m[0]);return m[1].toUpperCase();}
            }
            return '';
          };

          const findModeEnergyClass=(sourceText,mode,source)=>{
            const mName=String(mode||'').toUpperCase();
            const rx=new RegExp('(?:classe\\s+(?:énergétique|energetique|énergie|energie)|energy\\s+(?:efficiency\\s+)?class)\\s*\\((?:mode\\s+)?'+mName+'\\)\\s*[:\\-]?\\s*([A-G](?:\\+{1,3})?)','iu');
            const m=String(sourceText||'').match(rx);
            if(!m)return '';
            const v=m[1].toUpperCase();add('energy_class_'+mName.toLowerCase(),v,source,m[0]);return v;
          };

          const findIndex=(sourceText,kind,source)=>{
            const label=kind==='durability'
              ? '(?:indice\\s+de\\s+durabilit[eé]|durability\\s+index)'
              : '(?:indice\\s+de\\s+r[eé]parabilit[eé]|repairability\\s+index)';
            const p=new RegExp(label+'\\s*[:\\-]?\\s*([0-9](?:[.,][0-9])?|10(?:[.,]0)?)\\s*(?:\\/\\s*10)?','iu');
            const m=sourceText.match(p);
            if(!m)return '';
            const n=Number(String(m[1]).replace(',','.'));
            if(!Number.isFinite(n)||n<0||n>10)return '';
            const value=(Math.round(n*10)/10).toString().replace('.',',')+' / 10';
            add(kind==='durability'?'durability_index':'repairability_index',value,source,m[0]);
            return value;
          };

          let energyClass=findEnergyClass(text,'rendered-page-text');
          let energyClassSdr=findModeEnergyClass(text,'SDR','rendered-page-text');
          let energyClassHdr=findModeEnergyClass(text,'HDR','rendered-page-text');
          let durabilityIndex=findIndex(text,'durability','rendered-page-text');
          let repairabilityIndex=findIndex(text,'repairability','rendered-page-text');

          // Search label-centric DOM zones. This is stronger than a full-page regex because
          // icons and image labels are commonly rendered next to a short text value.
          const labelRx=/(classe\s+(?:énergétique|energetique|énergie|energie)|energy\s+(?:efficiency\s+)?class|indice\s+de\s+durabilit[eé]|durability\s+index|indice\s+de\s+r[eé]parabilit[eé]|repairability\s+index)/iu;
          for(const el of [...document.querySelectorAll('body *')].filter(visible).slice(0,8000)){
            const own=cleanLocal(el.getAttribute?.('aria-label')||el.getAttribute?.('title')||el.textContent||'');
            if(!own||own.length>500||!labelRx.test(own))continue;
            const zone=el.closest('section,article,li,div,figure,td,tr,dl')||el.parentElement||el;
            const zoneText=cleanLocal(zone.textContent||'').slice(0,1200);
            if(!energyClass)energyClass=findEnergyClass(zoneText,'label-zone-text');
            if(!energyClassSdr)energyClassSdr=findModeEnergyClass(zoneText,'SDR','label-zone-text');
            if(!energyClassHdr)energyClassHdr=findModeEnergyClass(zoneText,'HDR','label-zone-text');
            if(!durabilityIndex)durabilityIndex=findIndex(zoneText,'durability','label-zone-text');
            if(!repairabilityIndex)repairabilityIndex=findIndex(zoneText,'repairability','label-zone-text');
            if(energyClass&&durabilityIndex&&repairabilityIndex)break;
          }

          // Image/icon evidence: alt/title/aria/filename/caption/nearby text.
          // This is safe visual metadata reading; no unverified OCR value is trusted alone.
          const imageHints=[];
          for(const img of [...document.images].filter(visible).slice(0,120)){
            const src=cleanLocal(img.currentSrc||img.src||'');
            let filename='';
            try{filename=decodeURIComponent(new URL(src,location.href).pathname.split('/').pop()||'');}catch{}
            const zone=img.closest('figure,section,article,li,div')||img.parentElement;
            const payload=cleanLocal([
              img.alt||'',img.title||'',img.getAttribute('aria-label')||'',filename,
              zone?.querySelector?.('figcaption')?.textContent||'',
              zone?.textContent||''
            ].join(' ')).slice(0,1800);
            if(!/(energie|énergie|energy|durabil|repair|reparab|réparab|classe\s*[a-g])/iu.test(payload))continue;
            imageHints.push({src:src.slice(0,600),text:payload.slice(0,700)});
            if(!energyClass)energyClass=findEnergyClass(payload,'product-image-metadata');
            if(!energyClassSdr)energyClassSdr=findModeEnergyClass(payload,'SDR','product-image-metadata');
            if(!energyClassHdr)energyClassHdr=findModeEnergyClass(payload,'HDR','product-image-metadata');
            if(!durabilityIndex)durabilityIndex=findIndex(payload,'durability','product-image-metadata');
            if(!repairabilityIndex)repairabilityIndex=findIndex(payload,'repairability','product-image-metadata');
          }

          const findOperationalEnergyPair=(sourceText)=>{
            const s=cleanLocal(sourceText||'');
            const patterns=[
              /classe\s+(?:d[’']?efficacit[eé]\s+)?[eé]nerg[eé]tique\s*[:\-]?\s*([A-G](?:\+{1,3})?)\s+(?:en\s+)?refroidissement\s*[,;\/]?\s*(?:et\s*)?([A-G](?:\+{1,3})?)\s+(?:en\s+)?chauffage/iu,
              /energy\s+(?:efficiency\s+)?class\s*[:\-]?\s*([A-G](?:\+{1,3})?)\s+(?:in\s+)?cooling\s*[,;\/]?\s*(?:and\s*)?([A-G](?:\+{1,3})?)\s+(?:in\s+)?heating/iu
            ];
            for(const rx of patterns){const m=s.match(rx);if(m)return{cooling:m[1].toUpperCase(),heating:m[2].toUpperCase(),source:'exact-labeled-operational-pair'};}
            const productTitle=cleanLocal(document.querySelector('h1')?.textContent||'');
            if(/(?:climatiseur|climatisation|air\s*conditioner|heat\s*pump)/iu.test(productTitle)){
              const m=productTitle.match(/\b([A-G](?:\+{1,3})?)\s*\/\s*([A-G](?:\+{1,3})?)\b/i);
              if(m)return{cooling:m[1].toUpperCase(),heating:m[2].toUpperCase(),source:'hvac-title-pair'};
            }
            return{cooling:'',heating:'',source:''};
          };
          const operationalPair=findOperationalEnergyPair(text);
          const defaultEnergyClass=(operationalPair.cooling&&operationalPair.heating)?`${operationalPair.cooling} / ${operationalPair.heating}`:(energyClassSdr||energyClass||'');
          const energyTruthCertificate={
            version:'energy-truth-certificate-v2-labeled-pair',
            default_class:defaultEnergyClass,
            sdr_class:energyClassSdr||'',
            hdr_class:energyClassHdr||'',
            cooling_class:operationalPair.cooling||'',
            heating_class:operationalPair.heating||'',
            default_role:operationalPair.cooling?'operational_multimode':(energyClassSdr?'sdr_explicit':(energyClass?'generic_product_class':'')),
            cross_mode_vote_weight:0,
            scale_bound_vote_weight:0,
            identity_url:location.href,
            source:'browser-rendered-product-zone',
            invariant:'default/generic and HDR are distinct facts; HDR never overrides generic/default',
            confidence:defaultEnergyClass?1:0
          };
          return {
            version:'h5q7-sustainability-evidence-v3-energy-truth-certificate',
            energy_class:defaultEnergyClass,
            energy_class_sdr:energyClassSdr||'',
            energy_class_hdr:energyClassHdr||'',
            energy_class_cooling:operationalPair.cooling||'',
            energy_class_heating:operationalPair.heating||'',
            energy_truth_certificate:energyTruthCertificate,
            durability_index:durabilityIndex||'',
            repairability_index:repairabilityIndex||'',
            evidence:evidence.slice(0,20),
            image_hints:imageHints.slice(0,12),
            visual_strategy:'rendered-text-label-zone-image-metadata-v1',
            ocr_status:'not_required_unless_metadata_and_rendered_text_are_insufficient'
          };
        };

        const captureGalleryCompleteness=(descriptionHtml='')=>{
          const canonical=u=>{
            try{
              const x=new URL(String(u||''),location.href);
              ['w','h','width','height','fit','crop','quality','q','format','fm','auto'].forEach(k=>x.searchParams.delete(k));
              return x.href;
            }catch{return String(u||'').trim();}
          };
          const urls=new Map();
          const add=(u,source)=>{
            const raw=String(u||'').trim();if(!/^https?:/i.test(raw))return;
            const key=canonical(raw);if(!key)return;
            if(!urls.has(key))urls.set(key,{url:raw,source});
          };
          const owners=[...document.querySelectorAll('[class*="gallery" i],[class*="carousel" i],[data-testid*="gallery" i],[aria-label*="gallery" i],[aria-label*="galerie" i],[class*="product-media" i],[data-testid*="product-media" i]')];
          for(const owner of owners.slice(0,40)){
            for(const img of owner.querySelectorAll('img')){
              add(img.currentSrc||img.src||img.getAttribute('data-src')||img.getAttribute('data-original')||img.getAttribute('data-zoom-image'),'rendered-gallery-dom');
              const srcset=img.getAttribute('srcset')||img.getAttribute('data-srcset')||'';
              for(const part of srcset.split(','))add(part.trim().split(/\s+/)[0],'rendered-gallery-srcset');
            }
          }
          if(descriptionHtml){
            const box=document.createElement('div');box.innerHTML=String(descriptionHtml);
            for(const img of box.querySelectorAll('img'))add(img.getAttribute('src')||img.getAttribute('data-src')||img.getAttribute('data-original')||img.getAttribute('data-zoom-image'),'exact-product-description');
          }
          let declared=0; const counters=[];
          const counterNodes=[...document.querySelectorAll('[class*="gallery" i],[class*="carousel" i],[aria-label*="image" i],[aria-label*="photo" i],[data-testid*="gallery" i]')].slice(0,300);
          for(const el of counterNodes){
            const t=clean([el.getAttribute?.('aria-label')||'',el.textContent||''].join(' '));
            for(const rx of [/(?:^|\s)(\d{1,2})\s*\/\s*(\d{1,2})(?:\s|$)/g,/(?:image|photo|vue)\s*\d{1,2}\s*(?:sur|of)\s*(\d{1,2})/gi]){
              let m;while((m=rx.exec(t))){const n=Number(m[2]||m[1]);if(Number.isFinite(n)&&n>declared&&n<=40){declared=n;counters.push({text:t.slice(0,120),count:n});}}
            }
          }
          const discovered=urls.size;
          const expected=Math.max(declared,discovered);
          return {
            version:'browser-gallery-completeness-v2.0.32',
            declared_count:declared,
            discovered_distinct:discovered,
            expected_count:expected,
            coverage_ratio:expected?Math.min(1,discovered/expected):0,
            recovery_required:expected>0&&discovered<expected,
            source_union:[...urls.values()].slice(0,40),
            counters:counters.slice(0,12),
            invariant:'success only when discovered_distinct >= expected_count when expected_count is known',
          };
        };

        const bridgePrimaryPrice=capturePrimaryPrice();
        // 2.0.31 hotfix: build the consensus object before it is serialized below.
        // 2.0.29/2.0.30 defined buildExactMainPriceConsensus() but never invoked it,
        // which raised a ReferenceError and surfaced as "La page capturée est vide".
        const exactMainPriceConsensus=buildExactMainPriceConsensus(bridgePrimaryPrice);
        const identityEvidence=captureIdentityEvidence();
        const sustainabilityEvidence=captureSustainabilityEvidence();
        const specificationsExpansion=await expandSpecifications();
        const specifications=captureSpecifications();
        const description=captureByHeadingRange()||captureBySelector()||{html:'',meta:{strategy:'none',text_length:0}};
        const galleryCompleteness=captureGalleryCompleteness(description.html||'');
        const clone=document.documentElement.cloneNode(true);
        applyPolicyToBox(clone);
        // Clone-only ancillary money firewall: old Cloud parsers may still scan DOM text even
        // when the Bridge supplies a certified price. Remove financing/monthly/service money
        // leaves from the transmitted snapshot so they cannot be promoted downstream.
        clone.querySelectorAll('span,div,p,strong,small,button,a').forEach(el=>{
          const txt=clean(el.textContent||''); if(!txt||txt.length>700||!/[0-9].*(?:€|eur)|(?:€|eur).*[0-9]/i.test(txt))return;
          const ctx=clean([txt,el.parentElement?.textContent||''].join(' ')).slice(0,1400);
          if(ancillaryMoneyPattern.test(normalize(ctx)) && el.childElementCount<=2){el.setAttribute('data-mace-ancillary-money','true');el.textContent='';['itemprop','content','data-price'].forEach(a=>el.removeAttribute(a));}
        });
        const productPriceContract=bridgePrimaryPrice.product_price_contract||{version:'product-price-evidence-contract-v3',status:'rejected',semantic_role:'unknown',authoritative_price:null};
        if(productPriceContract.status==='certified'){
          const cloneHead=clone.querySelector('head')||clone;
          const contractScript=document.createElement('script');contractScript.type='application/json';contractScript.id='mace-product-price-contract';contractScript.textContent=JSON.stringify(productPriceContract);cloneHead.appendChild(contractScript);
        }
        if(bridgePrimaryPrice.amount){
          clone.querySelectorAll('[itemprop="price"]').forEach(el=>{el.removeAttribute('itemprop');el.removeAttribute('content');});
          const cloneHead=clone.querySelector('head')||clone;
          const meta=document.createElement('meta');
          meta.setAttribute('itemprop','price');
          meta.setAttribute('content',String(bridgePrimaryPrice.amount));
          meta.setAttribute('data-mace-bridge-primary-price','true');
          meta.setAttribute('data-mace-price-authority',bridgePrimaryPrice.strategy);
          cloneHead.insertBefore(meta,cloneHead.firstChild||null);
        }
        const sustainabilityRows=[];
        if(sustainabilityEvidence.energy_class) sustainabilityRows.push(`<dt>Classe énergétique</dt><dd>${sustainabilityEvidence.energy_class}</dd>`);
        if(sustainabilityEvidence.durability_index) sustainabilityRows.push(`<dt>Indice de durabilité</dt><dd>${sustainabilityEvidence.durability_index}</dd>`);
        if(sustainabilityEvidence.repairability_index) sustainabilityRows.push(`<dt>Indice de réparabilité</dt><dd>${sustainabilityEvidence.repairability_index}</dd>`);
        const sustainabilityHtml=sustainabilityRows.length?`<section data-mace-sustainability-evidence="v1"><h3>Informations environnementales</h3><dl>${sustainabilityRows.join('')}</dl></section>`:'';
        const renderedDescriptionHtmlWithSustainability=(description.html||'')+sustainabilityHtml;
        const enrichedSpecificationsHtml=(specifications.html||'')+sustainabilityHtml;
        if(enrichedSpecificationsHtml){
          const marker=document.createElement('section');
          marker.setAttribute('data-mace-bridge-capture','specifications');
          marker.innerHTML='<h2>Caractéristiques</h2>'+enrichedSpecificationsHtml;
          const cloneBody=clone.querySelector('body')||clone;
          cloneBody.appendChild(marker);
        }
        return {
          html:clone.outerHTML,
          url:location.href,
          title:document.title,
          rendered_description_html:renderedDescriptionHtmlWithSustainability,
          rendered_description_meta:description.meta,
          rendered_specifications_html:enrichedSpecificationsHtml,
          rendered_specifications_meta:{...specifications.meta,expanded:specificationsExpansion.expanded,expansion_control:specificationsExpansion.control},
          rendered_primary_price:exactMainPriceConsensus?.winner?.amount??bridgePrimaryPrice.amount,
          rendered_primary_price_meta:{
            strategy:exactMainPriceConsensus?.winner?.source??bridgePrimaryPrice.strategy,
            candidates:bridgePrimaryPrice.candidates,
            authority_class:exactMainPriceConsensus?.winner?.role??'exact-product-zone',
            non_product_service_filter:'v3',
            exact_main_price_consensus:exactMainPriceConsensus
          },
          rendered_identity_evidence:identityEvidence,
          source_title_certificate:{version:'source-title-identity-authority-v2',visible_h1:identityEvidence?.title||'',document_title:document.title||'',page_lang:document.documentElement?.lang||'',url:location.href,locked:Boolean(identityEvidence?.title),source:'url-overlap-ranked-visible-product-title'},
          price_truth_certificate:bridgePrimaryPrice.price_truth_certificate||exactMainPriceConsensus?.price_truth_certificate||null,
          product_price_contract:bridgePrimaryPrice.product_price_contract||null,
          rendered_sustainability_evidence:sustainabilityEvidence,
          rendered_gallery_completeness:galleryCompleteness,
          browser_runtime_identity_certificate:{...bridgeRuntimeIdentityCertificate,captured_at:new Date().toISOString()},
        };
      },
      args:[filterPolicy]
    });

    // 2.0.31 capture resilience: recover with a minimal DOM snapshot if the rich capture
    // unexpectedly returns no serializable HTML. The fallback is recovery-only and does
    // not override price/brand/category authority by itself.
    let result=primaryResult;
    if(!result || !String(result.html||'').trim() || String(result.html||'').length<120){
      msg('Capture principale incomplète · activation du fallback DOM…');
      const [{result:fallbackResult}]=await chrome.scripting.executeScript({
        target:{tabId:tab.id},
        func:()=>{
          const clean=v=>String(v??'').replace(/[\p{Cf}\u00AD]+/gu,' ').replace(/\s+/g,' ').trim();
          const norm=v=>clean(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
          const letter=v=>{const m=clean(v).toUpperCase().match(/(?:^|\b)([A-G])(?:\b|$)/);return m?m[1]:'';};
          const roleOf=label=>{const n=norm(label);if(!/(classe|energy|energet)/.test(n))return'none';if(/(?:max|min|maximum|minimum|echelle|scale|plage|range)/.test(n))return'bound';if(/\bhdr\b/.test(n))return'hdr';if(/\bsdr\b/.test(n))return'sdr';if(/classe.*energet|energy.*class/.test(n))return'default';return'none';};
          const pairs=[];
          const add=(label,value,source)=>{const role=roleOf(label),v=letter(value);if(role==='none'||role==='bound'||!v)return;pairs.push({label:clean(label),value:v,role,source});};
          for(const tr of document.querySelectorAll('tr')){const cells=[...tr.querySelectorAll('th,td')].map(x=>clean(x.innerText||x.textContent));if(cells.length>=2)add(cells[0],cells.slice(1).join(' '),'fallback-table-row');}
          for(const dt of document.querySelectorAll('dt')){let dd=dt.nextElementSibling;if(dd&&dd.matches('dd'))add(dt.innerText||dt.textContent,dd.innerText||dd.textContent,'fallback-dl-row');}
          const candidates=[...document.querySelectorAll('[class*="spec" i],[class*="character" i],[class*="feature" i],[data-testid*="spec" i],[data-automation-id*="spec" i]')].slice(0,800);
          for(const el of candidates){const kids=[...el.children].map(x=>clean(x.innerText||x.textContent)).filter(Boolean);if(kids.length===2)add(kids[0],kids[1],'fallback-grid-row');}
          // final textual adjacency fallback, restricted to explicit labels
          const textLines=(document.body?.innerText||'').split(/\n+/).map(clean).filter(Boolean);
          for(let i=0;i<textLines.length;i++){const role=roleOf(textLines[i]);if(role==='none'||role==='bound')continue;for(let j=i+1;j<Math.min(i+4,textLines.length);j++){const v=letter(textLines[j]);if(v){add(textLines[i],v,'fallback-text-adjacency');break;}}}
          const byRole={default:[],sdr:[],hdr:[]};for(const row of pairs){if(byRole[row.role])byRole[row.role].push(row);}
          const best=r=>byRole[r][0]?.value||'';
          const generic=best('default')||best('sdr'),sdr=best('sdr'),hdr=best('hdr');
          const html=document.documentElement?.outerHTML||'';
          const body=document.body?.innerHTML||'';
          const text=clean(document.body?.innerText||'');
          const title=document.title||'';
          const h1=[...document.querySelectorAll('h1')].map(x=>clean(x.innerText||x.textContent)).find(Boolean)||'';
          const cert={version:'energy-truth-certificate-v2-labeled-pair',default_class:generic,sdr_class:sdr,hdr_class:hdr,evidence_pairs:pairs.slice(0,80),cross_mode_vote_weight:0,scale_bound_vote_weight:0,source:'fallback-visible-product-dom',invariant:'value accepted only with co-located semantic label'};
          const specHtml=pairs.length?`<section data-mace-fallback-regulatory=\"v2\"><h2>Caractéristiques réglementaires</h2><dl>${pairs.map(r=>`<dt>${r.label.replace(/[<>&]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]))}</dt><dd>${r.value}</dd>`).join('')}</dl></section>`:'';
          return {
            html:html||(`<html><head><title>${title}</title></head><body>${body}</body></html>`),
            url:location.href,title,
            rendered_description_html:'',rendered_description_meta:{strategy:'fallback-dom-snapshot-v2-regulatory',text_length:text.length},
            rendered_specifications_html:specHtml,rendered_specifications_meta:{strategy:'fallback-dom-snapshot-v2-regulatory',row_candidates:pairs.length,expanded:false},
            rendered_primary_price:null,rendered_primary_price_meta:{strategy:'fallback-dom-snapshot-v2-regulatory',authority_class:'recovery-only'},
            rendered_identity_evidence:{version:'fallback-dom-snapshot-v3-regulatory',title_text:h1||title,body_text_probe:text.slice(0,60000),ocr_status:'pending'},
            source_title_certificate:{version:'source-title-identity-authority-v1',visible_h1:h1||'',document_title:title,page_lang:document.documentElement?.lang||'',url:location.href,locked:Boolean(h1),source:'fallback-visible-h1'},
            rendered_sustainability_evidence:{version:'fallback-dom-snapshot-v2-regulatory',energy_class:generic,energy_class_sdr:sdr,energy_class_hdr:hdr,energy_truth_certificate:cert,durability_index:'',repairability_index:''},
            energy_truth_certificate:cert,
            regulatory_presence_certificate:{version:'regulatory-presence-certificate-v1',energy_product_class_observed:Boolean(generic),energy_hdr_observed:Boolean(hdr),scan_coverage:pairs.length>=3?'high':pairs.length?'medium':'low',pair_count:pairs.length,fail_closed_if_absent:pairs.length>=3},
            price_truth_certificate:{version:'atomic-money-authority-v3',locked:false,reason:'fallback_has_no_authoritative_price'},
            capture_recovery:{fallback_used:true,regulatory_fallback:true,regulatory_pair_count:pairs.length,html_length:(html||body).length,text_length:text.length}
          };
        }
      });
      result=fallbackResult;
    }
    if(!result || !String(result.html||'').trim()) throw new Error('Capture DOM vide après fallback de récupération.');

    await maceRunPixelOcr(result);
    const ocrConsensus=result?.rendered_identity_evidence?.visual_ocr_brand_consensus||[];
    msg(`OCR visuel terminé${ocrConsensus.length?` · marque(s) corroborée(s) : ${ocrConsensus.join(', ')}`:''}. Transmission…`);
    const r=await fetch(cloud+'/v1/bridge/upload',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code,...result,browser_runtime_identity_certificate:{...bridgeRuntimeIdentityCertificate,transmitted_at:new Date().toISOString()},filtering_policy:filterPolicy,filtering_policy_hash:filterPolicy?.policy_hash||''})});
    const j=await r.json();
    if(!r.ok||!j.ok) throw new Error(j?.error?.message||'Échec de transmission.');
    const detected=j.fields?.images_detected??j.fields?.images??0,
      validated=j.fields?.images_validated??j.fields?.images??0,
      rejected=j.fields?.images_rejected??0,
      collapsed=j.fields?.images_collapsed??0,
      primaryPrice=j.fields?.primary_price??'',
      priceSource=j.fields?.price_source??'',
      length=j.fields?.length??'',width=j.fields?.width??'',height=j.fields?.height??'',
      dimensionUnit=j.fields?.dimension_unit??'cm',
      dimensions=(length&&width&&height)?`${length} × ${width} × ${height} ${dimensionUnit}`:'non confirmées',
      descriptionSource=j.fields?.description_source??'non confirmée',
      descriptionBlocks=j.fields?.description_blocks??0;
      specificationsStrategy=result?.rendered_specifications_meta?.strategy??'none',
      specificationsRows=result?.rendered_specifications_meta?.row_candidates??0,
      specificationsExpanded=result?.rendered_specifications_meta?.expanded??false;
      energyClass=result?.rendered_sustainability_evidence?.energy_class??'',
      energyCooling=result?.rendered_sustainability_evidence?.energy_class_cooling??'',
      energyHeating=result?.rendered_sustainability_evidence?.energy_class_heating??'',
      durabilityIndex=result?.rendered_sustainability_evidence?.durability_index??'',
      repairabilityIndex=result?.rendered_sustainability_evidence?.repairability_index??'';
    maceRenderCaptureSummary({j,result,detected,validated,rejected,collapsed,primaryPrice,priceSource,dimensions,descriptionSource,descriptionBlocks,specificationsStrategy,specificationsRows,specificationsExpanded,energyClass,energyCooling,energyHeating,durabilityIndex,repairabilityIndex});
  }catch(e){msg('Erreur : '+e.message)}
};
