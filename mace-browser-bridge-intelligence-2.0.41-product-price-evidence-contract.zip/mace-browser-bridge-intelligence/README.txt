MACE Browser Bridge Intelligence 2.0.12 — Golden Non-Regression
Version visible directement en haut du popup Chrome.
Cloud: https://mace-cloud-extraction-engine-h5q7.onrender.com

Cette version conserve les acquis 2.0.11 : prix principal, Product Media Ownership, galerie produit, dimensions Unicode et transmission H5Q7.
Aucun mécanisme validé n'est supprimé ; évolution additive uniquement.
Stack recommandée : Plugin 5.3.24 RC1 + Browser 2.0.12 + Cloud 5.3.16 RC1.

2.0.15 — Source Layout Fidelity
- capture prioritaire de la plage rendue comprise entre « Description » et la prochaine section hors description ;
- conservation des paragraphes, titres, listes, tableaux et ordre DOM ;
- transmission de rendered_description_html + métriques de structure au Cloud 5.3.18 ;
- aucune modification des politiques médias, prix ou dimensions.

2.0.15 — Description Boundary Firewall
- arrête la capture avant les blocs « Les internautes ont aussi acheté », produits/articles similaires, recommandations et suggestions ;
- applique le même coupe-feu au mode selector fallback ;
- ne modifie jamais le contenu produit compris avant cette frontière.


2.0.16 — Characteristics Capture
- recherche sémantique de Caractéristiques / Spécifications / Fiche technique ;
- ouverture ciblée d’un contrôle « Voir tout / Afficher plus » uniquement dans une zone de caractéristiques ;
- capture dédiée par plage de titres avec arrêt avant Description/Avis/Offres/etc. ;
- fallback sur racines DOM caractéristiques/specifications/technical ;
- injection de la capture dans une copie du DOM transmise au Cloud, sans modifier la page utilisateur ;
- métriques locales de lignes candidates affichées dans le popup ;
- aucun changement des politiques prix, médias, dimensions ou Description.


2.0.19 — Primary Price Zone Authority + Merchant Source Firewall
- construit une zone produit principale autour du H1 et du bouton d'achat ;
- reconstruit les prix fragmentés entre éléments enfants (ex. 425 + ,41 € => 425,41 €) ;
- pénalise les prix barrés, mensualités, financement et petits montants accessoires ;
- exclut les zones Produit similaire / recommandations / sponsorisé de l'autorité prix ;
- neutralise les itemprop=price étrangers dans la copie DOM transmise au Cloud lorsqu'un prix principal est confirmé ;
- injecte une preuve primaire marquée data-mace-bridge-primary-price sans modifier la page source visible ;
- conserve intégralement les mécanismes 2.0.16 de caractéristiques, description, médias et dimensions.


2.0.19 — Merchant Source Firewall
- conserve Primary Price Zone Authority 2.0.17 ;
- retire des copies transmises les attributs de provenance marketplace (Réf. ManoMano, MMID, breadcrumbs/source IDs) ;
- retire les mentions éditoriales de source comme « Réponses générées par IA à partir des informations vendeur » ;
- ne retire jamais Réf. fabricant, EAN/GTIN, marque, dimensions ou caractéristiques produit légitimes.


2.0.20 — Multi-Evidence Brand Authority
- Conserve la voie de prix exact 2.0.19.
- Capture les preuves de marque depuis le titre, les champs Brand/Marque, les breadcrumbs et les images produit.
- Analyse alt/title/aria-label, noms de fichiers, légendes et textes visibles associés aux images produit.
- Rejette les technologies et familles produit (OLED/QLED/LED/4K/Smart TV, etc.) comme marques.
- Transmet image_brand_candidates et image_text_hints au Cloud pour consensus multi-preuves.
- Cette version ne prétend pas faire de reconnaissance OCR pixel native dans Chrome; le contrat accepte image_ocr_text si une future lane OCR validée est ajoutée.

2.0.39: strict independent corroboration for tiny prices, multimode energy A++/A preservation, URL-overlap ranked source title.

2.0.41: semantic product-price authority; ManoMano structured Product Offer defeats materially different CTA/financing amounts regardless of magnitude.
